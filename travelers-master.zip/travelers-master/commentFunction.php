<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <title>Messages</title>
</head>

<body>
    <?php
 $_SESSION['id'] = 2;
 //$login  = $_SESSION['login'];
 $id= $_SESSION['id'];
require('connexionBD.php');
    if(isset($_POST['date'])){

        $nom=$_POST['nom'];
        $prenom=$_POST['prenom'];
        $date=$_POST['date'];
        $sujet=$_POST['sujet'];
        $message=$_POST['message'];


   	
        $sql = "INSERT INTO message (titreMessage, texteMessage, dateMessage, idUser) VALUES ('$sujet', '$message', '$date', $id )";
        $sqlGet ="SELECT * FROM message INNER JOIN user ON message.idUser = user.idUser";
        $sql1 = "DELETE FROM message WHERE message.idMessage='$message'"; 

        

        if(mysqli_query($connexion, $sql)){
            echo "Enregistrement fait avec succès.";
        } else{
            echo "Erreur: Vérifier votre base de donnèes $sql. " . mysqli_error($connexion);
        }

        if($result = $connexion->query($sqlGet)){

            while ($row = $result->fetch_assoc()) {
                
                echo '<div class="comment-box col">';
                echo $row['idUser']."<br>";
               // echo $id."<br>";
                echo $row['nomUser']." ".$row['prenomUser']."<br>"; 
                echo $row['dateMessage']."<br>";
                echo $row['titreMessage']."<br>";
                echo $row['texteMessage']."<br>";
                echo '</div>';
                echo '<div>';
                echo '<input type="button" name="supp" value="Supprimer" class="btn btn-danger text-white">';
                echo '</div>';

            } 
            mysqli_close($connexion);   
        }
    }
    // if(isset($_GET['supp'])){

    //         $result = $connexion->query($sql1);
    //         mysqli_close($connexion); 
    // }
?>
</body>

</html>