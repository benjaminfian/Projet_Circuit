<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Messages</title>
</head>
<body>
<?php
 $_SESSION['id'] = 1;
 //$login  = $_SESSION['login'];
 $id= $_SESSION['id'];
require('connexionBD.php');
    if(isset($_POST['date'])){

        $nom=$_POST['nom'];
        $prenom=$_POST['prenom'];
        $date=$_POST['date'];
        $sujet=$_POST['sujet'];
        $message=$_POST['message'];


   	
        $sql = "INSERT INTO message (titreMessage, texteMessage, dateMessage, idUser) VALUES ('$sujet', '$message', '$date', $id )";
        $sqlGet ="SELECT * FROM message INNER JOIN user ON message.idUser = user.idUser";

        

        if(mysqli_query($connexion, $sql)){
            echo "Enregistrement fait avec succès.";
        } else{
            echo "Erreur: Vérifier votre base de donnèes $sql. " . mysqli_error($connexion);
        }

        if($result = $connexion->query($sqlGet)){

            echo '<table class="table">';
            echo '<tr>';
            echo '<th scope="col">Date </th>';
            echo '<th scope="col">Sujet</th>';
            echo '<th scope="col">Message</th>';
            echo '</tr>'; 

            while ($row = $result->fetch_assoc()) {
                echo '<tr><td>' . $row['dateMessage'] . '</td><td>' . $row['titreMessage'] . '</td><td>' . $row['texteMessage'] . '</td></tr>';
            }
            echo '</table>';
            
        

     
        }    

        mysqli_close($connexion);
    
    }


?>
</body>
</html>

