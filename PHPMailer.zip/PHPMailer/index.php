<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="main.js"></script>
</head>
<body>
<h1>Contact</h1>
    <div class="container">
        <form method="post">
       
            <div class="form-group">
                <label>Nom :</label>
                <input type="text" name="nom" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" required>
            </div>
            <div class="form-group">
                <label>Message</label>
                <textarea name="message" required></textarea>
            </div>
            <input type="submit" class="btn btn-primary">
         
        </form>
    </div>    
</body>
</html>
<?php
if (isset($_POST['nom'],$_POST['email'],$_POST['message'])) {
    $nom=$_POST['nom'];
    $email=$_POST['email'];
    $message=$_POST['message'];
    
    require 'phpmailer/PHPMailerAutoload.php';
    $mail = new PHPMailer();

    $mail->isSMTP();
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPSecure = "ssl";
    $mail->Port = 465;
    $mail->SMTPAuth = true;
    $mail->Username = 'circuit16701@gmail.com';
    $mail->Password = '@zerty01';

    $mail->setFrom($email, $nom);
    $mail->addAddress('circuit16701@gmail.com');
    $mail->Subject = 'Nouveau mail depuis notre site';
    $mail->Body = $message;

    if ($mail->send()){
       
        echo '<div class="alert alert-success" role="alert">Votre message a bien été envoyé.</div>';
    }    
    else
        
        echo '<div class="alert alert-danger" role="alert">Message non envoyé : " '.$mail->ErrorInfo.'</div>';
     
  
}
?>
