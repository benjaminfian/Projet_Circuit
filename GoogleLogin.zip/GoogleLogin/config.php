<?php
	session_start();
	require_once "GoogleAPI/vendor/autoload.php";
	$gClient = new Google_Client();
	$gClient->setClientId("816250088029-f9o304gir599ouod08db4nhfsvo298cl.apps.googleusercontent.com");
	$gClient->setClientSecret("G6kg_tWxZ87aNez2_1mha9LE");
	$gClient->setApplicationName("CPI Login Tutorial");
	$gClient->setRedirectUri("http://localhost/GoogleLogin/g-callback.php");
	$gClient->addScope("https://www.googleapis.com/auth/plus.login https://www.googleapis.com/auth/userinfo.email");
?>
