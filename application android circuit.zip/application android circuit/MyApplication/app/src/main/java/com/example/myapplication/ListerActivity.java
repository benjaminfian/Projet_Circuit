package com.example.myapplication;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;
import android.widget.AdapterView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.content.Context;
import android.widget.ImageView;
//import com.bumptech.glide.Glide;
import  java.util.concurrent.ExecutionException;

public class ListerActivity extends AppCompatActivity{ //implements View.OnClickListener {
    ListView liste;
    private static final String TAG = "ListerActivity";
    //Context context = ListerActivity.this;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lister);
        liste=(ListView) findViewById(R.id.liste);
        lister();
    }

    public void lister() {

        final ArrayList<HashMap<String, Object>> tabLivres = new ArrayList<HashMap<String, Object>>();

        //String url = "http://10.0.2.2:8080/Exemple_Controleur_Android/PHP/livresControleur.php";
        String url = "http://10.0.2.2:8080/projetCircuit/circuits/circuitControleur.php";

        StringRequest requete = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            Log.d("RESULTAT", response);
                            int i,j;
                            JSONArray jsonResponse = new JSONArray(response);
                            HashMap<String, Object> map;
                            String msg = jsonResponse.getString(0);
                            if(msg.equals("OK")){
                                JSONObject unLivre;
                                for(i=1;i<jsonResponse.length();i++){
                                    unLivre=jsonResponse.getJSONObject(i);
                                    map= new HashMap<String, Object>();
                                    //j=(i%7);//m0.jpg, ...,m6.jpg round robin
                                    //String nomImage = "m"+j;
                                   /* byte[] decodedString = Base64.decode(unLivre.getString("image"), Base64.DEFAULT);
                                    Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                                    Drawable d = new BitmapDrawable(getResources(),decodedByte);
                                    map.put("Image", d);
                                    if (i==3)
                                        map.put("img", d);
                                    else*/

                                    //map.put("img", String.valueOf(getResources().getIdentifier(nomImage, "drawable", getPackageName())));

                                    /*Bitmap image = Glide.
                                            with(ListerActivity.this).
                                            asBitmap().
                                            load("http://10.0.2.2:8080"+unLivre.getString("img")).
                                            into(50,70).
                                            get();
                                    map.put("idl", unLivre.getString("id"));
                                    map.put("img",image);*/

                                    //ImageView imageView = (ImageView) findViewById(R.id.img);
                                    //ImageView image = Glide.with(this).load("http://goo.gl/gEgYUd").into(imageView);

                                    String image = String.valueOf(getResources().getIdentifier("image"+i, "drawable", getPackageName()));//String.valueOf(idimage);


                                    map.put("img",image);
                                    map.put("mtitre", unLivre.getString("titre"));
                                    map.put("mprix", unLivre.getString("prix"));
                                    map.put("mnbetapes", unLivre.getString("nbEtapes"));
                                    map.put("mdatedebut", unLivre.getString("dateDebut"));
                                    map.put("mdatefin", unLivre.getString("dateFin"));
                                    tabLivres.add(map);
                                }

                                SimpleAdapter monAdapter = new SimpleAdapter (ListerActivity.this, tabLivres, R.layout.lister_livres_map,
                                        new String[] {"img","mtitre","mprix","mnbetapes","mdatedebut","mdatefin"},
                                        new int[] {R.id.img,R.id.mtitre,R.id.mprix,R.id.mnbetapes,R.id.mdatedebut,R.id.mdatefin});
                                liste.setAdapter(monAdapter);
                            }
                            else{}
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        /*catch (final ExecutionException e) {
                            Log.e(TAG, e.getMessage());
                        } catch (final InterruptedException e) {
                            Log.e(TAG, e.getMessage());
                        }*/
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(ListerActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                // Les parametres pour POST
                params.put("action", "listerm");
                return params;
            }
        };
        Volley.newRequestQueue(this).add(requete);//Si Volley rouge clique Volley et choisir add dependency on module volley
    }
}

