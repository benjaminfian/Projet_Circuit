package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
//https://futurestud.io/tutorials/how-to-run-an-android-app-against-a-localhost-api
public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    Button benreg,blister,bmodifier,benlever;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ajouterEvents();
    }

    public void ajouterEvents(){

        blister = (Button) findViewById(R.id.blister);
        blister.setOnClickListener(this);
    }

    public void onClick(View v) {
        switch(v.getId()){
            case R.id.blister:
                lister();
                break;
        }
    }
    public void enregistrer(){
        //Intent IntEnreg = new Intent(MainActivity.this, EnregistrerActivity.class);
        //startActivity(IntEnreg);
    }
    public void lister(){
        Intent IntLister = new Intent(MainActivity.this, ListerActivity.class);
        startActivity(IntLister);
    }
    public void modifier(){
        //Intent IntModif = new Intent(MainActivity.this, ModifierActivity.class);
        //startActivity(IntModif);
    }
    public void enlever(){
        //Intent IntEnlever = new Intent(MainActivity.this, EnleverActivity.class);
        //startActivity(IntEnlever);
    }

}
