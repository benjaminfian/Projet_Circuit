-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  ven. 14 juin 2019 à 19:43
-- Version du serveur :  5.7.17
-- Version de PHP :  5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `dbcircuits`
--

-- --------------------------------------------------------

--
-- Structure de la table `activite`
--

CREATE TABLE `activite` (
  `descriptionActivite` text COLLATE utf8_unicode_ci NOT NULL,
  `idJour` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `activite`
--

INSERT INTO `activite` (`descriptionActivite`, `idJour`) VALUES
('<p>Description etape 1 jour 1</p>', 49),
('<p>Description etape 1 jour 2</p>', 50),
('<p>Description etape 1 jour 3</p>', 51),
('<p>Description etape 2 jour 1</p>', 52),
('<p>Description etape 2 jour 2</p>', 53),
('<p>Description etape 2 jour 3</p>', 54),
('<p>Description etape 3 jour 1</p>', 55),
('<p>Description etape 3 jour 2</p>', 56),
('<p>Description etape 3 jour 3</p>', 57),
('<p>D&eacute;part pour la visite &agrave; pied de la ville avec votre guide francophone. En passant par&nbsp;Hyde Park et le Queen Victoria Building, d&eacute;couverte du quartier&nbsp;historique des Rocks. D&icirc;ner-croisi&egrave;re&nbsp;dans la baie &agrave; bord d&rsquo;un catamaran qui vous m&egrave;nera parmi les sites les plus renomm&eacute;s, tels que :&nbsp;le Sydney Harbour Bridge, le Fort Denison, le Luna Park&nbsp;et les demeures des milliardaires qui bordent la baie. Passage &agrave; l&rsquo;ext&eacute;rieur au pied du c&eacute;l&egrave;bre&nbsp;Op&eacute;ra de Sydney&nbsp;et balade dans les&nbsp;jardins botaniques.&nbsp;</p>', 61),
('<p>Vous partirez &agrave; pied vers Circular Quay pour la travers&eacute;e en bateau vers Manly et sa c&eacute;l&egrave;bre plage bord&eacute;e de pins, son ambiance d&eacute;contract&eacute;e, ses surfeurs et sa charmante rue pi&eacute;tonne (boutiques, caf&eacute;s&hellip;) Passage par le chemin c&ocirc;tier vers l&rsquo;anse de Shelly Beach. Retour au quai pour le bateau vers Watsons Bay et d&icirc;ner au c&eacute;l&egrave;bre restaurant Doyles On the Beach d&rsquo;o&ugrave; vous apercevez une vue imprenable sur la baie. Promenade c&ocirc;ti&egrave;re sur le &laquo;Gap&raquo; le long des falaises pour un panorama sur l&rsquo;oc&eacute;an. Retour vers Circular Quay en bateau et visite de la Sydney Tower Eye avec sa vue &agrave; 360 degr&eacute;s. Retour &agrave; l&rsquo;h&ocirc;tel, fin d&rsquo;apr&egrave;s midi et souper libre.</p>', 62),
('<p>Journ&eacute;e libre pour d&eacute;couverte personnelle. (DJ)&nbsp;Option sur place ($) : Montagnes Bleues : D&eacute;part avec votre guide francophone pour une journ&eacute;e d&rsquo;excursion aux Montagnes Bleues, l&rsquo;Echo Point et les Three Sisters, en passant par le parc animalier de Featherdale. D&icirc;ner inclus. Retour &agrave; Sydney en fin d&rsquo;apr&egrave;s-midi.</p>', 63),
('<p>D&eacute;part en direction de Kings Canyon, avec un arr&ecirc;t &agrave; &laquo;Anzac Hill&raquo; pour observer la vue panoramique sur la ville et les &laquo;MacDonnell Ranges&raquo;. D&icirc;ner et arr&ecirc;ts photos des paysages d&eacute;sertiques en route. Arriv&eacute;e en fin d&rsquo;apr&egrave;s-midi &agrave; Kings Creek Station, ranch de l&rsquo;Outback sur les terres de la famille Conway, &eacute;leveur et exportateur de chameaux. Souper et nuit en tente au campement permanent.</p>', 64),
('<p>D&eacute;part matinal avec votre guide pour la&nbsp;randonn&eacute;e spectaculaire du Rim Walk,&nbsp;sentier d&rsquo;une intensit&eacute; moyenne de 6 km au sommet du Kings Canyon. Possibilit&eacute; d&rsquo;une balade moins sportive sans guide. D&icirc;ner en cours de route. En apr&egrave;s-midi, marche autour du rocher par le chemin de&nbsp;Mala jusqu&rsquo;&agrave;&nbsp;la Gorge de Katju&nbsp;et marche jusqu&rsquo;&agrave;&nbsp;Mutitjulu. En fin de journ&eacute;e, vous assisterez au&nbsp;coucher&nbsp;de soleil sur Uluru&nbsp;en d&eacute;gustant un ap&eacute;ritif et en &eacute;coutant des l&eacute;gendes li&eacute;es &agrave; ce site sacr&eacute;, un moment inoubliable.&nbsp;Souper barbecue, o&ugrave; vous ferez cuire vous-m&ecirc;me votre viande dans l&rsquo;ambiance conviviale du bush.</p>', 65),
('<p>D&eacute;part matinal avec panier d&eacute;jeuner pour assister au&nbsp;lever de soleil sur les Monts&nbsp;Olgas, aussi appel&eacute;s Kata-Tjuta, suivi d&rsquo;une&nbsp;marche d&rsquo;environ 1 heure&nbsp;en compagnie de votre guide au milieu du site. Visite du&nbsp;Centre&nbsp;Culturel&nbsp;consacr&eacute; &agrave; la culture et &agrave; l&rsquo;art aborig&egrave;ne Anangu. D&icirc;ner libre. Transfert &agrave; l&rsquo;a&eacute;roport d&rsquo;Ayers Rock pour le vol en direction de Cairns (non inclus). Accueil et transfert vers Palm Cove, jolie petite&nbsp;station&nbsp;baln&eacute;aire&nbsp;situ&eacute;e &agrave; une vingtaine de minutes au nord de Cairns. Souper &agrave; l&rsquo;h&ocirc;tel.</p>', 66),
('<p>D&eacute;part pour la visite d&rsquo;une&nbsp;ferme de crocodiles. D&icirc;ner &agrave; Port Douglas. En apr&egrave;s-midi, atelier de peinture avec un artiste aborig&egrave;ne local qui vous initiera aux techniques traditionnelles pour&nbsp;peindre votre boomerang, que vous pourrez garder en souvenir. Vous vous rendrez ensuite aux&nbsp;Mossman Gorges. Marche d&rsquo;environ 1h30 dans la for&ecirc;t tropicale de Daintree, en compagnie d&rsquo;un guide aborig&egrave;ne.&nbsp;D&eacute;couverte&nbsp;de la gigantesque canop&eacute;e, de la faune, de la flore color&eacute;e et des cascades cristallines.&nbsp;C&eacute;r&eacute;monie traditionnelle&nbsp;et apprentissage sur l&rsquo;usage des plantes, les traditions, les croyances et l&rsquo;histoire de la culture Kuku Yalanji. Retour &agrave; l&rsquo;h&ocirc;tel en fin d&rsquo;apr&egrave;s-midi. Souper libre.</p>', 67),
('<p>En matin&eacute;e, t&eacute;l&eacute;ph&eacute;rique Skyrail pour survoler la for&ecirc;t tropicale en direction du village pittoresque de Kuranda avec ses nombreux magasins d&rsquo;artisanat local. D&icirc;ner libre. Au retour, train historique &agrave; travers 15 tunnels et plus de 40 ponts qui offre des vues spectaculaires sur des chutes d&rsquo;eau et canyons. Transfert &agrave; votre h&ocirc;tel.</p>', 68),
('<p>Arriv&eacute;e &agrave; <strong>Moscou</strong>. Accueil &agrave; l&rsquo;a&eacute;roport par votre guide.&nbsp;<strong>C&eacute;r&eacute;monie du pain et du sel</strong>&nbsp;&agrave; l&rsquo;arriv&eacute;e &agrave; l&rsquo;h&ocirc;tel.</p>', 69),
('<p>On s&rsquo;y arr&ecirc;te sur la place des Cath&eacute;drales, o&ugrave; se dressent des &eacute;glises c&eacute;l&egrave;bres, comme l&rsquo;Annonciation (XVe si&egrave;cle) dont l&rsquo;iconostase contient des peintures d&rsquo;Andre&iuml; Roublev, celle de l&rsquo;Archange-Saint-Michel (XVIe si&egrave;cle) d&rsquo;esprit v&eacute;nitien et celle de la Dormition (XVe si&egrave;cle) o&ugrave; fut couronn&eacute; Ivan IV le Terrible. Le Kremlin est le c&oelig;ur de toutes les Russies, dans l&rsquo;espace et dans le temps. Les b&acirc;timents civils et religieux qui le composent permettent de lire dans l&rsquo;architecture l&rsquo;histoire politique et culturelle du pays depuis le XVe si&egrave;cle, d&rsquo;Ivan III le Grand &agrave; Vladimir Poutine. Visite en compagnie d&rsquo;un guide francophone priv&eacute;. <strong>Lunch</strong>&nbsp;en ville <a href=\"https://www.cafemumu.ru/\">https://www.cafemumu.ru/</a>.&nbsp;<strong>Visite de la </strong><a href=\"https://www.tretyakovgallery.ru/en/\">Galerie Tretiakov&nbsp;</a>dont les 62 salles sont r&eacute;parties sur 2 niveaux pour pr&eacute;senter aux visiteurs entre autres : la peinture russe classique des 18e et 19e si&egrave;cles, des tableaux de l&rsquo;Avant-garde russe et de magnifiques ic&ocirc;nes.&nbsp;</p>\r\n<p><strong>&nbsp;</strong></p>', 70),
('<p><strong>Visite du couvent Novodievitchi</strong>. Fond&eacute; en 1524, il &eacute;tait destin&eacute; aux femmes des familles des Tsars ou des grandes familles russes. Il est, apr&egrave;s le Kremlin, le plus remarquable ensemble d&rsquo;architecture religieuse de Moscou.&nbsp;<strong>Lunch</strong>&nbsp;puis temps libre au centre-ville.&nbsp;<strong>D&icirc;ner&nbsp;</strong>suivi de la d&eacute;couverte de &laquo;<strong>Moscou illumin&eacute;</strong>&raquo; avec une&nbsp;<strong>visite des plus belles stations de m&eacute;tro.</strong></p>', 71),
('<p>Route pour&nbsp;<strong>St-P&eacute;tersbourg</strong>. Lors de vos d&eacute;placements,&nbsp;<strong>conf&eacute;rence sur l&rsquo;art et l&rsquo;architecture russes. Lunch</strong>&nbsp;suivi d&rsquo;un&nbsp;<strong>tour de ville panoramique</strong>&nbsp;de la capitale de Pierre le Grand : la perspective Nevski, les quais de la N&eacute;va, la place du palais d&rsquo;Hiver, l&rsquo;Amiraut&eacute;, la cath&eacute;drale St-Isaac, puis,&nbsp;<strong>visite de la forteresse Pierre et Paul</strong>, transform&eacute;e en prison &agrave; partir de 1717 et de la&nbsp;<strong>cath&eacute;drale St- Pierre et St-Paul</strong>&nbsp;qui renferme les tombeaux des Romanov depuis Pierre le Grand. Installation &agrave; l&rsquo;h&ocirc;tel et&nbsp;<strong>d&icirc;ner</strong>.</p>', 72),
('<p>Excursion &agrave;&nbsp;<strong>Petrodvorets</strong>. Autrefois r&eacute;sidence de campagne des Tsars, l&rsquo;ensemble unique du palais et des parcs de Petrodvorets est un v&eacute;ritable monument de l&rsquo;art russe des 18e et 19e si&egrave;cles.&nbsp;<strong>Visite int&eacute;rieure du grand palais de Pierre et du parc. Lunch</strong>&nbsp;sur place - <a href=\"http://www.restaurantshtandart.spb.ru/\">http://www.restaurantshtandart.spb.ru/</a>. Retour en ville.&nbsp;<strong>Visite de l&rsquo;&eacute;glise St-Nicolas des Marins</strong>, o&ugrave; vous assisterez &agrave; une partie de l&rsquo;office puis&nbsp;<strong>visite du march&eacute; local</strong>&nbsp;afin d&rsquo;y d&eacute;couvrir les produits du terroir russe.</p>', 73),
('<p>Tsarsko&iuml;e Selo (Pouchkine, &agrave; partir de 1937) est situ&eacute;e &agrave; 25 km environ au sud de Saint-P&eacute;tersbourg. Palais, &eacute;glises, parcs, h&ocirc;tels particuliers - la cour ne faisait pas de camping - composent une vill&eacute;giature tr&egrave;s s&eacute;lecte. En compagnie d&rsquo;un guide priv&eacute; francophone, on visite le palais de Catherine II et ses jardins (Bartolomeo Rastrelli, 1752 et Charles Cameron, 1780-1787) et le palais de Pavlovsk (Charles Cameron, 1782-1786) que l&rsquo;imp&eacute;ratrice offrit &agrave; son fils Paul. Il y a l&agrave; quelque chose de moins majestueux que dans les grands ensembles palatiaux de Saint-P&eacute;tersbourg, mais plus de l&eacute;g&egrave;ret&eacute; et toujours une &eacute;tourdissante magnificence.</p>', 74),
('<p>Arriv&eacute;e matinale &agrave;<strong>&nbsp;Irkoutsk.</strong>&nbsp;Transfert chez l\'h&ocirc;tel, dans le centre de la ville. Apr&egrave;s le petit d&eacute;jeuner, la visite de la ville d&rsquo;Irkoutsk. Vous pourrez visiter les quartiers historiques des maisons en bois, le mus&eacute;e des D&eacute;cembristes, le mus&eacute;e ethnographique, le centre-ville et ses march&eacute;s, les quais de l\'Angara. D&icirc;ner et nuit chez l&rsquo;habitant.</p>', 75),
('<p>Apr&egrave;s le petit d&eacute;jeuner, transfert &agrave; la gare routi&egrave;re et d&eacute;part en bus public vers&nbsp;<strong>l&rsquo;&icirc;le d&rsquo;Olkhon.</strong>&nbsp;250 km de la bonne route jusqu\'au d&eacute;troit les Portes d\'Olkhone qui s&eacute;pare l&rsquo;&icirc;le de la grande terre. La travers&eacute;e du d&eacute;troit en ferry en &eacute;t&eacute;, ou sur la glace en hiver. Puis, encore 40 km de piste jusqu&rsquo;au<strong>&nbsp;village principal de l&rsquo;&icirc;le Khoujir.&nbsp;</strong>Visite du&nbsp;<strong>village des p&ecirc;cheurs</strong>&nbsp;et d<strong>u Rocher au Chamane,&nbsp;</strong>lieu sacr&eacute; des chamanistes sib&eacute;riens.&nbsp;</p>', 76),
('<p>Apr&egrave;s le petit d&eacute;jeuner, nous partons en voiture dans la partie nord de<strong>&nbsp;l\'&icirc;le d\'Olkhon.&nbsp;</strong>Nous allons visiter la pointe nord de l&rsquo;&icirc;le, le<strong>&nbsp;cap Khobo&iuml;,</strong>&nbsp;lieu sacr&eacute; prot&eacute;g&eacute; par l\'&eacute;tat et les esprits des Dieux bouriates. Promenade le long de hautes falaises qui surplombent le lac.&nbsp;<strong>Panorama magnifique</strong>&nbsp;de la partie la plus large du<strong>&nbsp;lac Baikal&nbsp;</strong>&ndash; pr&eacute;sque 80 km. Dans l\'apr&egrave;s-midi, notre chemin nous emm&egrave;ne &agrave; la station m&eacute;t&eacute;orologique de&nbsp;<strong>Ouzouri</strong>&nbsp;&ndash; endroit d\'une beaut&eacute; exeptionnelle.&nbsp; Balade aux alentours de la station et petite ascension facile de soir pour contempler le coucher du soleil.&nbsp;</p>', 77),
('<p>D&eacute;part depuis Marrakech, jusqu\'&agrave; Ouarzazate via le col du Tizi N Tichka dans le Haut Atlas (2260M d\' alt.). Pause &agrave; Ouarzazate, puis visite de la casbah de Taourirte class&eacute;e au patrimoine mondial par l\'Unesco. Direction Tineghir qui est r&eacute;put&eacute;e pour sa palmeraie, une des plus riches du Maroc.</p>\r\n<p>Diner et nuit &agrave; Tineghir en chambre d\'h&ocirc;te ou h&ocirc;tel de charme selon disponiblit&eacute;s.</p>', 78),
('<p>Petit d&eacute;jeuner, puis route jusqu\'au d&eacute;sert de Merzouga. Des dunes impressionnantes vous y attendent. Balade en dromadaire jusqu\'au bivouac.</p>\r\n<p>Diner et nuit dans le d&eacute;sert, sous les tentes nomades au bivouac.</p>', 79),
('<p>Balade en dromadaire dans le d&eacute;sert au lever du soleil. Petit d&eacute;jeuner puis route jusqu\'&agrave; Ouarzazate. Pause &agrave; Foum Zguid, et Tazenakht, r&eacute;put&eacute;es pour ses fabriques de tapis. Arriv&eacute;e &agrave; Ouarzazate : visite des studios de cin&eacute;ma (en option).</p>\r\n<p>D&icirc;ner et nuit en h&ocirc;tel de charme ou chambre d\'h&ocirc;te typique.</p>', 80),
('<p>Apr&egrave;s le petit-d&eacute;jeuner, nous viendrons vous chercher &agrave; l\'h&ocirc;tel / au Lodge &agrave; 8h00, puis nous commencerons par un trajet en voiture vers la zone de conservation de Ngorongoro. Tandis que nous continuons &agrave; conduire vers le nord, nous aurons une promenade d\'observation du jeu en direction de Serengeti.</p>\r\n<p>Il y a beaucoup &agrave; observer: plus de 1,5 million de gnous et 700&rsquo;000 z&egrave;bres sont en route ici si nous passons lors de la fameuse migration annuelle.</p>\r\n<p><em><u>D&icirc;ner et nuit au camping Seronera &agrave; l\'int&eacute;rieur du parc.</u></em></p>', 81),
('<p>Une journ&eacute;e compl&egrave;te au parc national du Serengeti, &agrave; la recherche de migrations de gnous, y compris de pr&eacute;dateurs et de pri&egrave;res. D&icirc;ner et nuit au camping Seronera &agrave; l\'int&eacute;rieur du parc.</p>', 82),
('<p>Notre dernier jour commence tr&egrave;s t&ocirc;t le matin. Equip&eacute;s d&rsquo;un pique-nique, nous descendons jusqu&rsquo;&agrave; l&rsquo;&eacute;tage du crat&egrave;re &agrave; bord de notre v&eacute;hicule &agrave; 4 &times; 4 roues pour observer le gibier. Explorons ce jardin d&rsquo;Eden. Ngorongoro est un crat&egrave;re volcanique &eacute;norme et profond. Il y a de nombreux p&acirc;turages, mar&eacute;cages, for&ecirc;ts et eau permanente sur le sol du crat&egrave;re, ce qui explique pourquoi la faune est si diverse et nombreuse. Il y a jusqu\'&agrave; 25 000 animaux de plus grande taille vivant ici. C&rsquo;est la meilleure occasion de voir le rhinoc&eacute;ros noir et de nombreuses autres esp&egrave;ces rares comme le lion &agrave; la chair noire. Nous aurons une journ&eacute;e fantastique et vous verrez la faune sous son meilleur jour. En fin d&rsquo;apr&egrave;s-midi, nous rentrons &agrave; Arusha et nous vous d&eacute;poserons &agrave; votre h&ocirc;tel.</p>', 83),
('<p>Laissez derri&egrave;re vous le bruit et les distractions de la vie moderne. Aujourd&rsquo;hui, vous vous r&eacute;jouissez de la d&eacute;tente et du silence de la nature recul&eacute;e. Votre guide amical vous attend pour vous aider &agrave; vous rendre au Great Bear Lodge. Montez &agrave; bord de votre hydravion pour votre premi&egrave;re aventure - la vue sur le d&eacute;troit de la Reine Charlotte et la c&ocirc;te centrale est &agrave; couper le souffle.</p>\r\n<p>Vos h&ocirc;tes sympathiques attendent de vous accueillir au lodge et de vous montrer votre chambre priv&eacute;e. En fin d\'apr&egrave;s-midi, votre premi&egrave;re session d\'observation de la faune commence. Il est presque impossible de d&eacute;crire le fait d&rsquo;avoir vu son premier grizzli: &agrave; couper le souffle, &eacute;mouvant et humiliant en un instant.</p>\r\n<p>&nbsp;</p>\r\n<p>Ce soir, un repas gastronomique pr&eacute;par&eacute; avec les meilleurs produits locaux et les fruits de mer est servi. D&eacute;gustez du vin ou une bi&egrave;re avec votre repas. Apprenez o&ugrave; le grizzli s&rsquo;int&egrave;gre dans l&rsquo;&eacute;cosyst&egrave;me local avant de vous d&eacute;tendre au coin du feu et de profiter du son de la for&ecirc;t.</p>', 84),
('<p>Le Great Bear Lodge encourage l\'&eacute;cotourisme &agrave; faible impact en utilisant l\'&eacute;nergie &eacute;olienne et solaire, en veillant particuli&egrave;rement &agrave; ne pas d&eacute;ranger les ours ni leur environnement.</p>\r\n<p>Les s&eacute;ances d&rsquo;observation des ours programm&eacute;es le matin et l&rsquo;apr&egrave;s-midi co&iuml;ncident avec les p&eacute;riodes o&ugrave; les ours sont les plus actifs. Accompagn&eacute; d\'un biologiste exp&eacute;riment&eacute; de la faune, observez les ours errer librement dans leur habitat naturel tout en naviguant en bateau dans les estuaires avoisinants ou depuis des zones d\'observation sp&eacute;cialement am&eacute;nag&eacute;es.</p>\r\n<p>Surveillez les autres animaux sauvages tels que les loups, les loutres, les pygargues &agrave; t&ecirc;te blanche, les ours noirs, les martres et les visons. Des activit&eacute;s guid&eacute;es quotidiennes, telles que des croisi&egrave;res en bateau et une promenade interpr&eacute;tative populaire dans la for&ecirc;t tropicale, sont propos&eacute;es entre les excursions d\'observation du matin et de l\'apr&egrave;s-midi.</p>\r\n<p>Si vous voyagez &agrave; la fin de l&rsquo;&eacute;t&eacute; et &agrave; l&rsquo;automne, vous serez t&eacute;moin de la vue incroyable de milliers de saumons en migration &agrave; partir d&rsquo;une s&eacute;rie de tribunes d\'observation situ&eacute;es le long de la rivi&egrave;re. Observez les grizzlis chasser le poisson en pr&eacute;vision de leur hibernation.</p>', 85),
('<p>Ce matin, vous sortez pour votre derni&egrave;re session d\'observation des ours. Assurez-vous d\'apporter votre appareil photo pour les derni&egrave;res superbes photos! Retournez au lodge pour un brunch d\'adieu avant de prendre votre hydravion pour votre voyage de retour &agrave; Port Hardy. Profitez d\'une autre soir&eacute;e dans cette communaut&eacute; de p&ecirc;cheurs.</p>', 86),
('<p><strong>Vol vers Copenhague</strong>.</p>', 87),
('<p><strong>Arriv&eacute;e &agrave; l&rsquo;a&eacute;roport de Copenhague. Accueil par votre guide de parcours puis transfert &agrave; l&rsquo;h&ocirc;tel. Souper de bienvenue au parc de Tivoli o&ugrave; toute la ville se retrouve pour relaxer ou profiter de concerts et spectacles.</strong></p>', 88),
('<p><strong>Vol vers Deer Lake. Trajet vers Rocky Harbour, village pittoresque au c&oelig;ur du parc national du Gros-Morne.</strong></p>', 89),
('<p><strong>Arriv&eacute;e &agrave; l&rsquo;a&eacute;roport de Copenhague. Accueil par votre guide de parcours puis transfert &agrave; l&rsquo;h&ocirc;tel. Souper de bienvenue au parc de Tivoli o&ugrave; toute la ville se retrouve pour relaxer ou profiter de concerts et spectacles.</strong></p>', 90),
('<p><strong>D&eacute;part pour la visite guid&eacute;e de la ville &laquo; verte &raquo;. Copenhague cultive l&rsquo;art de vivre et offre aux visiteurs de nombreux plaisirs. Vous verrez, entre autres, les superbes ch&acirc;teaux de Rosenborg et d&rsquo;Amalienborg ainsi que la glyptoth&egrave;que. L&rsquo;apr&egrave;s-midi, votre guide vous fera des propositions de visites, vous pourrez arpenter la rue pi&eacute;tonne Str&oslash;get et y d&eacute;couvrir les caf&eacute;s et restaurants traditionnels du port bord&eacute; de fa&ccedil;ades multicolores. Vous serez surpris par Christiania, le quartier tr&egrave;s anim&eacute; sillonn&eacute; de canaux. Sur le front de mer, vous vous retrouverez devant le symbole de la ville : la Petite Sir&egrave;ne, &eacute;videmment ! Nuit &agrave; Copenhague.</strong></p>', 91),
('<p><strong>Vol vers Deer Lake. Trajet vers Rocky Harbour, village pittoresque au c&oelig;ur du parc national du Gros-Morne.</strong></p>', 92),
('<p><strong>AM : Visite du centre d\'interpr&eacute;tation du parc national du Gros-Morne, site du patrimoine mondial de l\'UNESCO, &agrave; la d&eacute;couverte d\'une riche vari&eacute;t&eacute; de paysages et d\'une faune </strong></p>', 93);

-- --------------------------------------------------------

--
-- Structure de la table `circuit`
--

CREATE TABLE `circuit` (
  `idCircuit` int(11) NOT NULL,
  `titreCircuit` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `descriptionCircuit` text COLLATE utf8_unicode_ci NOT NULL,
  `prixCircuit` double NOT NULL,
  `etat` bit(1) NOT NULL DEFAULT b'0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `circuit`
--

INSERT INTO `circuit` (`idCircuit`, `titreCircuit`, `descriptionCircuit`, `prixCircuit`, `etat`) VALUES
(13, 'circuitTest', '<p>Description circuit test</p>', 5, b'0'),
(15, 'RÃŠVE AUSTRALIEN', '<p style=\"color: white;\">L&rsquo;Australie se situe entre l&rsquo;oc&eacute;an Pacifique et Indien. La majorit&eacute; de la population est concentr&eacute;e sur le littoral est et sud est. L&rsquo;Australie occupe, par son &eacute;tendue, la sixi&egrave;me place parmi les plus vastes &eacute;tats du monde. Situ&eacute; de part et d&rsquo;autre du tropique du Capricorne, le paysage est extr&ecirc;mement vari&eacute;, allant de l&rsquo;impitoyable d&eacute;sert rouge &agrave; la verte et luxuriante for&ecirc;t tropicale. Pays r&eacute;put&eacute; dans le monde entier pour ses plages et le surf.</p>', 10000, b'1'),
(16, 'TRÃ‰SORS DE RUSSIE', '<p style=\"color: white;\">La Russie, un vaste pays qui a tant de richesses &agrave; offrir aux voyageurs ! Deux villes majeures marqueront votre voyage&nbsp;: St-P&eacute;tersbourg et Moscou. Moderne, europ&eacute;enne, ponctu&eacute;e d&rsquo;une architecture &eacute;l&eacute;gante mais aussi de traces de l&rsquo;&eacute;poque socialiste, la ville est joyeuse et color&eacute;e. <strong>Vos exp&eacute;riences de voyageur y seront belles et vari&eacute;es.</strong>&nbsp;Vous passerez aussi du temps &agrave; d&eacute;couvrir&nbsp;l&rsquo;Anneau d&rsquo;Or, cet ensemble de villes situ&eacute;es au nord-est de Moscou qui furent autrefois princi&egrave;res et qui gardent aujourd&rsquo;hui&nbsp;encore de sublimes traces de cet h&eacute;ritage architectural, historique et religieux. Un voyage culturel au pays des babouchkas.</span></p>', 15000, b'1'),
(17, 'Safari', '<p style=\"color: white;\">Des grandes r&eacute;serves &agrave; celles plus m&eacute;connues, notre s&eacute;lection de voyages pour prendre le temps d\'observer les animaux et de vivre la nature : la vraie, la grande. Toutes sortes de safaris peuvent vous &ecirc;tre propos&eacute;es, des plus proches de la nature, aux plus insolites. Mais bien s&ucirc;r, le safari par excellence, celui vous permettra de voir les animaux au plus pr&egrave;s,&nbsp;les safaris en 4X4 dans les grands sanctuaires animaliers, seront sans aucun doute inoubliables. Toujours priv&eacute;s, toujours con&ccedil;us pour vous seulement. Vivez des moments et exp&eacute;riences incroyables, o&ugrave; l&rsquo;on traverse une nature vierge avec son lot de trag&eacute;die et de belles histoires, toujours cont&eacute;es avec passion par nos guides et rangers.</p>', 20000, b'1'),
(19, 'Splendeur de neige', '<p style=\"color: white;\">Rendez-vous en pays nordique, &agrave; la d&eacute;couverte du Yukon et de l&rsquo;Alaska, la Scandinavie des noms qui enflamment l&rsquo;imagination de l&rsquo;explorateur en vous et vivez une exp&eacute;rience &eacute;tonnante !. Plongez dans une culture saisissante o&ugrave; s&rsquo;entrem&ecirc;lent l&rsquo;histoire passionnante des Vikings, des traditions pr&eacute;serv&eacute;es, du folklore et du modernisme. Montagnes, grands espaces, nature sauvage, des paysages &agrave; couper le souffle. Partez avec Varesanto pour d&eacute;couvrir ces contr&eacute;es sauvages.</p>', 5000, b'1');

-- --------------------------------------------------------

--
-- Structure de la table `circuit_etape`
--

CREATE TABLE `circuit_etape` (
  `idCircuit` int(11) NOT NULL,
  `idEtape` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `circuit_etape`
--

INSERT INTO `circuit_etape` (`idCircuit`, `idEtape`) VALUES
(13, 69),
(13, 70),
(13, 71),
(15, 73),
(15, 74),
(15, 75),
(16, 76),
(16, 77),
(16, 78),
(17, 79),
(17, 80),
(17, 81),
(19, 84),
(19, 85);

-- --------------------------------------------------------

--
-- Structure de la table `connexion`
--

CREATE TABLE `connexion` (
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `pwd` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `statut` bit(1) NOT NULL DEFAULT b'1',
  `type` enum('M','P','A') COLLATE utf8_unicode_ci NOT NULL,
  `idUser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `connexion`
--

INSERT INTO `connexion` (`email`, `pwd`, `statut`, `type`, `idUser`) VALUES
('admin@gmail.com', '123', b'1', 'A', 2),
('shakira@outlook.com', '123', b'1', 'M', 5),
('test@mail.com', '123', b'1', 'M', 4);

-- --------------------------------------------------------

--
-- Structure de la table `detailscircuit`
--

CREATE TABLE `detailscircuit` (
  `idCircuit` int(11) NOT NULL,
  `dateDebutCircuit` date NOT NULL,
  `dateFinCircuit` date NOT NULL,
  `nbPlaceMin` int(11) NOT NULL,
  `nbPlaceMax` int(11) NOT NULL,
  `montantReservation` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `detailscircuit`
--

INSERT INTO `detailscircuit` (`idCircuit`, `dateDebutCircuit`, `dateFinCircuit`, `nbPlaceMin`, `nbPlaceMax`, `montantReservation`) VALUES
(13, '2019-05-16', '2019-05-31', 5, 5, 5),
(15, '2019-06-01', '2019-06-09', 10, 50, 1000),
(16, '2019-09-01', '2019-07-09', 10, 50, 1500),
(17, '2020-04-01', '2020-04-09', 10, 50, 2000),
(19, '2019-05-23', '2019-05-30', 2, 10, 1000);

-- --------------------------------------------------------

--
-- Structure de la table `detailsreservation`
--

CREATE TABLE `detailsreservation` (
  `idReservation` int(11) NOT NULL,
  `nbAdulte` int(11) NOT NULL,
  `nbEnfant` int(11) NOT NULL,
  `nbBebe` int(11) NOT NULL,
  `nbChambre` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `etape`
--

CREATE TABLE `etape` (
  `idEtape` int(11) NOT NULL,
  `titreEtape` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `descriptionEtape` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `etape`
--

INSERT INTO `etape` (`idEtape`, `titreEtape`, `descriptionEtape`) VALUES
(69, 'etape 1', '<p>Description etape 1</p>'),
(70, 'etape 2 ', '<p>Description etape 2</p>'),
(71, 'etape 3', '<p>Description etape 3</p>'),
(73, 'SYDNEY', '<p>Rendez-vous au bout du monde &agrave; la d&eacute;couverte d&rsquo;une multitude de paysages et de cultures diff&eacute;rentes.</p>'),
(74, 'ALICE SPRINGS', '<p>Au d&eacute;part de Alice Springs, cet autotour classique en voiture vous fera d&eacute;couvrir les sites incontournables du centre rouge : le rocher embl&eacute;matique d\'Uluru et les formations rocheuses.</p>'),
(75, 'PALM COVE', '<p>Palm Cove est une banlieue au bord de la plage de Cairns dans la r&eacute;gion de Cairns, dans le Queensland, en Australie. Il se trouve &agrave; 27 kilom&egrave;tres au nord de la ville de Cairns</p>'),
(76, 'MOSCOU', '<p>Depuis la place Rouge, admirez les coupoles d&rsquo;or du Kremlin et les bulbes multicolores de la cath&eacute;drale Basile-le-Bienheureux, avant de vous arr&ecirc;ter au caf&eacute; Pouchkine.</p>'),
(77, 'ST-PÃ‰TERSBOURG ', '<p><strong>Plongez dans la f&eacute;erie de Saint P&eacute;tersbourg ! Ce mus&eacute;e &agrave; ciel ouvert, compos&eacute; de palais, de mus&eacute;es, d\'avenues colossales</strong>.</p>'),
(78, 'Lac BaÃ¯kal Ã  la carte', '<p>Un voyage exceptionnel pour ceux qui aiment l&rsquo;aventure et les grands paysages glac&eacute;.</p>'),
(79, 'Grand Sud Marocain', '<p>Ce circuit vous fait d&eacute;couvrir le grand sud Marocain, et le d&eacute;sert du Sahara.</p>'),
(80, 'Serengeti', '<p>Pour ressentir l&rsquo;&eacute;motion du safari camping en Tanzanie, c&rsquo;est un passage oblig&eacute; pour tous les voyageurs qui souhaitent d&eacute;couvrir la nature sauvage de la Tanzanie.</p>'),
(81, 'Great Bear Lodge', '<p>R&eacute;nov&eacute; en 2014, le Great Bear Lodge se situe &agrave; 80 kilom&egrave;tres de Port Hardy, au milieu de l\'habitat des ours.</p>'),
(82, 'Scandinave', '<p>Le Danemark, la Su&egrave;de et la Norv&egrave;ge vous offriront une palette incroyable</p>'),
(83, 'Terre-Neuve', '<p>D&eacute;couvrez Terre-Neuve et ses airs de bout du monde. Visitez St. John&rsquo;s, la capitale color&eacute;e et anim&eacute;e.</p>'),
(84, 'Pays nordiques', '<p>Le Danemark, la Su&egrave;de et la Norv&egrave;ge vous offriront une palette incroyable</p>'),
(85, 'Terre-Neuve', '<p>D&eacute;couvrez Terre-Neuve et ses airs de bout du monde</p>');

-- --------------------------------------------------------

--
-- Structure de la table `hebergement`
--

CREATE TABLE `hebergement` (
  `nomHebergement` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lienHebergement` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `idJour` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

--
-- Déchargement des données de la table `hebergement`
--

INSERT INTO `hebergement` (`nomHebergement`, `lienHebergement`, `idJour`) VALUES
('hotel etape 1 jour 1', 'lien hotel etape 1 jour 1', 49),
('hotel etape 1 jour 2', 'lien hotel etape 1 jour 2', 50),
('hotel etape 1 jour 3', 'lien hotel etape 1 jour 3', 51),
('hotel etape 2 jour 1', 'lien hotel etape 2 jour 1', 52),
('hotel etape 2 jour 2', 'lien hotel etape 2 jour 2', 53),
('hotel etape 2 jour 3', 'lien hotel etape 2 jour 3', 54),
('hotel etape 3 jour 1', 'lien hotel etape 3 jour 1', 55),
('hotel etape 3 jour 2', 'lien hotel etape 3 jour 2', 56),
('hotel etape 3 jour 3', 'lien hotel etape 3 jour 3', 57),
('Pan Pacific', 'https://www.panpacific.com/en.html', 61),
('Pan Pacific', 'https://www.panpacific.com/en.html', 62),
('Rydges Sydney Central', 'https://www.rydges.com/accommodation/sydney-nsw/sydney-central/', 63),
('Primus Hotel Sydney', 'https://www.primushotelsydney.com/', 64),
('Primus Hotel Sydney', 'https://www.primushotelsydney.com/', 65),
('Lofthouse Bed and Breakfast', 'https://www.tripadvisor.ca/Hotel_Review-g552097-d292484-Reviews-Lofthouse_Bed_and_Breakfast-Greenwich_Lane_Cove_Greater_Sydney_New_South_Wales.html', 66),
('Lofthouse Bed and Breakfast', 'https://www.tripadvisor.ca/Hotel_Review-g552097-d292484-Reviews-Lofthouse_Bed_and_Breakfast-Greenwich_Lane_Cove_Greater_Sydney_New_South_Wales.html', 67),
('Lofthouse Bed and Breakfast', 'https://www.tripadvisor.ca/Hotel_Review-g552097-d292484-Reviews-Lofthouse_Bed_and_Breakfast-Greenwich_Lane_Cove_Greater_Sydney_New_South_Wales.html', 68),
('Ritz-Carlton', 'http://www.ritzcarlton.com/en/hotels/europe/moscow', 69),
('Ritz-Carlton', 'http://www.ritzcarlton.com/en/hotels/europe/moscow', 70),
('Ritz-Carlton', 'http://www.ritzcarlton.com/en/hotels/europe/moscow', 71),
('Hotel Histoire', 'https://www.taleonimperialhotel.com/ru/%D0%BE%D1%82%D0%B5%D0%BB%D1%8C#/tab-1', 72),
('Hotel Histoire', 'https://www.taleonimperialhotel.com/ru/%D0%BE%D1%82%D0%B5%D0%BB%D1%8C#/tab-1', 73),
('Hotel Histoire', 'https://www.taleonimperialhotel.com/ru/%D0%BE%D1%82%D0%B5%D0%BB%D1%8C#/tab-1', 74),
('Zvezda', 'https://www.zvezdahotel.ru/en/', 75),
('Zvezda', 'https://www.zvezdahotel.ru/en/', 76),
('Zvezda', 'https://www.zvezdahotel.ru/en/', 77),
('chambre d\'hÃ´te ou hÃ´tel de charme selon disponiblitÃ©s', 'vide', 78),
('Diner et nuit dans le dÃ©sert, sous les tentes nomades au bivouac.', 'vide', 79),
('DÃ®ner et nuit en hÃ´tel de charme ou chambre d\'hÃ´te typique', 'vide', 80),
('DÃ®ner et nuit au camping Seronera Ã  l\'intÃ©rieur du parc.', 'vide', 81),
('DÃ®ner et nuit au camping Seronera', 'vide', 82),
('hotel Arusha', 'vide', 83),
('DÃ©jeuner et nuit au Great Bear Lodge.', 'vide', 84),
('DÃ©jeuner et nuit au Great Bear Lodge', 'vide', 85),
('DÃ©jeuner et nuit Ã  Port Hardy', 'vide', 86),
('avion', '#', 87),
('hotel-mayfair', 'https://www.booking.com/hotel/dk/first-hotel-mayfair.fr.html', 88),
('first-hotel-mayfair', 'https://www.booking.com/hotel/dk/first-hotel-mayfair.fr.html', 90),
('first-hotel-mayfair', 'https://www.booking.com/hotel/dk/first-hotel-mayfair.fr.html', 91),
('first-hotel-mayfair', 'https://www.booking.com/hotel/dk/first-hotel-mayfair.fr.html', 92),
('first-hotel-mayfair.', 'https://www.booking.com/hotel/dk/first-hotel-mayfair.fr.html', 93);

-- --------------------------------------------------------

--
-- Structure de la table `historique`
--

CREATE TABLE `historique` (
  `nom` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `prenom` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `age` int(11) NOT NULL,
  `sexe` enum('M','F') COLLATE utf8_unicode_ci NOT NULL,
  `dateVoyage` date NOT NULL,
  `titreCircuit` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `montant` double NOT NULL,
  `nbParticipant` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `jour`
--

CREATE TABLE `jour` (
  `idJour` int(11) NOT NULL,
  `titreJour` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descriptionJour` text COLLATE utf8_unicode_ci,
  `idEtape` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `jour`
--

INSERT INTO `jour` (`idJour`, `titreJour`, `descriptionJour`, `idEtape`) VALUES
(49, 'titre', 'description', 69),
(50, 'titre', 'description', 69),
(51, 'titre', 'description', 69),
(52, 'titre', 'description', 70),
(53, 'titre', 'description', 70),
(54, 'titre', 'description', 70),
(55, 'titre', 'description', 71),
(56, 'titre', 'description', 71),
(57, 'titre', 'description', 71),
(61, 'titre', 'description', 73),
(62, 'titre', 'description', 73),
(63, 'titre', 'description', 73),
(64, 'titre', 'description', 74),
(65, 'titre', 'description', 74),
(66, 'titre', 'description', 75),
(67, 'titre', 'description', 75),
(68, 'titre', 'description', 75),
(69, 'titre', 'description', 76),
(70, 'titre', 'description', 76),
(71, 'titre', 'description', 76),
(72, 'titre', 'description', 77),
(73, 'titre', 'description', 77),
(74, 'titre', 'description', 77),
(75, 'titre', 'description', 78),
(76, 'titre', 'description', 78),
(77, 'titre', 'description', 78),
(78, 'titre', 'description', 79),
(79, 'titre', 'description', 79),
(80, 'titre', 'description', 79),
(81, 'titre', 'description', 80),
(82, 'titre', 'description', 80),
(83, 'titre', 'description', 80),
(84, 'titre', 'description', 81),
(85, 'titre', 'description', 81),
(86, 'titre', 'description', 81),
(87, 'titre', 'description', 82),
(88, 'titre', 'description', 82),
(89, 'titre', 'description', 83),
(90, 'titre', 'description', 84),
(91, 'titre', 'description', 84),
(92, 'titre', 'description', 85),
(93, 'titre', 'description', 85);

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

CREATE TABLE `message` (
  `idMessage` int(11) NOT NULL,
  `titreMessage` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `texteMessage` text COLLATE utf8_unicode_ci NOT NULL,
  `dateMessage` datetime NOT NULL,
  `idUser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `message`
--

INSERT INTO `message` (`idMessage`, `titreMessage`, `texteMessage`, `dateMessage`, `idUser`) VALUES
(4, 'message test', 'hello world !', '2019-05-21 02:02:52', 2),
(5, 'salut', 'salut', '2019-05-21 12:10:00', 2);

-- --------------------------------------------------------

--
-- Structure de la table `paiement`
--

CREATE TABLE `paiement` (
  `idPaiement` int(11) NOT NULL,
  `datePaiement` date NOT NULL,
  `montantPaiement` double NOT NULL,
  `typePaiement` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `idReservation` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `participant`
--

CREATE TABLE `participant` (
  `nom` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `prenom` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dateNaissanceParticipant` date NOT NULL,
  `sexe` enum('M','F') COLLATE utf8_unicode_ci NOT NULL,
  `idReservation` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `pension`
--

CREATE TABLE `pension` (
  `nomPension` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lienPension` varchar(200) CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `idJour` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

--
-- Déchargement des données de la table `pension`
--

INSERT INTO `pension` (`nomPension`, `lienPension`, `idJour`) VALUES
('restaurant etape 1 jour 1', 'lien restaurant etape 1 jour 1', 49),
('restaurant etape 1 jour 2', 'lien restaurant etape 1 jour 2', 50),
('restaurant etape 1 jour 3', 'lien restaurant etape 1 jour 3', 51),
('restaurant etape 2 jour 1', 'lien restaurant etape 2 jour 1', 52),
('restaurant etape 2 jour 2', 'lien restaurant etape 2 jour 2', 53),
('restaurant etape 2 jour 3', 'lien restaurant etape 2 jour 3', 54),
('restaurant etape 3 jour 1', 'lien restaurant etape 3 jour 1', 55),
('restaurant etape 3 jour 2', 'lien restaurant etape 3 jour 2', 56),
('restaurant etape 3 jour 3', 'lien restaurant etape 3 jour 3', 57),
('Farmhouse Kingscross', 'http://farmhousekingscross.com.au/', 61),
('The Gantry', 'https://www.thegantry.com.au/', 62),
('The Grand Pavilion', 'https://www.thegrandpavilion.com.au/', 63),
('Gozleme King', 'http://www.gozlemeking.com.au/', 64),
('China Town Noodle King', 'http://www.chinatownnoodleking.com/', 65),
('Four Frogs CrÃªperie', 'https://www.fourfrogs.com.au/', 66),
('Four Frogs CrÃªperie', 'https://www.fourfrogs.com.au/', 67),
('Four Frogs CrÃªperie', 'https://www.fourfrogs.com.au/', 68),
('Metropol', 'https://metropol-moscow.ru/en/restaurants/', 69),
('Metropol', 'https://metropol-moscow.ru/en/restaurants/', 70),
('Metropol', 'https://metropol-moscow.ru/en/restaurants/', 71),
('Staraya Tamozhnya', 'http://oldcustom.ru/en/', 72),
('Troika', 'https://www.troikaspb.ru/en/', 73),
('Staraya Tamozhnya', 'http://oldcustom.ru/en/', 74),
('Ðž Ð ectopahe', 'http://restoranohotnikov.ru/', 75),
('Ðž Ð ectopahe', 'http://restoranohotnikov.ru/', 76),
('Ðž Ð ectopahe', 'http://restoranohotnikov.ru/', 77),
('chambre d\'hÃ´te ou hÃ´tel de charme selon disponiblitÃ©s', 'vide', 78),
('Diner et nuit dans le dÃ©sert, sous les tentes nomades au bivouac.', 'vide', 79),
('DÃ®ner et nuit en hÃ´tel de charme ou chambre d\'hÃ´te typique', 'vide', 80),
('DÃ®ner et nuit au camping Seronera Ã  l\'intÃ©rieur du parc.', 'vide', 81),
('DÃ®ner et nuit au camping Seronera', 'vide', 82),
('restaurant Arusha', 'vide', 83),
('DÃ©jeuner et nuit au Great Bear Lodge.', 'vide', 84),
('DÃ©jeuner et nuit au Great Bear Lodge', 'vide', 85),
('DÃ©jeuner et nuit Ã  Port Hardy', 'vide', 86),
('avion', '#', 87),
('hotel-mayfair', 'https://www.booking.com/hotel/dk/first-hotel-mayfair.fr.html', 88),
('first-hotel-mayfair', 'https://www.booking.com/hotel/dk/first-hotel-mayfair.fr.html', 90),
('first-hotel-mayfair', 'https://www.booking.com/hotel/dk/first-hotel-mayfair.fr.html', 91),
('first-hotel-mayfair', 'https://www.booking.com/hotel/dk/first-hotel-mayfair.fr.html', 92),
('first-hotel-mayfair.', 'https://www.booking.com/hotel/dk/first-hotel-mayfair.fr.html', 93);

-- --------------------------------------------------------

--
-- Structure de la table `promotion`
--

CREATE TABLE `promotion` (
  `idPromotion` int(11) NOT NULL,
  `pourcentagePromotion` double NOT NULL,
  `titrePromotion` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dateDebutPromotion` date NOT NULL,
  `dateFinPromotion` date NOT NULL,
  `idCircuit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `rabais`
--

CREATE TABLE `rabais` (
  `idRabais` int(11) NOT NULL,
  `montantRabais` double NOT NULL,
  `titreRabais` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dateDebutRabais` datetime NOT NULL,
  `dateFinRabais` datetime NOT NULL,
  `idUser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `reservation`
--

CREATE TABLE `reservation` (
  `idReservation` int(11) NOT NULL,
  `montantTotal` double NOT NULL,
  `PourcentageAcompte` double DEFAULT NULL,
  `annulation` bit(1) NOT NULL DEFAULT b'0',
  `dateReservation` datetime NOT NULL,
  `idUser` int(11) NOT NULL,
  `idCircuit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `tarif`
--

CREATE TABLE `tarif` (
  `idCircuit` int(11) NOT NULL,
  `prixBebe` double NOT NULL,
  `prixEnfant` double NOT NULL,
  `prixAdulte` double NOT NULL,
  `prixChambre` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `tarif`
--

INSERT INTO `tarif` (`idCircuit`, `prixBebe`, `prixEnfant`, `prixAdulte`, `prixChambre`) VALUES
(15, 0, 1000, 5000, 500),
(19, 0, 500, 1000, 200);

-- --------------------------------------------------------

--
-- Structure de la table `test`
--

CREATE TABLE `test` (
  `idTest` int(11) NOT NULL,
  `titre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `bit` bit(1) DEFAULT b'0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `idUser` int(11) NOT NULL,
  `nomUser` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `prenomUser` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sexe` enum('M','F') CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `dateNaissance` date NOT NULL,
  `dateInscription` datetime NOT NULL,
  `panier` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`idUser`, `nomUser`, `prenomUser`, `sexe`, `dateNaissance`, `dateInscription`, `panier`) VALUES
(2, 'Fian', 'Benjamin', 'M', '1982-09-09', '2019-05-20 00:00:00', NULL),
(4, 'test', 'test', 'M', '2019-05-01', '2019-05-21 12:19:30', '0'),
(5, 'shakira', 'chanteuse', 'F', '1995-04-13', '2019-05-21 12:55:25', '0');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `activite`
--
ALTER TABLE `activite`
  ADD KEY `idJour` (`idJour`);

--
-- Index pour la table `circuit`
--
ALTER TABLE `circuit`
  ADD PRIMARY KEY (`idCircuit`);

--
-- Index pour la table `circuit_etape`
--
ALTER TABLE `circuit_etape`
  ADD KEY `idCircuit` (`idCircuit`),
  ADD KEY `idEtape` (`idEtape`);

--
-- Index pour la table `connexion`
--
ALTER TABLE `connexion`
  ADD PRIMARY KEY (`email`),
  ADD KEY `idUser` (`idUser`);

--
-- Index pour la table `detailscircuit`
--
ALTER TABLE `detailscircuit`
  ADD KEY `idCircuit` (`idCircuit`);

--
-- Index pour la table `detailsreservation`
--
ALTER TABLE `detailsreservation`
  ADD KEY `idReservation` (`idReservation`);

--
-- Index pour la table `etape`
--
ALTER TABLE `etape`
  ADD PRIMARY KEY (`idEtape`);

--
-- Index pour la table `hebergement`
--
ALTER TABLE `hebergement`
  ADD KEY `idJour` (`idJour`);

--
-- Index pour la table `jour`
--
ALTER TABLE `jour`
  ADD PRIMARY KEY (`idJour`),
  ADD KEY `idEtape` (`idEtape`);

--
-- Index pour la table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`idMessage`),
  ADD KEY `idUser` (`idUser`);

--
-- Index pour la table `paiement`
--
ALTER TABLE `paiement`
  ADD PRIMARY KEY (`idPaiement`),
  ADD KEY `idReservation` (`idReservation`);

--
-- Index pour la table `participant`
--
ALTER TABLE `participant`
  ADD KEY `idReservation` (`idReservation`);

--
-- Index pour la table `pension`
--
ALTER TABLE `pension`
  ADD KEY `idJour` (`idJour`);

--
-- Index pour la table `promotion`
--
ALTER TABLE `promotion`
  ADD PRIMARY KEY (`idPromotion`),
  ADD KEY `idCircuit` (`idCircuit`);

--
-- Index pour la table `rabais`
--
ALTER TABLE `rabais`
  ADD PRIMARY KEY (`idRabais`),
  ADD KEY `idUser` (`idUser`);

--
-- Index pour la table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`idReservation`),
  ADD KEY `idUser` (`idUser`),
  ADD KEY `idCircuit` (`idCircuit`);

--
-- Index pour la table `tarif`
--
ALTER TABLE `tarif`
  ADD KEY `idCircuit` (`idCircuit`);

--
-- Index pour la table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`idTest`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`idUser`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `circuit`
--
ALTER TABLE `circuit`
  MODIFY `idCircuit` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT pour la table `etape`
--
ALTER TABLE `etape`
  MODIFY `idEtape` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;
--
-- AUTO_INCREMENT pour la table `jour`
--
ALTER TABLE `jour`
  MODIFY `idJour` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;
--
-- AUTO_INCREMENT pour la table `message`
--
ALTER TABLE `message`
  MODIFY `idMessage` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `promotion`
--
ALTER TABLE `promotion`
  MODIFY `idPromotion` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `rabais`
--
ALTER TABLE `rabais`
  MODIFY `idRabais` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `idReservation` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `test`
--
ALTER TABLE `test`
  MODIFY `idTest` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `activite`
--
ALTER TABLE `activite`
  ADD CONSTRAINT `activite_ibfk_1` FOREIGN KEY (`idJour`) REFERENCES `jour` (`idJour`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `circuit_etape`
--
ALTER TABLE `circuit_etape`
  ADD CONSTRAINT `circuit_etape_ibfk_1` FOREIGN KEY (`idCircuit`) REFERENCES `circuit` (`idCircuit`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `circuit_etape_ibfk_2` FOREIGN KEY (`idEtape`) REFERENCES `etape` (`idEtape`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `connexion`
--
ALTER TABLE `connexion`
  ADD CONSTRAINT `connexion_ibfk_1` FOREIGN KEY (`idUser`) REFERENCES `user` (`idUser`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `detailscircuit`
--
ALTER TABLE `detailscircuit`
  ADD CONSTRAINT `detailscircuit_ibfk_1` FOREIGN KEY (`idCircuit`) REFERENCES `circuit` (`idCircuit`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `detailsreservation`
--
ALTER TABLE `detailsreservation`
  ADD CONSTRAINT `detailsreservation_ibfk_1` FOREIGN KEY (`idReservation`) REFERENCES `reservation` (`idReservation`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `hebergement`
--
ALTER TABLE `hebergement`
  ADD CONSTRAINT `hebergement_ibfk_1` FOREIGN KEY (`idJour`) REFERENCES `jour` (`idJour`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `jour`
--
ALTER TABLE `jour`
  ADD CONSTRAINT `jour_ibfk_1` FOREIGN KEY (`idEtape`) REFERENCES `etape` (`idEtape`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `message`
--
ALTER TABLE `message`
  ADD CONSTRAINT `message_ibfk_1` FOREIGN KEY (`idUser`) REFERENCES `user` (`idUser`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `paiement`
--
ALTER TABLE `paiement`
  ADD CONSTRAINT `paiement_ibfk_1` FOREIGN KEY (`idReservation`) REFERENCES `reservation` (`idReservation`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `participant`
--
ALTER TABLE `participant`
  ADD CONSTRAINT `participant_ibfk_1` FOREIGN KEY (`idReservation`) REFERENCES `reservation` (`idReservation`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `pension`
--
ALTER TABLE `pension`
  ADD CONSTRAINT `pension_ibfk_1` FOREIGN KEY (`idJour`) REFERENCES `jour` (`idJour`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `promotion`
--
ALTER TABLE `promotion`
  ADD CONSTRAINT `promotion_ibfk_1` FOREIGN KEY (`idCircuit`) REFERENCES `circuit` (`idCircuit`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `rabais`
--
ALTER TABLE `rabais`
  ADD CONSTRAINT `rabais_ibfk_1` FOREIGN KEY (`idUser`) REFERENCES `user` (`idUser`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`idUser`) REFERENCES `user` (`idUser`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`idCircuit`) REFERENCES `circuit` (`idCircuit`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `tarif`
--
ALTER TABLE `tarif`
  ADD CONSTRAINT `tarif_ibfk_1` FOREIGN KEY (`idCircuit`) REFERENCES `circuit` (`idCircuit`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
