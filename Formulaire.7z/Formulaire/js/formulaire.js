var nbJour; //jour
var nbEtape;
function afficherEtapes(){
    var colRight=document.getElementById("colRight");
    $('#colRight').append('<button type="button" class="btn btn-primary" onclick="ajouterEtape();">Ajouter étape</button>');
}

function ajouterEtape(){
   
    
    var colRight=document.getElementById("colRight");
    $('#colRight').append('<div class="card" id="card"></div>');
    var card=document.getElementById("card");
  //  alert(card.innerHTML);
    nbEtape=card.childElementCount;
    nbEtape++;

    $('#card').append('<div><button class="accordion" onclick="ajouter();">Étape '+nbEtape+'</button><div class="panel"><form method="POST" id="etape'+nbEtape+'">  <input type="text" class="form-control input-md" value="" placeholder="Titre" size="30"><br> <br> Description<br> <textarea></textarea> <br /> Image <input type="file" name="name" multiple><br> <button type="button" class="btn btn-primary">Sauvgarder étape</button></form><button id="ajouterJour'+nbEtape+'" onclick="ajouterJour('+nbEtape+');">Ajouter jour</button><ul class="nav nav-tabs" id="tabs'+nbEtape+'"></ul> </div><div class="tab-content border" id="unJourEtape'+nbEtape+'"></div></div></div>');
  //  alert(document.getElementById("card").innerHTML);
   // alert(card.innerHTML);
}

function ajouter(){
    var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";
    } else {
      panel.style.display = "block";
    }
  });
}
}

function ajouterJour(etape){
    var tabs=document.getElementById("tabs"+etape);
 //   alert(tabs);
    nbJour=tabs.childElementCount;
    nbJour++;
//    alert(etape);
   
   $('#tabs'+etape).append('<li class="nav-item"> <a class="nav-link jourClass" href="javascript:showJour(event,'+nbJour+','+etape+');"></a>Jour'+nbJour+' </li>');
  // alert();
   var unJourEtape=document.getElementById("unJourEtape"+etape);
   alert(unJourEtape.innerHTML);
    $('#unJourEtape'+etape).append('<div id="unJour'+nbJour+'" class="cont'+etape+' tab-pane"><br><form method="POST" id="jour'+nbJour+'"><input type="text"  class="form-control input-md" size="" placeholder="Nom d\'hotel">  <input type="text" value="" class="form-control input-md" size="" placeholder="Lien d\'hotel"><br><br><input type="text" value="" class="form-control input-md" size="" placeholder="Nom de restaurant"> <input type="text" value="" class="form-control input-md" size="" placeholder="Lien de restaurant"><br><br>Activités:<br><textarea></textarea> <br /><button type="button" class="btn btn-primary">Sauvgarder jour</button><button type="button" class="btn btn-primary">Supprimer</button></form></div>');
   // alert(unJour.innerHTML);
 //   $('#unJour'+nbJour).addClass("active");
    showJour(event,nbJour,etape);
}

function showJour(event,jour,etape){
   
var cont=document.getElementsByClassName("cont"+etape);
var jourClass=document.getElementsByClassName("jourClass");
//alert(document.getElementById("unJour"+jour).innerHTML);
//alert(cont.length);
for (i = 0; i < cont.length; i++) {
    cont[i].style.display = "none";
}
//alert(cont.length);
  for (i = 0; i < jourClass.length; i++) {
    jourClass[i].className = jourClass[i].className.replace(" active", " fade ");
  }
  document.getElementById("unJour"+jour).style.display = "block";
  event.currentTarget.className += " active";
}

