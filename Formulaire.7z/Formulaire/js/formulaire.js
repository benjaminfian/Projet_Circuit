var nbEtape, nbJour;

/****** */
function textarea(){
$(document).ready(function() {
   tinymce.init({
     selector: "textarea",
     theme: "modern",
     paste_data_images: true,
     plugins: [
       "advlist autolink lists link image charmap print preview hr anchor pagebreak",
       "searchreplace wordcount visualblocks visualchars code fullscreen",
       "insertdatetime media nonbreaking save table contextmenu directionality",
       "emoticons template paste textcolor colorpicker textpattern"
     ],
     toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
     toolbar2: "print preview media | forecolor backcolor emoticons",
     image_advtab: true,
     file_picker_callback: function(callback, value, meta) {
       if (meta.filetype == 'image') {
         $('#upload').trigger('click');
         $('#upload').on('change', function() {
           var file = this.files[0];
           var reader = new FileReader();
           reader.onload = function(e) {
             callback(e.target.result, {
               alt: ''
             });
           };
           reader.readAsDataURL(file);
         });
       }
     },
     templates: [{
       title: 'Test template 1',
       content: 'Test 1'
     }, {
       title: 'Test template 2',
       content: 'Test 2'
     }]
   });
 });
}
/****** */
function openCircuit(evt, etapeCreation) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(etapeCreation).style.display = "block";
  evt.currentTarget.className += " active";
}

function saveCircuit() {
  var save = document.getElementById("save");
  $('#save').attr("disabled", true);
  $('#ajouteEtape').attr("disabled", false);
  $('#btnTarifs').attr("disabled", false);
  $('#btnPromo').attr("disabled", false);
}



function afficherEtapes() {

  if (document.getElementById("loading")) document.getElementById("loading").remove();
  var colRight = document.getElementById("colRight");
  nbEtape = colRight.childElementCount;
  //    alert(nbEtape);
  nbEtape++;
  $('#colRight').append('<div><button class="accordion" onclick="openEtape();" >Étape' + nbEtape + '</button> <div class="panel"><form method="POST" id="etape' + nbEtape + '"> <br> <input type="text" class="form-control input-md" value="" placeholder="Titre" size="30"><br><textarea name="" id="" cols="30" rows="10" >Description</textarea> <br /> Image <input type="file" name="name" multiple><br><br> <div class="row"><div class="col col-6"><button type="button" class="btn btn-primary" id="saveEtape' + nbEtape + '" onclick="saveEtape(' + nbEtape + ');"> Continuer</button></div><div class="col col-6"><button class="btn btn-primary" type="button" id="ajouterJour' + nbEtape + '" disabled onclick="ajouterJour(' + nbEtape + ');">Ajouter jour</button><br> </div></div></form></div></div>');
  textarea();

}
function saveEtape(etape) {
  $('#saveEtape' + etape).attr("disabled", true);
  $('#ajouterJour' + etape).attr("disabled", false);
  $('#etape' + etape).after('<br><div class="tab" id="linkJour' + etape + '"></div>');
}
function ajouterJour(etape) {

  // $('#etape' + etape).after('<br><div class="tab" id="tabJour' + etape + '"></div>');
  var tabJour = document.getElementById("linkJour" + etape);
  nbJour = tabJour.childElementCount;
  nbJour++;

  $('#linkJour' + etape).append('<button id="tabJour' + nbJour + '" class="tablink' + etape + ' active" onclick="openJour(event,' + nbJour + ',' + etape + ')">Jour' + nbJour + '</button>');

  $('#linkJour' + etape).after('<div id="jour' + etape + nbJour + '" style="display:block;" class="tabcont' + etape + '"><form method="POST" id="formJour' + nbJour + '"> <div class="row">        <div class="col col-12"> <textarea name="" id="" cols="30" rows="10" >Description</textarea> <br></div> </div><div class="row"> <div class="col col-8"> <input type="text" class="form-control input-md" size="" placeholder="Nom d\'hotel"> <br>       </div> <div class="col col-4"></div> </div> <div class="row">        <div class="col col-8"><input type="text" value="" class="form-control input-md" placeholder="Lien d\'hotel"><br> </div> <div class="col col-4"> <button type="button" id="jourSup' + etape + nbJour + '" class="btn btn-primary" onclick="supprimerJour(' + etape + ',' + nbJour + ');">Supprimer</button></div>    </div> <div class="row"> <div class="col col-8"> <input type="text" value="" class="form-control input-md" placeholder="Nom de restaurant"> <br></div> <div class="col col-4"></div> </div> <div class="row"><div class="col col-8"> <input type="text" value="" class="form-control input-md" placeholder="Lien de restaurant">   <br>     </div> <div class="col col-4"> <button type="button" class="btn btn-primary">Sauvgarder jour</button> </div> </div></form></div>');
textarea();
  openJour(event, nbJour, etape);
}
function openJour(event, jour, etape) {
  var i, tabcont, tablink;

  tabcont = document.getElementsByClassName("tabcont" + etape);
  for (i = 0; i < tabcont.length; i++) {
      tabcont[i].style.display = "none";
  }
  tablink = document.getElementsByClassName("tablink" + etape);
  for (i = 0; i < tablink.length; i++) {
      tablink[i].className = tablink[i].className.replace(" active", "");
  }
  document.getElementById("jour" + etape + jour).style.display = "block";
  event.currentTarget.className += " active";
}

function supprimerJour(etape, jour) {

  document.getElementById("jour" + etape + jour).remove();
  tablink = document.getElementsByClassName("tablink" + etape);
  for (i = 0; i < tablink.length; i++) {
      if (tablink[i].id == "tabJour" + jour) {
          document.getElementById("tabJour" + jour).remove();
      }
  }

}
function openEtape() {
  var acc = document.getElementsByClassName("accordion");
  var i;
  for (i = 0; i < acc.length; i++) {
      acc[i].addEventListener("click", function () {
          this.classList.toggle("active");

          var panel = this.nextElementSibling;
          if (panel.style.display === "block") {
              panel.style.display = "none";
          } else {
              panel.style.display = "block";
          }
      });
  }

}