var idCircuit,idEtape,codeCircuit;
//vue Circuit

function listeCircuits(reponse)
{
    $('#contenu').html("");
    var rep = '<div class="row marge-gauche custom-center">\
        <div class="col-sm-12 col-md-10 col-md-offset-1 custom-center"><br>\
            <button type="button" class="btn btn-success marge-bas" onclick="nouveauCircuit()">Ajouter un circuit</button>\
            <table class="table table-hover table-striped">\
                <thead>\
                    <tr>\
                        <th>image</th>\
                        <th class="text-center">Titre</th>\
                        <th class="text-center">Nombre d\'étapes</th>\
                        <th class="text-center">Date de début</th>\
                        <th class="text-center">Date de fin</th>\
                        <th class="text-center">Prix</th>\
                        <th></th><th></th><th></th></tr>\
                </thead>\
                <tbody>';    
    for (var i =0; i < reponse.listeCircuits.length; i++)
    {          
        rep +=  '<tr>\
                    <td width=\"8%\">\
                        <div class="media">\
                                <img class="img_crud" src="'+reponse.listeImages[i]+'" alt="Circuit '+reponse.listeCircuits[i].idCircuit+'" title="image du circuit'+reponse.listeCircuits[i].titreCircuit+'">\
                        </div>\
                    </td>\
                    <td class="text-center"><strong>'+reponse.listeCircuits[i].titreCircuit+'</strong></td>\
                    <td class="text-center"><strong>'+reponse.listeCircuits[i].nbEtape+'</strong></td>\
                    <td class="text-center"><strong>'+reponse.listeCircuits[i].dateDebutCircuit+'</strong></td>\
                    <td class="text-center"><strong>'+reponse.listeCircuits[i].dateDebutCircuit+'</strong></td>\
                    <td class="text-center"><strong>'+reponse.listeCircuits[i].prixCircuit+' $</strong></td>';
        if (reponse.listeCircuits[i].etat == 0)
        {
            rep += '<td class="text-center"><button type="button" class="btn btn-success"\ onclick="obtenirFicheCircuit('+reponse.listeCircuits[i].idCircuit+')\">Modifier</button></td>\
                    <td class="text-center"><button type="button" class="btn btn-danger"\ onclick="supprimerCircuit('+reponse.listeCircuits[i].idCircuit+')\">Supprimer</button></td>\
                    <td class="text-center"><button type="button" class="btn btn-primary"\ onclick="activerCircuit('+reponse.listeCircuits[i].idCircuit+')\">Activer</button></td></tr>';    
        }
        else
        {
            rep += '<td></td><td></td>\
                    <td class="text-center"><button type="button" class="btn btn-secondary" onclick="desactiverCircuit('+reponse.listeCircuits[i].idCircuit+')\">Desactiver</button></td></tr>';    
        }                    
    }    
    rep += '</tbody></table></div></div></div>';
    $('#contenu').html(rep);
}

function listeCircuitsClient(reponse)
{
    $('#listeCircuits').html(""); 
    var rep = '<div class="row">';
    for (var i =0; i < reponse.listeCircuits.length; i++)
    {        
          rep += '<div class="col-md-6 col-lg-4 mb-4 mb-lg-4">\
            <a href="#" class="unit-1 text-center" onclick="ouvrirEtapes('+reponse.listeCircuits[i].idCircuit+')">\
              <img src="'+reponse.listeImages[i]+'" alt="Image" class="img-fluid">\
              <div class="unit-1-text">\
                <h3><strong class="text-primary mb-2 d-block">'+reponse.listeCircuits[i].prixCircuit+'$</strong></h3>\
                <h3 class="unit-1-heading">'+reponse.listeCircuits[i].titreCircuit+'</h3>\
              </div>\
            </a>\
          </div>';
    }
    rep += '</div>';
    $('#listeCircuits').html(rep);
}

function listeEtapes(reponse)
{
    $('#listeEtapes').html("");
    var rep = '<div class="site-blocks-cover inner-page-cover" style="background-image: url(images/hero_bg_2.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">\
        <div class="container">\
          <div class="row align-items-center justify-content-center text-center">\
            <div class="col-md-8" data-aos="fade-up" data-aos-delay="400">\
              <h1 class="text-white font-weight-light">Circuit</h1>\
              <p class="text-white lead">&ldquo;Découvrez les circuits accompagnés par VaresAnto, une formule pour voyager en toute tranquillité ! Élaborés par nos experts, ils s’appuient sur un réseau de partenaires et de guides sélectionnés pour leurs connaissances et leur professionnalisme.&rdquo;</p>\
              <p class="mb-5"></p>\
                  <a class="btn btn-primary py-3 px-5 text-white" href="images/01-greece.jpg" data-lightbox="imgGLR">Galerie</a>\
                  <a href="images/02-rome.jpg" data-lightbox="imgGLR"></a>\
                  <a href="images/03-japan.jpg" data-lightbox="imgGLR"></a>\
                  <a href="images/04-dubai.jpg" data-lightbox="imgGLR"></a>\
                  <a href="images/circuit_img1.jpg" data-lightbox="imgGLR"></a>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div class="site-section">\
          <div class="container">\
              <nav class="nav nav-pills nav-fill">\
                  <a class="nav-item nav-link btn-primary active" href="#pE1" data-toggle="tab" onclick="showEtape();">Etape 1</a>\
                  <a class="nav-item nav-link btn-primary" href="#pE2" data-toggle="tab" onclick="showEtape();">Etape 2</a>\
                  <a class="nav-item nav-link btn-primary" href="#pE3" data-toggle="tab" onclick="showEtape();">Etape 3</a>\
                  <a class="nav-item nav-link btn-primary" href="#pE4" data-toggle="tab" onclick="showEtape();">Etape 4</a>\
                </nav>\
                <div class="tab-content">\
                  <div class="tab-pane active" id="pE1"><p class="mb-5"></p>Panneau 1\
                    <div class="boxes row">\
                        <div class="col-md-4">\
                          <div class="grid_4">\
                            <figure>\
                              <div><img src="images/circuit_img1.jpg" alt=""></div>\
                              <figcaption>\
                                <h3>Venice</h3>\
                                Lorem ipsum dolor site geril amet, consectetur cing eliti. Suspendisse nulla leo mew dignissim eu velite a rew qw vehicula lacinia arcufasec ro. Aenean lacinia ucibusy fase tortor ut feugiat. Rabi tur oliti aliquam bibendum olor quis malesuadivamu. </figcaption>\
                            </figure>\
                          </div>\
                        </div>\
                        <div class="col-md-8">\
                            <nav class="nav nav-tabs">\
                                <a class="nav-item nav-link active" href="#pJ1" data-toggle="tab">Jour 1</a>\
                                <a class="nav-item nav-link" href="#pJ2" data-toggle="tab">Jour 2</a>\
                              </nav>\
                              <div class="tab-content">\
                                <div class="tab-pane active" id="pJ1">Panneau 1</div>\
                                <div class="tab-pane" id="pJ2">Panneau 2</div>\
                              </div>\
                        </div>\
                      </div>\
                  </div>\
                  <div class="tab-pane" id="pE2"><p class="mb-5"></p>Panneau 2</div>\
                  <div class="tab-pane" id="pE3"><p class="mb-5"></p>Panneau 3</div>\
                  <div class="tab-pane" id="pE4"><p class="mb-5"></p>Panneau 4</div>\
                </div>\
    </div>\
  </div>';
    $('#listeEtapes').html(rep);
}

function afficheFiche(reponse)
{
    $('#contenu').html("");
    var uneFiche;
    if(reponse.OK)
    {
        uneFiche=reponse.circuit;
        var test = JSON.stringify(uneFiche);
        /*$('#formFicheF h3:first-child').html("Fiche du film numero "+uneFiche.idf);
        $('#idf').val(uneFiche.idf);
        $('#titreF').val(uneFiche.titre);
        $('#dureeF').val(uneFiche.duree);
        $('#resF').val(uneFiche.res);
        $('#divFormFiche').show();
        document.getElementById('divFormFiche').style.display='block';*/
    }
    else
    {
        /*$('#messages').html("Film "+$('#numF').val()+" introuvable");
        setTimeout(function(){ $('#messages').html(""); }, 5000);*/
    }
    $('#contenu').html(rep);
}

var circuitsVue=function(reponse)
{
	var action = reponse.action;    
	switch(action)
    {
		case "enregistrer" :
            if(reponse.idCircuit)
            {
                idCircuit = reponse.idCircuit;
                saveCircuit();
                //alert(idCircuit);                
            }                
            if(reponse.idEtape)
            {
                idEtape = reponse.idEtape;
                saveEtape(nbEtape);
                $('#ajouteEtape').attr("disabled", false);
                
                //ajouterJour(nbEtape);
                
                //alert(idEtape);                
            }            
            if(reponse.msgTarif)
            {
                alert(reponse.msgTarif);
                $('#msgTarif').html("");
                $('#msgTarif').html(reponse.msgTarif);
            }
            if(reponse.msgPromotion)
            {
                $('#msgPromotion').html("");
                $('#msgPromotion').html(reponse.msgPromotion);
            }
            if(reponse.msgJour)
            {
                $('#ajouterJour' + nbEtape).attr("disabled", false);
                
                $('#jourSup' + nbEtape + nbJour + '').attr("disabled", true);
                $('#jourSvg' + nbEtape + nbJour + '').attr("disabled", true);
                
                //ajouterJour(nbEtape);
                
                //alert(reponse.msgJour);                
            }
        break;
		case "enlever" :
            listerCircuits();
        break;
		case "modifier" :
            listerCircuits();
        break;            
		case "lister" :            
			listeCircuits(reponse);            
		break;
        case "listeCircuits" :            
			listeCircuitsClient(reponse);            
		break;
        case "listeEtapes" :            
			listeEtapes(reponse);            
		break;
		case "fiche" :
			//afficheFiche(reponse);
            alert(reponse.action);
		break;
        case "activer" :
			listerCircuits();
		break;
        case "desactiver" :
			listerCircuits();
		break;
        default :
            console.log(reponse.action);        
	}
}