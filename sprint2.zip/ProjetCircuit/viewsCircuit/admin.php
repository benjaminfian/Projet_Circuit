<?php
    session_start();
?>

<!doctype html>
<html lang="fr">

<head><!---->  
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
        <script language="javascript" src="../js/jquery-3.3.1.min.js"></script>
        <script language="javascript" src="../js/global.js"></script>
        <script language="javascript" src="../circuits/circuitRequetes.js"></script>    
        <script language="javascript" src="../circuits/circuitControleurVue.js"></script>
    
        <!--<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
            integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
            crossorigin="anonymous"></script>-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
            integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
            crossorigin="anonymous"></script>
        <!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
            integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
            crossorigin="anonymous"></script>-->
        <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
        <script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
        <script src="../js/formulaire.js"></script>
        <!--<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
        <script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>-->
    
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../css/bootstrap-grid.min.css">
        <link rel="stylesheet" href="../css/bootstrap-reboot.min.css">
        <link rel="stylesheet" href="../css/monCSS.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,700,900|Display+Playfair:200,300,400,700"><link href="https://fonts.googleapis.com/css?family=Roboto+Slab" rel="stylesheet">
        
        <!--<link rel="stylesheet" href="http://www.codermen.com/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <link rel="stylesheet" href="http://www.codermen.com/css/bootstrap.min.css">-->
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/css/bootstrap-datepicker.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
            integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
        <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet"
            href="https://cloud.tinymce.com/5/tinymce.min.js?apiKey=bf1dckm1oallcnw9kiu10dbo0s87xnd804mg9go70pdi4kxk&fbclid=IwAR3upVC5kNBxCXaDtwcUNi0O02_qG1IuhnJD9eFjEl6TbY558fB33d8FaX4">
        <link rel="stylesheet" href="../css/styleFormulaire.css">    

</head>

<body onload="accueilAdmin()">
    <div id="contenu">
        
    </div>
    
</body>

</html>