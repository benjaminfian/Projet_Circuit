var nbEtape=0, nbJour;

/****** */

function nouveauCircuit()
{
    $('#contenu').html("");
    var rep = '<div class="row justify-content-center">\
        <div class="tab">\
            <button class="tablinks active" style="width:300px" onclick="openCircuit(event, \'Circuit\')">Circuit</button>\
            <button id="btnTarifs" class="tablinks" disabled style="width:300px" onclick="openCircuit(event, \'Tarifs\')">Tarifs</button>\
            <button id="btnPromo" class="tablinks" disabled style="width:300px" onclick="openCircuit(event, \'Promotion\')">Promotion</button>\
        </div>\
    </div>\
    <div id="Circuit" class="tabcontent"  style="display:block;">\
        <div class="row justify-content-center">\
            <div class="col col-5">\
                <form method="post" id="formEnregCircuit" enctype="multipart/form-data" >\
                    <input type="text" value="" class="form-control input-md" size="30" placeholder="Titre" name="titreCircuit" required> <br>\
                    <textarea id="descriptionCircuit" cols="30" rows="10">Description</textarea> <br />\
                    <div class="row">\
                        <div class="col col-6">\
                            <input id="startDate" name="dateDebutCircuit" class="form-control " placeholder="Date début" width="150" required>\
                        </div>\
                        <div class="col col-6">\
                            <input id="endDate" name="dateFinCircuit" class="form-control " width="150" placeholder="Date fin" required><br><br>\
                        </div>\
                    </div>\
                    <div class="row">\
                        <div class="col col-6">\
                            <input type="text" name="prixCircuit" class="form-control" width="150" placeholder="Prix $$" value="" required>\
                        </div>\
                        <div class="col col-6">\
                            <input type="text" name="montantReservation" class="form-control " width="150" type="text" placeholder="Montant réservation $$" value="" required>\
                        </div>\
                        <br><br>\
                    </div>\
                    <div class="row">\
                        <div class="col col-6">\
                            <input name="nbPlaceMin" type="number" class=" form-control" placeholder="Places min" value="" required>\
                        </div>\
                        <div class="col col-6">\
                            <input  name="nbPlaceMax" placeholder="Places max" class="form-control " type="number" value="" required>\
                        </div>\
                    </div>\
                    <br>\
                    Images : <input type="file" name="images[]" multiple><br><br>\
                    <div class="row">\
                        <div class="col col-6">\
                            <button class="btn btn-primary" id="save" onclick="enregistrer(\'circuit\')">Sauvegarder</button>\
                        </div>\
                        <div class="col col-6">\
                            <button type="button" id="ajouteEtape" class="btn btn-primary" disabled\
                                onclick="afficherEtapes();">Ajouter étape</button>\
                        </div>\
                    </div>\
                </form>\
            </div>\
            <div class="col col-5" id=colRight>\
                <div id="loading">\
                        <div id="cssload-contain">\
                                <div class="cssload-wrap" id="cssload-wrap1">\
                                    <div class="cssload-ball" id="cssload-ball1"></div>\
                                </div>\
                                <div class="cssload-wrap" id="cssload-wrap2">\
                                    <div class="cssload-ball" id="cssload-ball2"></div>\
                                </div>\
                                <div class="cssload-wrap" id="cssload-wrap3">\
                                    <div class="cssload-ball" id="cssload-ball3"></div>\
                                </div>\
                                <div class="cssload-wrap" id="cssload-wrap4">\
                                    <div class="cssload-ball" id="cssload-ball4"></div>\
                                </div>\
                            </div>\
                </div>\
            </div>\
        </div>\
    </div>\
    <div id="Tarifs" class="tabcontent">\
        <div class="row justify-content-center">\
            <form id="formEnregTarif" class="form-signin  ">\
                <table class="table table-striped">\
                    <thead>\
                        <tr>\
                            <th>Catégorie</th>\
                            <th>Prix</th>\
                        </tr>\
                    </thead>\
                    <tbody>\
                        <tr>\
                            <td>Adulte</td>\
                            <td><input id="prixAdulte" class=" form-control" name="prixAdulte" type="text" required></td>\
                        </tr>\
                        <tr>\
                            <td>Bébé</td>\
                            <td><input id="prixBebe" class=" form-control" name="prixBebe" type="text" required></td>\
                        </tr>\
                        <tr>\
                            <td>Enfant</td>\
                            <td><input id="prixEnfant" class=" form-control" name="prixEnfant" type="text" required></td>\
                        </tr>\
                        <tr>\
                            <td>Chambre</td>\
                            <td><input id="prixChambre" class=" form-control" name="prixChambre" type="text" required></td>\
                        </tr>\
                    </tbody>\
                </table>\
                <button class="btn btn-primary" onclick="enregistrer(\'tarif\','+idCircuit+')" >Activer</button>&nbsp;&nbsp;&nbsp;<span id="msgTarif"></span><br>\
            </form>\
        </div>\
    </div>\
    <div id="Promotion" class="tabcontent">\
        <div class="row justify-content-center">\
            <form id="formEnregPromotion" class="form-signin ">\
                <input id="titrePromotion" name="titrePromotion" type="text" placeholder="Entrez titre de promotion"\
                    class="form-control input-md" required=""><br>\
                <div class="row">\
                    <div class="col col-4">\
                        <input id="pourcentagePromotion" name="pourcentagePromotion" type="text"\
                            placeholder="Entrez pourcentage" class="form-control input-md" required=""><br>\
                    </div>\
                    <div class="col col-4">\
                        <img src="../images/pourcentage.png" style="width:30px;">\
                    </div>\
                </div>\
                <div class="row">\
                    <div class="col col-6">\
                        <input id="dateDebut" name="dateDebutPromotion" class="form-control " placeholder="Date début" width="150" required>\
                    </div>\
                    <div class="col col-6">\
                        <input id="dateFin" name="dateFinPromotion" class="form-control " width="150" placeholder="Date fin" required><br><br>\
                    </div>\
                </div>\
                <button class="btn btn-lg btn-primary" onclick="enregistrer(\'promotion\','+idCircuit+')">Activer</button>&nbsp;&nbsp;&nbsp;<span id="msgPromotion"></span><br>\
            </form>\
        </div>\
    </div>\
    <script src="../js/initDatePicker.js"></script>\
    <script src="../js/initTextarea.js"></script>';
    $('#contenu').html(rep);    
}

function openCircuit(evt, etapeCreation) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(etapeCreation).style.display = "block";
  evt.currentTarget.className += " active";
}

function saveCircuit() {
  var save = document.getElementById("save");
  $('#save').attr("disabled", true);
  $('#ajouteEtape').attr("disabled", false);
  $('#btnTarifs').attr("disabled", false);
  $('#btnPromo').attr("disabled", false);    
}

function afficherEtapes() {
  if (document.getElementById("loading")) document.getElementById("loading").remove();
  var colRight = document.getElementById("colRight");
  //nbEtape = colRight.childElementCount;
  //alert(nbEtape);
  nbEtape++;
  $('#colRight').append('<div><button class="accordion" onclick="openEtape();" >Étape' + nbEtape + '</button> <div class="panel"><form method="POST" id="formEnregEtape' + nbEtape + '"> <br> <input type="text" name="titreEtape" class="form-control input-md" value="" placeholder="Titre étape" size="30" required><br><textarea id="descriptionEtape'+nbEtape+'" cols="30" rows="10" >Description</textarea> <br /> Images : <input type="file" name="images[]" multiple><br><br> <div class="row"><div class="col col-6"><button type="button" class="btn btn-primary" id="saveEtape' + nbEtape + '" onclick="enregistrer(\'etape\','+nbEtape+')">Sauvegarder</button></div></div></form></div></div>\
  <script src="../js/initTextarea.js"></script>');
  $('#ajouteEtape').attr("disabled", true);  
  //textarea();

}
function saveEtape(etape) {
  $('#saveEtape' + etape).attr("disabled", true);
  //$('#ajouterJour' + etape).attr("disabled", false);
  $('#formEnregEtape' + etape).after('<br><div class="tab" id="linkJour' + etape + '"></div>');
}
function ajouterJour(etape) {

  // $('#etape' + etape).after('<br><div class="tab" id="tabJour' + etape + '"></div>');
  var tabJour = document.getElementById("linkJour" + etape);
  nbJour = tabJour.childElementCount;
  nbJour++;

  $('#linkJour' + etape).append('<button id="tabJour' + nbJour + '" class="tablink' + etape + ' active" onclick="openJour(event,' + nbJour + ',' + etape + ')">Jour' + nbJour + '</button>');

  $('#linkJour' + etape).after('<div id="jour' + etape + nbJour + '" style="display:block;" class="tabcont' + etape + '"><form method="POST" id="formEnregJour' + nbJour + '"> <div class="row">        <div class="col col-12"> <textarea name="descriptionJour" id="" cols="30" rows="10" >Description</textarea> <br></div> </div><div class="row"> <div class="col col-8"> <input type="text" name="nomHebergement" class="form-control input-md" size="" placeholder="Nom d\'hotel" required> <br>       </div> <div class="col col-4"></div> </div> <div class="row">        <div class="col col-8"><input name="lienHebergement" type="text" value="" class="form-control input-md" placeholder="Lien d\'hotel" required><br> </div> <div class="col col-4"> <button type="button" id="jourSup' + etape + nbJour + '" class="btn btn-primary" onclick="supprimerJour(' + etape + ',' + nbJour + ');">Supprimer</button></div>    </div> <div class="row"> <div class="col col-8"> <input type="text" name="nomPension" value="" class="form-control input-md" placeholder="Nom de restaurant" required> <br></div> <div class="col col-4"></div> </div> <div class="row"><div class="col col-8"> <input type="text" name="lienPension" value="" class="form-control input-md" placeholder="Lien de restaurant" required>   <br>     </div> <div class="col col-4"> <button type="button" class="btn btn-primary" onclick="enregistrer(\'jour\','+nbJour+')">Sauvegarder jour</button> </div> </div>\</form></div>\
  <script src="../js/initTextarea.js"></script>')
  //textarea();
  openJour(event, nbJour, etape);
  //$('#ajouterJour' + etape).attr("disabled", true);
}

function openJour(event, jour, etape) {
  var i, tabcont, tablink;

  tabcont = document.getElementsByClassName("tabcont" + etape);
  for (i = 0; i < tabcont.length; i++) {
      tabcont[i].style.display = "none";
  }
  tablink = document.getElementsByClassName("tablink" + etape);
  for (i = 0; i < tablink.length; i++) {
      tablink[i].className = tablink[i].className.replace(" active", "");
  }
  document.getElementById("jour" + etape + jour).style.display = "block";
  event.currentTarget.className += " active";
}

/*function supprimerJour(etape, jour) {

  document.getElementById("jour" + etape + jour).remove();
  tablink = document.getElementsByClassName("tablink" + etape);
  for (i = 0; i < tablink.length; i++) {
      if (tablink[i].id == "tabJour" + jour) {
          document.getElementById("tabJour" + jour).remove();
      }
  }
  //$('#ajouterJour' + etape).attr("disabled", false);
}*/

function openEtape() {
  var acc = document.getElementsByClassName("accordion");
  var i;
  for (i = 0; i < acc.length; i++) {
      acc[i].addEventListener("click", function () {
          this.classList.toggle("active");

          var panel = this.nextElementSibling;
          if (panel.style.display === "block") {
              panel.style.display = "none";
          } else {
              panel.style.display = "block";
          }
      });
  }

}