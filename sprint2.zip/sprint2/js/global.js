function nouveauCircuit
{
    //inserer le formulaire de creation du circuit.
}