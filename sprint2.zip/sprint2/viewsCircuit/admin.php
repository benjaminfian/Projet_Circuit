<!doctype html>
<html lang="fr">

<head>
  
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="http://www.codermen.com/css/bootstrap.min.css">
       
        <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
        <script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>

   
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>


    <link rel="stylesheet" href="http://www.codermen.com/css/bootstrap.min.css">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
        integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet"
        href="https://cloud.tinymce.com/5/tinymce.min.js?apiKey=bf1dckm1oallcnw9kiu10dbo0s87xnd804mg9go70pdi4kxk&fbclid=IwAR3upVC5kNBxCXaDtwcUNi0O02_qG1IuhnJD9eFjEl6TbY558fB33d8FaX4">
    <link rel="stylesheet" href="css/style.css">

    <style>
        .mce-notification {
            display: none !important;
        }
    </style>

</head>

<body onload="textarea();">
    <div class="row justify-content-center">
        <div class="tab">
            <button class="tablinks active" style="width:300px" onclick="openCircuit(event, 'Circuit')">Circuit</button>
            <button id="btnTarifs" class="tablinks" disabled style="width:300px" onclick="openCircuit(event, 'Tarifs')">Tarifs</button>
            <button id="btnPromo" class="tablinks" disabled style="width:300px" onclick="openCircuit(event, 'Promotion')">Promotion</button>

        </div>
    </div>
    <div id="Circuit" class="tabcontent"  style="display:block;">
        <div class="row justify-content-center">
            <div class="col col-5">
                <form method="POST" class="form-signin " id="circuit">
                    <input type="text" value="" class="form-control input-md" size="30" placeholder="Titre" required> <br>
                    <textarea name="" id="" cols="30" rows="10" >Description</textarea> <br />
                    <div class="row">
                        <div class="col col-6">
                            <input id="startDate" class="form-control " placeholder="Date début" width="150" required>
                        </div>
                        <div class="col col-6">
                            <input id="endDate" class="form-control " width="150" placeholder="Date fin" required><br><br>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col col-6">
                            <input type="text" class="form-control " width="150" placeholder="Prix $$" value="" required>
                        </div>
                        <div class="col col-6">
                            <input class="form-control " width="150" type="text" placeholder="Montant réservation $$" value="" required>
                        </div>
                        <br><br>
                    </div>
                    <div class="row">
                        <div class="col col-6">
                            <input type="number" class=" form-control" placeholder="Places min" value="" required>
                        </div>
                        <div class="col col-6">
                            <input placeholder="Places max" class="form-control " type="number" value="" required>

                        </div>
                    </div>
                    <br>
                    <input type="file" name="name" multiple><br><br>
                    <div class="row">
                        <div class="col col-6">
                            <button type="button" class="btn btn-primary" id="save"
                                onclick="saveCircuit();">Sauvgarder</button>
                        </div>
                        <div class="col col-6">
                            <button type="button" id="ajouteEtape" class="btn btn-primary" disabled
                                onclick="afficherEtapes();">Ajouter
                                étape</button>

                        </div>
                    </div>

                </form>

            </div>
            <div class="col col-5" id=colRight>
                <div id="loading">
                        <div id="cssload-contain">
                                <div class="cssload-wrap" id="cssload-wrap1">
                                    <div class="cssload-ball" id="cssload-ball1"></div>
                                </div>
                            
                                <div class="cssload-wrap" id="cssload-wrap2">
                                    <div class="cssload-ball" id="cssload-ball2"></div>
                                </div>
                                
                                <div class="cssload-wrap" id="cssload-wrap3">
                                    <div class="cssload-ball" id="cssload-ball3"></div>
                                </div>
                                
                                <div class="cssload-wrap" id="cssload-wrap4">
                                    <div class="cssload-ball" id="cssload-ball4"></div>
                                </div>
                            
                            </div>
                </div>

            </div>
        </div>

    </div>

    <div id="Tarifs" class="tabcontent">
        <div class="row justify-content-center">
            <form class="form-signin  ">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Catégorie</th>
                            <th>Prix</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Adulte</td>
                            <td><input id="prixAdulte" class=" form-control" name="prixAdulte" type="text" required></td>

                        </tr>
                        <tr>
                            <td>Bébé</td>
                            <td><input id="prixBebe" class=" form-control" name="prixBebe" type="text" required></td>

                        </tr>
                        <tr>
                            <td>Enfant</td>
                            <td><input id="prixEnfant" class=" form-control" name="prixEnfant" type="text" required></td>

                        </tr>
                        <tr>
                            <td>Chambre</td>
                            <td><input id="prixChambre" class=" form-control" name="prixChambre" type="text" required></td>

                        </tr>
                    </tbody>
                </table>
                <button class="btn  btn-primary ">Activer</button><br>
            </form>
        </div>
    </div>
    <div id="Promotion" class="tabcontent">
        <div class="row justify-content-center">

            <form class="form-signin ">

                <input id="titrePromotion" name="titrePromotion" type="text" placeholder="Entrez titre de promotion"
                    class="form-control input-md" required=""><br>
                <div class="row">
                    <div class="col col-4">
                        <input id="pourcentagePromotion" name="pourcentagePromotion" type="text"
                            placeholder="Entrez pourcentage" class="form-control input-md" required=""><br>
                    </div>
                    <div class="col col-4">
                        <img src="images/pourcentage.png" style="width:30px;">
                    </div>
                </div>
                <div class="row">
                    <div class="col col-6">
                        <input id="dateDebut" class="form-control " placeholder="Date début" width="150" required>
                    </div>
                    <div class="col col-6">
                        <input id="dateFin" class="form-control " width="150" placeholder="Date fin" required><br><br>
                    </div>
                </div>
                <button class="btn btn-lg btn-primary ">Activer</button><br>
            </form>
        </div>
    </div>


    <!-- Optional JavaScript -->
    <!--  jQuery first, then Popper.js, then Bootstrap JS -->
    <!--   <script src="https://code.jquery.com/jquery-3.4.0.min.js">
    </script>-->
    <!--  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>-->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"   integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"> </script>-->
    <!--  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>-->

    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>

    <script src="js/general.js"></script>
    <script src="js/formulaire.js"></script>
    
</body>

</html>