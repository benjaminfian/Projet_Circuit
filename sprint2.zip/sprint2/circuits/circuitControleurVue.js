var idCircuit,idEtape;

//vue Circuit

function listeCircuits(reponse)
{
    $('#contenu').html("");
    var rep = '<div class="row marge-gauche custom-center">\
        <div class="col-sm-12 col-md-10 col-md-offset-1 custom-center"><br>\
            <button type="button" class="btn btn-success marge-bas" onclick="nouveauCircuit()">Ajouter un circuit</button>\
            <table class="table table-hover table-striped">\
                <thead>\
                    <tr>\
                        <th>image</th>\
                        <th class="text-center">Titre</th>\
                        <th class="text-center">Nombre d\'étapes</th>\
                        <th class="text-center">Date de début</th>\
                        <th class="text-center">Date de fin</th>\
                        <th class="text-center">Prix</th>\
                        <th></th><th></th><th></th></tr>\
                </thead>\
                <tbody>';    
    for (var i =0; i < reponse.listeCircuits.length; i++)
    {          
        rep +=  '<tr>\
                    <td width=\"8%\">\
                        <div class="media">\
                                <img class="img_crud" src="'+reponse.listeImages[i]+'" alt="Circuit '+reponse.listeCircuits[i].idCircuit+'" title="image du circuit'+reponse.listeCircuits[i].titreCircuit+'">\
                        </div>\
                    </td>\
                    <td class="text-center"><strong>'+reponse.listeCircuits[i].titreCircuit+'</strong></td>\
                    <td class="text-center"><strong>'+reponse.listeCircuits[i].nbEtape+'</strong></td>\
                    <td class="text-center"><strong>'+reponse.listeCircuits[i].dateDebutCircuit+'</strong></td>\
                    <td class="text-center"><strong>'+reponse.listeCircuits[i].dateDebutCircuit+'</strong></td>\
                    <td class="text-center"><strong>'+reponse.listeCircuits[i].prixCircuit+' $</strong></td>';
        if (reponse.listeCircuits[i].etat == 0)
        {
            rep += '<td class="text-center"><button type="button" class="btn btn-success"\ onclick="obtenirFicheCircuit('+reponse.listeCircuits[i].idCircuit+')\">Modifier</button></td>\
                    <td class="text-center"><button type="button" class="btn btn-danger"\ onclick="supprimerCircuit('+reponse.listeCircuits[i].idCircuit+')\">Supprimer</button></td>\
                    <td class="text-center"><button type="button" class="btn btn-primary"\ onclick="activerCircuit('+reponse.listeCircuits[i].idCircuit+')\">Activer</button></td></tr>';    
        }
        else
        {
            rep += '<td></td><td></td>\
                    <td class="text-center"><button type="button" class="btn btn-secondary" onclick="desactiverCircuit('+reponse.listeCircuits[i].idCircuit+')\">Desactiver</button></td></tr>';    
        }                    
    }    
    rep += '</tbody></table></div></div></div>';
    $('#contenu').html(rep);
}



function afficheFiche(reponse)
{
    $('#contenu').html("");
    var uneFiche;
    if(reponse.OK)
    {
        uneFiche=reponse.circuit;
        var test = JSON.stringify(uneFiche);
        /*$('#formFicheF h3:first-child').html("Fiche du film numero "+uneFiche.idf);
        $('#idf').val(uneFiche.idf);
        $('#titreF').val(uneFiche.titre);
        $('#dureeF').val(uneFiche.duree);
        $('#resF').val(uneFiche.res);
        $('#divFormFiche').show();
        document.getElementById('divFormFiche').style.display='block';*/
    }
    else
    {
        /*$('#messages').html("Film "+$('#numF').val()+" introuvable");
        setTimeout(function(){ $('#messages').html(""); }, 5000);*/
    }
    $('#contenu').html(rep);
}

var circuitsVue=function(reponse)
{
	var action = reponse.action;    
	switch(action)
    {
		case "enregistrer" :
            if(reponse.idCircuit)
            {
                idCircuit = reponse.idCircuit;
                saveCircuit();
                //alert(idCircuit);                
            }                
            if(reponse.idEtape)
            {
                idEtape = reponse.idEtape;
                saveEtape(nbEtape);
                $('#ajouteEtape').attr("disabled", false);
                
                //ajouterJour(nbEtape);
                
                //alert(idEtape);                
            }            
            if(reponse.msgTarif)
            {
                alert(reponse.msgTarif);
                $('#msgTarif').html("");
                $('#msgTarif').html(reponse.msgTarif);
            }
            if(reponse.msgPromotion)
            {
                $('#msgPromotion').html("");
                $('#msgPromotion').html(reponse.msgPromotion);
            }
            if(reponse.msgJour)
            {
                $('#ajouterJour' + nbEtape).attr("disabled", false);
                
                $('#jourSup' + nbEtape + nbJour + '').attr("disabled", true);
                $('#jourSvg' + nbEtape + nbJour + '').attr("disabled", true);
                
                //ajouterJour(nbEtape);
                
                //alert(reponse.msgJour);                
            }
        break;
		case "enlever" :
            listerCircuits();
        break;
		case "modifier" :
            
        break;            
		case "lister" :            
			listeCircuits(reponse);            
		break;
		case "fiche" :
			//afficheFiche(reponse);
		break;
        case "activer" :
			listerCircuits();
		break;
        case "desactiver" :
			listerCircuits();
		break;
        default :
            console.log(reponse.action);        
	}
}