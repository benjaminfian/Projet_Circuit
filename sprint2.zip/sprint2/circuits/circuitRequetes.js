function enregistrer(type,id)
{
    var formCircuit;    
    if (type == "circuit")
    {   
        formCircuit = document.getElementById('formEnregCircuit');
        //alert();
    }
    if (type == "tarif")
    {   
        formCircuit = document.getElementById('formEnregTarif');
        //alert();
    }
    if (type == "promotion")
    {   
        formCircuit = document.getElementById('formEnregPromotion');
        //alert();
    }
    if (type == "etape")
    {        
        formCircuit = document.getElementById('formEnregEtape'+id+'');
        //alert(id);
    }
    if (type == "jour")
    {        
        formCircuit = document.getElementById('formEnregJour'+id+'');
        //alert(id);
    }
    var valid = formCircuit.checkValidity();
    if (valid)
    {        
        event.preventDefault();
        formCircuit = new FormData(formCircuit);
        //alert(type);
        if(type == "circuit")
        {
            var descriptionCircuit = tinyMCE.get('descriptionCircuit').getContent();    
            formCircuit.append('descriptionCircuit', descriptionCircuit);
        }     
        else
        {
            if(type == "etape" || type == "tarif" || type == "promotion")
            {
                if(type == "etape")
                {
                    var descriptionCircuit = tinyMCE.get('descriptionEtape'+id+'').getContent();
                    //var images = document.getElementById('imagesEtape'+id+'');
                    formCircuit.append('descriptionEtape', descriptionCircuit);
                    //formCircuit.append('images[]', images);
                }
                formCircuit.append('id',idCircuit);
            }
            else
            {
                formCircuit.append('id',idEtape);                
            }
        }
        formCircuit.append('typeForm', type);
        formCircuit.append('action','enregistrer');         
        $.ajax({
            type : 'POST',
            url : '../circuits/circuitControleur.php',
            data : formCircuit,
            dataType : 'json',
            //async : false,
            //cache : false,
            contentType : false,
            processData : false,
            success : function (reponse){//alert(reponse);
                        circuitsVue(reponse);
            },
            fail : function (err){//alert("fail");
            }
        });
    }    
}

function listerCircuits()
{      
    var formCircuit = new FormData();
	formCircuit.append('action','lister');
	$.ajax({
		type : 'POST',
		url : '../circuits/circuitControleur.php',
		data : formCircuit,		
		//async : false,
		//cache : false,
		contentType : false,
		processData : false,
        dataType : 'json',
		success : function (reponse){//alert(reponse);
					circuitsVue(reponse);
		},
		fail : function (err){//alert();		   
		}
	});
}

function supprimerCircuit(id)
{    
	var formCircuit = new FormData();
	formCircuit.append('action','enlever');
    formCircuit.append('id',id);
	$.ajax({
		type : 'POST',
		url : '../circuits/circuitControleur.php',
		data : formCircuit,//leForm.serialize(),
		contentType : false, //Enlever ces deux directives si vous utilisez serialize()
		processData : false,
		dataType : 'json', //text pour le voir en format de string
		success : function (reponse){alert(reponse);
					circuitsVue(reponse);
		},
		fail : function (err){
		}
	});
}

function activerCircuit(id)
{
    var formCircuit = new FormData();
	formCircuit.append('action','activer');
    formCircuit.append('id',id);
	$.ajax({
		type : 'POST',
		url : '../circuits/circuitControleur.php',
		data : formCircuit,
		dataType : 'json',
		//async : false,
		//cache : false,
		contentType : false,
		processData : false,
		success : function (reponse){//alert(reponse);
					circuitsVue(reponse);
		},
		fail : function (err){		   
		}
	});
}

function desactiverCircuit(id)
{
    var formCircuit = new FormData();
	formCircuit.append('action','desactiver');
    formCircuit.append('id',id);
	$.ajax({
		type : 'POST',
		url : '../circuits/circuitControleur.php',
		data : formCircuit,
		dataType : 'json',
		//async : false,
		//cache : false,
		contentType : false,
		processData : false,
		success : function (reponse){//alert(reponse);
					circuitsVue(reponse);
		},
		fail : function (err){		   
		}
	});
}

/*function obtenirFicheCircuit(idCircuit)
{	
	var formCircuit = new FormData();
	formCircuit.append('action','fiche');
	$.ajax({
		type : 'POST',
		url : 'circuits/circuitControleur.php',
		data : formCircuit,
		dataType : 'json',
		//async : false,
		//cache : false,
		contentType : false,
		processData : false,
		success : function (reponse){//alert(reponse);
					circuitsVue(reponse);
		},
		fail : function (err){		   
		}
	});
}

function modifierCircuit(idCircuit)
{
	var leForm=document.getElementById('formFicheCircuit');
	var formFilm = new FormData(leForm);
	formFilm.append('action','modifier');
	$.ajax({
		type : 'POST',
		url : 'Films/filmsControleur.php',
		data : formFilm,
		contentType : false, 
		processData : false,
		dataType : 'json', 
		success : function (reponse){//alert(reponse);
					$('#divFormFiche').hide();
					filmsVue(reponse);
		},
		fail : function (err){
		}
	});
}*/

