function enregistrer(type,id,idPrec)
{
    if (type == "circuit")
    {
        var formCircuit = new FormData(document.getElementById('formEnregCircuit'+id+''));
    }
    if (type == "etape")
    {
        var formCircuit = new FormData(document.getElementById('formEnregEtape'+id+''));
    }
    if (type == "jour")
    {
        var formCircuit = new FormData(document.getElementById('formEnregJour'+id+''));
    }
	var formCircuit = new FormData(document.getElementById('formEnregCircuit'));
	formCircuit.append('action','enregistrer');
    formCircuit.append('id','idPrec');//condition si pas de idPrec
	$.ajax({
		type : 'POST',
		url : 'circuits/circuitControleur.php',
		data : formCircuit,
		dataType : 'json',
		//async : false,
		//cache : false,
		contentType : false,
		processData : false,
		success : function (reponse){//alert(reponse);
					circuitsVue(reponse);
		},
		fail : function (err){
		   
		}
	});
}

function listerCircuits()
{
    var formCircuit = new FormData();
	formCircuit.append('action','lister');
	$.ajax({
		type : 'POST',
		url : 'circuits/circuitControleur.php',
		data : formCircuit,
		dataType : 'json',
		//async : false,
		//cache : false,
		contentType : false,
		processData : false,
		success : function (reponse){//alert(reponse);
					circuitsVue(reponse);
		},
		fail : function (err){
		   
		}
	});
}

function supprimerCircuit(idCircuit)
{
	var formCircuit = new FormData();
	formCircuit.append('action','enlever');
    formCircuit.append('id',idCircuit);
	$.ajax({
		type : 'POST',
		url : 'circuits/circuitControleur.php',
		data : formCircuit,//leForm.serialize(),
		contentType : false, //Enlever ces deux directives si vous utilisez serialize()
		processData : false,
		dataType : 'json', //text pour le voir en format de string
		success : function (reponse){//alert(reponse);
					circuitsVue(reponse);
		},
		fail : function (err){
		}
	});
}

function obtenirFicheCircuit(idCircuit)
{	
	var formCircuit = new FormData();
	formCircuit.append('action','fiche');
	$.ajax({
		type : 'POST',
		url : 'circuits/circuitControleur.php',
		data : formCircuit,
		dataType : 'json',
		//async : false,
		//cache : false,
		contentType : false,
		processData : false,
		success : function (reponse){//alert(reponse);
					circuitsVue(reponse);
		},
		fail : function (err){
		   
		}
	});
}

function modifierCircuit(idCircuit)
{
	var leForm=document.getElementById('formFicheCircuit');
	var formFilm = new FormData(leForm);
	formFilm.append('action','modifier');
	$.ajax({
		type : 'POST',
		url : 'Films/filmsControleur.php',
		data : formFilm,
		contentType : false, 
		processData : false,
		dataType : 'json', 
		success : function (reponse){//alert(reponse);
					$('#divFormFiche').hide();
					filmsVue(reponse);
		},
		fail : function (err){
		}
	});
}

function activerCircuit(idCircuit)
{
    var formCircuit = new FormData();
	formCircuit.append('action','activer');
    formCircuit.append('id',idCircuit);
	$.ajax({
		type : 'POST',
		url : 'circuits/circuitControleur.php',
		data : formCircuit,
		dataType : 'json',
		//async : false,
		//cache : false,
		contentType : false,
		processData : false,
		success : function (reponse){//alert(reponse);
					circuitsVue(reponse);
		},
		fail : function (err){
		   
		}
	});
}

function desactiverCircuit(idCircuit)
{
    var formCircuit = new FormData();
	formCircuit.append('action','desactiver');
	$.ajax({
		type : 'POST',
		url : 'circuits/circuitControleur.php',
		data : formCircuit,
		dataType : 'json',
		//async : false,
		//cache : false,
		contentType : false,
		processData : false,
		success : function (reponse){//alert(reponse);
					circuitsVue(reponse);
		},
		fail : function (err){
		   
		}
	});
}