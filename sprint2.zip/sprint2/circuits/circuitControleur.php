<?php
	require_once("../includes/modele.inc.php");
	$tabRes=array();

	function enregistrer($id)
    {
		global $tabRes;
        $type=$_POST['typeForm'];        
        switch($type)
        {
            case "circuit" :
                $titre=$_POST['titreCircuit'];
                $description=$_POST['descriptionCircuit'];
                $prix=$_POST['prixCircuit'];
                $dateDebut=$_POST['dateDebutCircuit'];
                $dateFin=$_POST['dateFinCircuit'];        
                $nbPlaceMin=$_POST['nbPlaceMin'];
                $nbPlaceMax=$_POST['nbPlaceMax'];
                $montantReservation=$_POST['montantReservation'];                
                try
                {			
                    $requete="INSERT INTO circuit VALUES(0,?,?,?)";
                    $unModele=new circuitsModele($requete,array($titre,$description,$prix));
                    $stmt=$unModele->executer();

                    $idCircuit = $unModele->connexion->lastInsertId();

                    $requete2="INSERT INTO detailscircuit VALUES(?,?,?,?,?,?)";
                    $unModele=new circuitsModele($requete2,array($idCircuit,$dateDebut,$dateFin,$nbPlaceMin,$nbPlaceMax,$montantReservation));
                    $stmt=$unModele->executer();

                    $cheminImages = "../imagesCircuits/circuit".$idCircuit."";
                    mkdir($cheminImages, 0700);

                    $unModele=new circuitsModele();    
                    $unModele->verserFichier($cheminImages, "images",$titre);

                    $tabRes['action']="enregistrer";
                    $tabRes['idCircuit']=$idCircuit;
                    $tabRes['msg']="Le circuit ".$titre." a bien �t� enregistr�.";
                }
                catch(Exception $e)
                {
                }
                finally
                {
                    unset($unModele);
                }
            break;
            case "etape" :
                $titre=$_POST['titreEtape'];
                $description=$_POST['descriptionEtape'];                                
                try
                {			
                    $requete="INSERT INTO etape VALUES(0,?,?)";
                    $unModele=new circuitsModele($requete,array($titre,$description));
                    $stmt=$unModele->executer();

                    $idEtape = $unModele->connexion->lastInsertId();
                    
                    requete2= "INSERT INTO circuit_etape VALUES(?,?)";
                    $unModele=new circuitsModele($requete2,array($id,$idEtape));
                    $stmt=$unModele->executer();                   

                    $cheminImages = "../imagesCircuits/circuit".$id."/etape".$idEtape."";
                    mkdir($cheminImages, 0700);

                    $unModele=new circuitsModele();    
                    $unModele->verserFichier($cheminImages, "images",$titre);

                    $tabRes['action']="enregistrer";
                    $tabRes['idCircuit']=$idCircuit;
                    $tabRes['msg']="L'�tape ".$titre." a bien �t� enregistr�e.";
                }
                catch(Exception $e)
                {
                }
                finally
                {
                    unset($unModele);
                }                         
            break;
            case "jour" : 
                $titre=$_POST['titreJour'];
                $descriptionJour=$_POST['descriptionJour'];
                $descriptionActivite=$_POST['descriptionActivite'];
                $nomHebergement=$POST['nomHebergement'];
                $lienHebergement=$POST['lienHebergement'];
                $nomPension=$POST['nomPension'];
                $lienPension=$POST['lienPension'];
                try
                {			
                    $requete="INSERT INTO jour VALUES(0,?,?)";
                    $unModele=new circuitsModele($requete,array($titre,$descriptionJour));
                    $stmt=$unModele->executer();

                    $idJour = $unModele->connexion->lastInsertId();
                    
                    $requete="INSERT INTO activite VALUES(?,?)";
                    $unModele=new circuitsModele($requete,array($descriptionActivite,$idJour));
                    $stmt=$unModele->executer();
                    
                    $requete="INSERT INTO hebergement VALUES(?,?,?)";
                    $unModele=new circuitsModele($requete,array($nomHebergement,$lienHebergement,$idJour));
                    $stmt=$unModele->executer();
                    
                    $requete="INSERT INTO pension VALUES(?,?,?)";
                    $unModele=new circuitsModele($requete,array($nomPension,$lienPension,$idJour));
                    $stmt=$unModele->executer();                    

                    $tabRes['action']="enregistrer";                    
                    $tabRes['msg']="Le jour ".$titre." a bien �t� enregistr�.";
                }
                catch(Exception $e)
                {
                }
                finally
                {
                    unset($unModele);
                }                
            break;
            case "tarif"
                $prixBebe=$_POST['prixBebe'];
                $prixEnfant=$_POST['prixEnfant'];
                $prixAdulte=$_POST['prixAdulte'];
                $prixChambre=$_POST['prixChambre'];
                try
                {			
                    $requete="INSERT INTO tarif VALUES(?,?,?,?,?)";
                    $unModele=new circuitsModele($requete,array($id,$prixBebe,$prixEnfant,$prixAdulte,prixChambre));
                    $stmt=$unModele->executer();                                                       

                    $tabRes['action']="enregistrer";                    
                    $tabRes['msg']="Le tarif a bien �t� enregistr�e.";
                }
                catch(Exception $e)
                {
                }
                finally
                {
                    unset($unModele);
                }                 
            break;
            case "promotion"
                $pourcentagePromotion=$_POST['pourcentagePromotion'];
                $titrePromotion=$_POST['titrePromotion'];
                $dateDebutPromotion=$_POST['dateDebutPromotion'];
                $dateFinPromotion=$_POST['dateFinPromotion'];                
                try
                {			
                    $requete="INSERT INTO promotion VALUES(0,?,?,?,?,?)";
                    $unModele=new circuitsModele($requete,array($pourcentagePromotion,$titrePromotion,$dateDebutPromotion,$dateFinPromotion,$id));
                    $stmt=$unModele->executer();                                                       

                    $tabRes['action']="enregistrer";                    
                    $tabRes['msg']="La promotion a bien �t� enregistr�e.";
                }
                catch(Exception $e)
                {
                }
                finally
                {
                    unset($unModele);
                }
            break;
        }
		
	}
	
	function lister()
    {
		global $tabRes;
        $tabID=array();
		$tabRes['action']="lister";        
		$requete="SELECT circuit.idCircuit, circuit.titreCircuit, circuit.descriptionCircuit, circuit.prixCircuit, circuit.etat, detailscircuit.dateDebutCircuit, detailscircuit.dateFinCircuit, COUNT(circuit_etape.idEtape) AS nbEtape FROM circuit JOIN detailscircuit ON  circuit.idCircuit = detailsCircuit.idCircuit LEFT JOIN circuit_etape ON circuit.idCircuit = circuit_etape.idCircuit GROUP BY circuit.idCircuit, circuit_etape.idCircuit ORDER BY circuit.idCircuit";        
        $chemin="../imagesCircuits/circuit";
		try
        {
			 $unModele=new circuitsModele($requete,array());
			 $stmt=$unModele->executer();
			 $tabRes['listeCircuits']=array();
             $tabRes['listeImages']=array();             
			 while($ligne=$stmt->fetch(PDO::FETCH_OBJ))
             {
			    $tabRes['listeCircuits'][]=$ligne;
                $tabID[]=$ligne->idCircuit;
                $path = $chemin.$ligne->titreCircuit.$ligne->idCircuit;
                if (file_exists($path))
                {
                    $fichier = $path."/".scandir($path,2)[0];
                }
                else
                {
                    $fichier = "../imagesCircuits/avatarCircuit.png";
                }                
                $tabRes['listeImages'][]= $fichier;                               
			 }
		}
        catch(Exception $e)
        {
            //echo $e->getMessage();
		}
        finally
        {
			unset($unModele);            
		}                    
	}
	
	function enlever($id)
    {
		global $tabRes;
        $chemin="../imagesCircuits/circuit";
		try
        {
			$requete="SELECT * FROM films WHERE idCircuit=?";
			$unModele=new filmsModele($requete,array($id));
			$stmt=$unModele->executer();
			if($ligne=$stmt->fetch(PDO::FETCH_OBJ))
            {
                $path = $chemin.$ligne->titreCircuit.$ligne->idCircuit;
				$unModele->enleverDossier($path);
				$requete="DELETE FROM circuit WHERE idCircuit=?";
				$unModele=new filmsModele($requete,array($id));
				$stmt=$unModele->executer();
				$tabRes['action']="enlever";
				$tabRes['msg']="Le circuit ".$ligne->titreCircuit." a bien �t� supprim�.";
			}
			else
            {
				$tabRes['action']="enlever";
				$tabRes['msg']="Le circuit ".$ligne->titreCircuit." est introuvable.";
			}
		}
        catch(Exception $e)
        {
		}
        finally
        {
			unset($unModele);
		}
	}
	
	function fiche($id)
    {
		global $tabRes;
        $tabID=array();
		$tabRes['action']="fiche";
		$requete="SELECT circuit.idCircuit, circuit.titreCircuit, circuit.descriptionCircuit, circuit.prixCircuit, circuit.etat, detailscircuit.dateDebutCircuit, detailscircuit.dateFinCircuit, detailscircuit.nbPlaceMin, detailscircuit.nbPlaceMax, detailscircuit.montantReservation, tarif.idCircuit, tarif.prixBebe, tarif.prixEnfant, tarif.prixAdulte, tarif.prixChambre, promotion.idPromotion, promotion.pourcentagePromotion, promotion.titrePromotion, promotion.dateDebutPromotion, promotion.dateFinPromotion, promotion.idCircuit, etape.idEtape, etape.titreEtape, etape.descriptionEtape, jour.idJour, jour.titreJour, jour.descriptionJour, jour.idEtape, hebergement.nomHebergement, hebergement.lienHebergement, hebergement.idJour, pension.nomPension, pension.lienPension, pension.idJour, activite.descriptionActivite, activite.idJour FROM circuit JOIN detailscircuit ON circuit.idCircuit = detailsCircuit.idCircuit LEFT JOIN tarif ON circuit.idCircuit = tarif.idCircuit LEFT JOIN promotion ON circuit.idCircuit = promotion.idPromotion LEFT JOIN circuit_etape ON circuit.idCircuit = circuit_etape.idCircuit LEFT JOIN etape ON circuit_etape.idEtape = etape.idEtape LEFT JOIN jour ON etape.idEtape = jour.idEtape LEFT JOIN hebergement ON jour.idJour = hebergement.idJour LEFT JOIN pension ON jour.idJour = pension.idJour LEFT JOIN activite ON jour.idJour = activite.idJour WHERE circuit.idCircuit=? GROUP BY circuit.idCircuit, circuit_etape.idEtape, etape.idEtape, jour.idEtape, hebergement.idJour, pension.idJour, activite.idJour ORDER BY circuit.idCircuit";        
		try
        {
			 $unModele=new circuitsModele($requete,array($id));
			 $stmt=$unModele->executer();
			 $tabRes['circuit']=array();
			 if($ligne=$stmt->fetch(PDO::FETCH_OBJ))
             {
			    $tabRes['circuit']=$ligne;
				$tabRes['OKcircuit']=true;
			 }
			 else
             {
				$tabRes['OKcircuit']=false;
			 }
		}
        catch(Exception $e)
        {
		}
        finally
        {
			unset($unModele);
		}        
	}
	//modif
	function modifier($idCircuit,$idEtape,$idJour)
    {
		global $tabRes;
        $type=$_POST['typeForm'];        
        switch($type)
        {
            case "circuit" :
                $titre=$_POST['titreCircuit'];
                $description=$_POST['descriptionCircuit'];
                $prix=$_POST['prixCircuit'];
                $dateDebut=$_POST['dateDebutCircuit'];
                $dateFin=$_POST['dateFinCircuit'];        
                $nbPlaceMin=$_POST['nbPlaceMin'];
                $nbPlaceMax=$_POST['nbPlaceMax'];
                $montantReservation=$_POST['montantReservation'];                
                try
                {
                    $requete="UPDATE circuit SET titreCircuit=?, descriptionCircuit=?, prixCircuit=? WHERE idCircuit=?";                    
                    $unModele=new circuitsModele($requete,array($titre,$description,$prix,$idCircuit));
                    $stmt=$unModele->executer();                    

                    $requete2="UPDATE detailscircuit SET dateDebutCircuit=?, dateFinCircuit=?, nbPlaceMin=?, nbPlaceMax=?, montantReservation=? WHERE idCircuit=?";
                    $unModele=new circuitsModele($requete2,array($dateDebut,$dateFin,$nbPlaceMin,$nbPlaceMax,$montantReservation,$idCircuit));
                    $stmt=$unModele->executer();

                    $cheminImages = "../imagesCircuits/circuit".$idCircuit."";
                    //mkdir($cheminImages, 0700);

                    $unModele=new circuitsModele();    
                    $unModele->verserFichier($cheminImages, "images",$titre);

                    $tabRes['action']="modifier";                    
                    $tabRes['msg']="Le circuit ".$titre." a bien �t� modifi�.";
                }
                catch(Exception $e)
                {
                }
                finally
                {
                    unset($unModele);
                }
            break;
            case "etape" :
                $titre=$_POST['titreEtape'];
                $description=$_POST['descriptionEtape'];                                
                try
                {			
                    $requete="UPDATE etape SET titreEtape=?, descriptionEtape=? WHERE idEtape=?";
                    $unModele=new circuitsModele($requete,array($titre,$description,$idEtape));
                    $stmt=$unModele->executer();                    
                    
                    $cheminImages = "../imagesCircuits/circuit".$idCircuit."/etape".$idEtape."";
                    //mkdir($cheminImages, 0700);

                    $unModele=new circuitsModele();    
                    $unModele->verserFichier($cheminImages, "images",$titre);

                    $tabRes['action']="modifier";                    
                    $tabRes['msg']="L'�tape ".$titre." a bien �t� modifi�e.";
                }
                catch(Exception $e)
                {
                }
                finally
                {
                    unset($unModele);
                }                           
            break;
            case "jour" :
                $titre=$_POST['titreJour'];
                $description=$_POST['descriptionJour'];                                
                try
                {			
                    $requete="UPDATE jour SET titreJour=?, descriptionJour=? WHERE idJour=?";
                    $unModele=new circuitsModele($requete,array($titre,$description,$idJour));
                    $stmt=$unModele->executer();                    

                    $tabRes['action']="modifier";                    
                    $tabRes['msg']="Le Jour ".$titre." a bien �t� modifi�.";
                }
                catch(Exception $e)
                {
                }
                finally
                {
                    unset($unModele);
                }                
            break;
            case "tarif"
                $prixBebe=$_POST['prixBebe'];
                $prixEnfant=$_POST['prixEnfant'];
                $prixAdulte=$_POST['prixAdulte'];
                $prixChambre=$_POST['prixChambre'];                                
                try
                {			
                    $requete="UPDATE tarif SET prixBebe=?, prixEnfant=?, prixAdulte=?, prixChambre=? WHERE idCircuit=?";
                    $unModele=new circuitsModele($requete,array($prixBebe,$prixEnfant,$prixAdulte,$prixChambre,$idCircuit));
                    $stmt=$unModele->executer();                    

                    $tabRes['action']="modifier";                    
                    $tabRes['msg']="Le tarif a bien �t� modifi�.";
                }
                catch(Exception $e)
                {
                }
                finally
                {
                    unset($unModele);
                }
            break;
            case "promotion"
                $pourcentagePromotion=$_POST['pourcentagePromotion'];
                $titrePromotion=$_POST['titrePromotion'];
                $dateDebutPromotion=$_POST['dateDebutPromotion'];
                $dateFinPromotion=$_POST['dateFinPromotion'];                                
                try
                {			
                    $requete="UPDATE promotion SET pourcentagePromotion=?, titrePromotion=?, dateDebutPromotion=?, dateFinPromotion=? WHERE idCircuit=?";
                    $unModele=new circuitsModele($requete,array($pourcentagePromotion,$titrePromotion,$dateDebutPromotion,$dateFinPromotion,$idCircuit));
                    $stmt=$unModele->executer();                    

                    $tabRes['action']="modifier";                    
                    $tabRes['msg']="Lpromotion a bien �t� modifi�e.";
                }
                catch(Exception $e)
                {
                }
                finally
                {
                    unset($unModele);
                }
            break;
        }
		/*$titre=$_POST['titreF'];
		$duree=$_POST['dureeF'];
		$res=$_POST['resF'];
		$idf=$_POST['idf']; 
		try
        {
			//Recuperer ancienne pochette
			$requette="SELECT pochette FROM films WHERE idf=?";
			$unModele=new filmsModele($requette,array($idf));
			$stmt=$unModele->executer();
			$ligne=$stmt->fetch(PDO::FETCH_OBJ);
			$anciennePochette=$ligne->pochette;
			$pochette=$unModele->verserFichier("pochettes", "pochette",$anciennePochette,$titre);	
			
			$requete="UPDATE films SET titre=?,duree=?, res=?, pochette=? WHERE idf=?";
			$unModele=new filmsModele($requete,array($titre,$duree,$res,$pochette,$idf));
			$stmt=$unModele->executer();
			$tabRes['action']="modifier";
			$tabRes['msg']="Film $idf bien modifie";
		}
        catch(Exception $e)
        {
		}
        finally
        {
			unset($unModele);
		}*/
	}

    function activer($id)
    {
        global $tabRes;
        try
        {
            $requete="SELECT * FROM circuit WHERE idCircuit=?";			
			$unModele=new filmsModele($requete,array($id));
			$stmt=$unModele->executer();
			if($ligne=$stmt->fetch(PDO::FETCH_OBJ))
            {				
				$requete="UPDATE circuit SET etat = 1 WHERE idCircuit=?";
				$unModele=new filmsModele($requete,array($idf));
				$stmt=$unModele->executer();
				$tabRes['action']="activer";
				$tabRes['msg']="Le circuit ".$ligne->titreCircuit." a bien �t� activ�.";
			}
			else{
				$tabRes['action']="activer";
				$tabRes['msg']="Le circuit ".$ligne->titreCircuit." est introuvable.";
			}
		}catch(Exception $e){
		}finally{
			unset($unModele);
		}
    }

    function desactiver($id)
    {
        global $tabRes;
        try
        {
            $requete="SELECT * FROM circuit WHERE idCircuit=?";			
			$unModele=new filmsModele($requete,array($id));
			$stmt=$unModele->executer();
			if($ligne=$stmt->fetch(PDO::FETCH_OBJ))
            {				
				$requete="UPDATE circuit SET etat = 0 WHERE idCircuit=?";
				$unModele=new filmsModele($requete,array($idf));
				$stmt=$unModele->executer();
				$tabRes['action']="desactiver";
				$tabRes['msg']="Le circuit ".$ligne->titreCircuit." a bien �t� d�sactiver.";
			}
			else{
				$tabRes['action']="desactiver";
				$tabRes['msg']="Le circuit ".$ligne->titreCircuit." est introuvable.";
			}
		}catch(Exception $e){
		}finally{
			unset($unModele);
		}
    }
	//******************************************************
	//Contr�leur
	$action=$_POST['action'];
    $id=$_POST['id'];//condition si pas de id
	switch($action)
    {
		case "enregistrer" :
			enregistrer($id);
		break;s
		case "lister" :            
			lister();            
		break;
		case "enlever" :
			enlever($id);
		break;
		case "fiche" :
			fiche($id);
		break;
		case "modifier" :
			modifier($idCircuit,idEtape,idJour);
		break;
        case "activer" :
			activer($id);
		break;
        case "desactiver" :
			desactiver($id);
		break;        
	}
    echo json_encode($tabRes);
?>