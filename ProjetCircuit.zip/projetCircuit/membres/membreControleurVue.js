
var membresVue=function(reponse)
{
    function listeMessages(reponse)
    {
        $('#adminAcceuil').html("");
        $('#formulaire').html("");
        var rep = '<div class="row marge-gauche custom-center">\
        <div class="col-sm-12 col-md-10 col-md-offset-1 custom-center"><br>\
            <table class="table table-hover table-striped">\
                <thead>\
                    <tr>\
                        <th class="text-center">Date</th>\
                        <th class="text-center">Sujet</th>\
                        <th class="text-center">Nom du membre</th>\
                        <th class="text-center">message</th>\
                        <th></th>\
                </thead>\
                <tbody>';    
    for (var i =0; i < reponse.listeMessages.length; i++)
    {          
        rep +=  '<tr>\
                    <td class="text-center"><strong>'+reponse.listeMessages[i].dateMessage+'</strong></td>\
                    <td class="text-center"><strong>'+reponse.listeMessages[i].titreMessage+'</strong></td>\
                    <td class="text-center"><strong>'+reponse.listeMessages[i].prenomUser+'&nbsp'+reponse.listeMessages[i].nomUser+'</strong></td>\
                    <td class="text-center"><strong>'+reponse.listeMessages[i].texteMessage+'</strong></td>\
                    <td class="text-center"><button type="button" class="btn btn-danger"\ onclick="supprimerMessage('+reponse.listeMessages[i].idMessage+')\">Supprimer</button></td>';
                          
    }    
    rep += '</tbody></table></div></div>';
        $('#adminAcceuil').html(rep); 
    }
    
	var action = reponse.action;    
	switch(action)
    {
		case "enregistrer" :
            document.getElementById("confirmFormEnregmembre").innerHTML = "Enregistrement réussi";
        break;
		case "login" :
            if(reponse.msgLogin == "OK")
            {
                document.location.href = "index.php";
            }
            else
            {
                document.getElementById("confirmFormLoginmembre").innerHTML = reponse.msgLogin;
            }
        break;
        case "logout" :
            if (reponse.retour == 'retour')
            {
                document.location.href = "../index.php";
            }
            else
            {
                document.location.href = "index.php";
            }
            console.log(reponse.retour);
        break;
        case "envoiMessage" :
            document.getElementById("confirmEnvoieMessage").innerHTML = reponse.msg;
        break;
        case "listeMessages" :
            listeMessages(reponse);
        break;
        case "supprimerMessage" :            
            listerMessage();
        break;
        default :
            console.log(reponse.action);
            
	}
}