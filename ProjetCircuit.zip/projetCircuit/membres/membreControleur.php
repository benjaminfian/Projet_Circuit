<?php
    session_start();
    require_once("../includes/modele.inc.php");    
	$tabRes=array();

	function enregistrer()
    {        
		global $tabRes;
        $nom=$_POST['nom'];
        $prenom=$_POST['prenom'];
        $dateNaissance=$_POST['dateNaissance'];                
        $sexe= $_POST['sexe'];
        $email= $_POST['email'];        
        $pass=$_POST['pass'];
        $tabRes['action']="enregistrer";
        try
        {   
            $requete="INSERT INTO user VALUES(0,?,?,?,?,now(),0)";
            $unModele=new circuitsModele($requete,array($nom,$prenom,$sexe,$dateNaissance));
            $stmt=$unModele->executer();

            $idUser= $_SESSION["id"];

            $requete2="INSERT INTO connexion VALUES(?,?,b?,?,?)";
            $unModele=new circuitsModele($requete2,array($email,$pass,1,'M',$idUser));
            $stmt=$unModele->executer();             

            $tabRes['action']="enregistrer";            
            //$tabRes['msg']="Le circuit ".$titre." a bien �t� enregistr�.";                    
        }
        catch(Exception $e)
        {
            
        }
        finally
        {
            unset($unModele);
        }		
	}
	
	function login()
    {	 
        global $tabRes;
        $tabRes['action']="login";
        $email=$_POST['logEmail'];
        $pwd=$_POST['pwd'];
        try
        {
            $requete = "SELECT * FROM connexion WHERE email=? AND pwd=?";
        
            $unModele=new circuitsModele($requete,array($email,$pwd));
            $stmt=$unModele->executer();        

            $ligne=$stmt->fetch(PDO::FETCH_OBJ);
            if ($ligne == null)
            {
                $tabRes['msgLogin']="Email ou mot de passe incorect";
                return;
            }            
            if (session_status() == PHP_SESSION_NONE) 
            { 
                session_start(); 
            }         
            $_SESSION['user']=$email;
            $_SESSION['typeUser']=$ligne->type;
            $tabRes['msgLogin']="OK";
        }
        catch(Exception $e)
        {
            $tabRes['msgLogin']="probleme avec la base de donn�es";
        }
        finally
        {
            unset($unModele);
        }        
	}

    function logout()
    {
        global $tabRes;
        $tabRes['action']="logout";
        if (isset ($_POST['retour']))
        {
            $tabRes['retour'] = $_POST['retour'];
        }        
        session_unset();
        session_destroy();        
	}

    function envoieMessage()
    {
        global $tabRes;
        $tabRes['action']="envoiMessage";
        $subject=$_POST['subject'];
        $message=$_POST['message'];
        $mail = $_SESSION['user'];
        
        try
        {
            $requete = "SELECT c.idUser FROM connexion c JOIN user u ON(c.idUser=u.idUser)WHERE c.email = ?";
            
            $unModele=new circuitsModele($requete,array($mail));
            $stmt=$unModele->executer();        

            $ligne=$stmt->fetch(PDO::FETCH_OBJ);
            if ($ligne == null)
            {
                $tabRes['msg']="probleme";
                return;
            }                
            $idUser = $ligne->idUser;
        
            $requete="INSERT INTO message VALUES(0,?,?,now(),?)";
            $unModele=new circuitsModele($requete,array($subject,$message,$idUser));
            $stmt=$unModele->executer();
            $tabRes['msg']="Votre message a bien ete envoye.";
        }
        catch(Exception $e)
        {
            $tabRes['msg']="probleme avec la base de donnees";
        }
        finally
        {
            unset($unModele);
        }        
    }
    
    function listeMessages()
    {
        global $tabRes;
        $tabRes['action']="listeMessages";
        try
        {
            $requete = "SELECT m.idMessage, m.titreMessage, m.texteMessage, m.dateMessage, u.prenomUser, u.nomUser FROM message m JOIN user u ON (m.idUser=u.idUser)";
            
            $unModele=new circuitsModele($requete,array());
            $stmt=$unModele->executer();        
            while($ligne=$stmt->fetch(PDO::FETCH_OBJ))
            {
			    $tabRes['listeMessages'][]=$ligne;
            }            
        }
        catch(Exception $e)
        {
            
        }
        finally
        {
            unset($unModele);
        }  
    }

    function supprimerMessage()
    {        
        global $tabRes;
        $tabRes['action']="supprimerMessage";
        $idMessage = $_POST['idMessage'];
        try
        {
            $requete = "DELETE FROM message WHERE idMessage=?";
            
            $unModele=new circuitsModele($requete,array($idMessage));
            $stmt=$unModele->executer();                      
        }
        catch(Exception $e)
        {
            
        }
        finally
        {
            unset($unModele);
        }          
    }

	//******************************************************
	//Contr�leur
	$action=$_POST['action'];        
	switch($action)
    {
		case "enregistrer" :
            enregistrer();            
		break;
		case "login" :             
			login();
		break;
        case "logout" :             
			logout();            
		break;
        case "envoieMessage" :
            envoieMessage();
        break;
        case "listeMessages" :
            listeMessages();
        break;
        case "supprimerMessage" :
            supprimerMessage();
        break;
	}
    echo json_encode($tabRes);
?>