var listePanier = [] //,nbrItemPanier = 0,prixPanierTotal = 0;
//panier = [];

/*function ajouterPanier(id,titre, prix, image) {
    var b = true;
    if (!localStorage.getItem('monPanier')) {
        listPanier.push({
            "id":id,
            "titre": titre,
            "prix": prix,
            "image": image            
        });
    } else {
        listPanier = JSON.parse(localStorage.getItem('monPanier'));
        for (var i in listPanier)
        {
            if (listPanier[i].titre == titre)
            {
                b = false;
            }
        }
        if (b)
        {
            listPanier.push({
            "id":id,
            "titre": titre,
            "prix": prix,
            "image": image
        });
        }        
    }
    localStorage.setItem("monPanier", JSON.stringify(listePanier));
    updatePanier();
}

function updatePanier() {
    var rep = "";
    var tab = JSON.parse(localStorage.getItem('monPanier'));
    qte = 0;
    if (tab != null && tab.length != 0) {
        for (var i = 0; i < tab.length; i++) {
            rep += '<li><div class="image"><img src="images/circuits/' + tab[i].image + '" alt="image"></div><strong><a href="#" onclick="return route(\'panier\',\'1\')">' + tab[i].titre + '</a>' + tab[i].prix + ' $ </strong><a href="#" class="action"><i class="icon-trash"></i></a></li>';
        }
        qte = tab.length;
    } else rep += "<li>Le panier est vide</li>";

    $('#cart_items').html(rep);
    $('.icon-shopping-cart').text(qte);
}
//Supprimer un produit du panier
function supprimer(id) {
    for (var i in panier)
        if (panier[i].id == id)
            panier.splice(panier.indexOf(panier[i]), 1);
    localStorage.setItem("monPanier", JSON.stringify(panier));
    updatePanier();
    $('#ligneProduits').html(lignesProduitsPanier());
}

//Les lignes des produits dans la page panier
function lignesProduitsPanier() {
    $('#ligneProduits').html("");
    var contenu = "";
    total = 0;
    panier = JSON.parse(localStorage.getItem('monPanier'));
    for (var i in panier) {
        total+=Number(panier[i].prix);
        contenu += '<tr>';
        contenu += '<td><div class="thumb_cart"><img src="images/circuits/'+panier[i].image+'" alt="Image"></div><span class="item_cart">'+panier[i].titre+' ( Départ le '+panier[i].dateDepart+')</span></td>';
        contenu += '<td><strong>' + panier[i].prix + ' $</strong></td>';
        contenu += '<td class="options"><a onclick="supprimer(' + panier[i].id + ')" href="#"><i class=" icon-trash"></i></a></td>';
        contenu += '</tr>';
    }
    $('#total').html(total+' $');
    return contenu;
}*/

function ajouterPanier(id, titre, prix ,image)
{        
    //var sel = document.getElementById("quantite"+id+"");        
    var quantite = 1;
    var circuit={"image":image,"titre":titre,"quantite":quantite,"prix":prix,"id":id};
      
    var taille=listePanier.length;
    if (taille === 0)
        {            
            listePanier.push(circuit);            
        }
    else 
    {
        var j = 0;
        for (j=0;j<taille;j++)
        {
            var unCircuit=listePanier[j];
            if(unCircuit.id == id)
            {                
                 unCircuit.quantite+=quantite;                
                 break;
            }            
        }
        if (j == taille)
            {                
                listePanier.push(circuit);                
            }
    }
	localStorage.setItem('monPanier', JSON.stringify(listePanier));
    //localStorage.setItem('nombre', JSON.stringify(nbrItemPanier));
    //localStorage.setItem('prix', JSON.stringify(prixPanierTotal));
	//sauver();    
    totalPanier();    
}

function supprimer(id)
{
    var taille=listePanier.length;
    for (var i=0;i<taille;i++)
    {
        var unCircuit=listePanier[i];
        if(unCircuit.id == id)
            {                
                listePanier.splice(i, 1);
                break;
            }        
    }    
    localStorage.setItem('monPanier', JSON.stringify(listePanier));
    //localStorage.setItem('nombre', JSON.stringify(nbrItemPanier));
    //localStorage.setItem('prix', JSON.stringify(prixPanierTotal));	
	//sauver();
	totalPanier();
    affichPanier();    
}

function retirer(id)
{
    var taille=listePanier.length;
    for (var i=0;i<taille;i++)
    {
        var unCircuit=listePanier[i];
        if(unCircuit.id == id)
            {                
                listePanier[i].quantite--;
                break;
            }        
    }    
    localStorage.setItem('monPanier', JSON.stringify(listePanier));
    //localStorage.setItem('nombre', JSON.stringify(nbrItemPanier));
    //localStorage.setItem('prix', JSON.stringify(prixPanierTotal));
	//sauver();
	totalPanier();
    affichPanier();
}

function affichPanier()
{    
    var image, titre, quantite = 0,prix = 0;
    $('#cart_items').html("");
    var rep = "";
    if (localStorage.getItem('monPanier') != null)
    {
        listePanier = JSON.parse(localStorage.getItem("monPanier"));
    }    
	var taille=listePanier.length;
    var totalHT = 0;
	rep+="<h2>Liste des circuits dans votre panier</h2><br><br><div class=\"row custom-center\"><div class=\"col-md-10 custom-center\"><button type=\"button\" id=\"vider\" class=\"btn btn-danger marge-bas float-right\" onclick=\"vider()\">Vider le panier</button><table class=\"table table-hover table-striped\"><thead><tr><th></th><th class=\"text-center\">Titre</th><th class=\"text-center\">Quantité</th><th class=\"text-center\">Prix</th><th> </th><th> </th></tr></thead><tbody>";
	for (var i=0;i<taille;i++){
		var unCircuit=listePanier[i];
		image=unCircuit.image;
		titre=unCircuit.titre;
        quantite=unCircuit.quantite;
        prix= parseFloat(unCircuit.prix);
        id=unCircuit.id;
        		
        rep+="<tr><td width=\"8%\"><div class=\"media\"><img class=\"img_crud\" src='../"+image+"' alt=\"Film numéro "+id+"\" title=\"image de la boite du film "+titre+"\"></div></td><td class=\"text-center\" width=\"34%\">"+titre+"</td><td class=\"text-center\" width=\"10%\">"+quantite+"</td><td class=\"text-center\" width=\"10%\">"+prix.toFixed(2)+"$</td>";
        if (unCircuit.quantite == 1)
            {
                rep+="<td width=\"13%\"></td><td class=\"text-center\" width=\"25%\"><button type=\"button\" class=\"btn btn-danger\" onclick=\"supprimer(\'"+id+"\')\">Supprimer</button></td>";                
            }
        else
            {
                rep+="<td class=\"text-center\" width=\"13%\"><button type=\"button\" class=\"btn btn-warning\" onclick=\"retirer(\'"+id+"\')\">Enlever 1 circuit</button></td><td class=\"text-center\" width=\"25%\"><button type=\"button\" class=\"btn btn-danger\" onclick=\"supprimer(\'"+id+"\')\">Supprimer</button></td>";                
            }
        rep+="</tr>";
        totalHT += (prix * quantite);
	}
    rep+="</tbody><tfoot><tr><td>   </td><td>   </td><td>   </td><td>   </td><td></td><td class=\"text-right\"><h3><strong>Sous-total:&nbsp;</strong>"+totalHT.toFixed(2)+"&nbsp;$</h3></td></tr>     <tr><td>   </td><td>   </td><td>   </td><td>   </td><td></td><td class=\"text-right\"><h3><strong>TVQ:&nbsp;</strong>"+(totalHT * 0.09975).toFixed(2)+"&nbsp;$</h3></td></tr>     <tr><td>   </td><td>   </td><td>   </td><td>   </td><td></td><td class=\"text-right\"><h3><strong>TPS:&nbsp;</strong>"+(totalHT * 0.05).toFixed(2)+"&nbsp;$</h3></td></tr>     <tr><td>   </td><td>   </td><td>   </td><td>   </td><td></td><td class=\"text-right\"><h3><strong>Total:&nbsp;</strong>"+(totalHT * 1.14975).toFixed(2)+"&nbsp;$</h3></td></tr></tfoot></table><button type=\"button\" id=\"commande\" class=\"btn btn-primary marge-bas float-right\" onclick=\"commander()\">Commander</button></div></div>";    
	$('#cart_items').html(rep);
    if(i == 0)
    {
        document.getElementById('vider').style.visibility = 'hidden';
        document.getElementById('commande').style.visibility = 'hidden';
    }
    totalPanier()
}

function totalPanier()
{
    $('.icon-shopping-cart').text("");
    nbrItemPanier = 0;
    prixPanierTotal = 0;
    var taille=listePanier.length;    
    for (var i=0;i<taille;i++)
    {
        nbrItemPanier+= listePanier[i].quantite;
        prixPanierTotal += listePanier[i].quantite * listePanier[i].prix;
    }
    var rep = "("+nbrItemPanier+")"+prixPanierTotal.toFixed(2)+"$";    
    //$('#totalPanier').html(rep);
    if (nbrItemPanier == 0)
    {
        $('.icon-shopping-cart').text("");
    }
    else
    {
        $('.icon-shopping-cart').text(rep);
    }
}

function vider()
{
    listePanier = [];
    //nbrItemPanier = 0;
    //prixPanierTotal = 0;
    localStorage.removeItem('monPanier');
    //localStorage.removeItem('nombre');
    //localStorage.removeItem('prix');
	//sauver();
    totalPanier();
    affichPanier();
}