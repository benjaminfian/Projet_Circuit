function accueilAdmin()//a effacer
{
    $('#contenu').html("");
    //temporaire
    var rep = '<p>Page d\'accueil administrateur</p>';
    rep+= '<button type="button" class="btn btn-success" onclick="listerCircuits()">Lister les circuits</button>';    
    $('#contenu').html(rep);    
}

function ouvrirEtapes(id)
{
    localStorage.setItem("idCircuit",id);
    document.location.href = "circuit.html";
}
