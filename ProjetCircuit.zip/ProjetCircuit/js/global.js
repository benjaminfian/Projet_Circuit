function accueilAdmin()//a effacer
{
    $('#contenu').html("");
    //temporaire
    var rep = '<p>Page d\'accueil administrateur</p>';
    rep+= '<button type="button" class="btn btn-success" onclick="listerCircuits()">Lister les circuits</button>';    
    $('#contenu').html(rep);    
}

function ouvrirEtapes(id)
{
    localStorage.setItem("idCircuit",id);
    document.location.href = "circuit.html";
}

function message()
{
    $('#adminAcceuil').html("");
    $('#formulaire').html("");
    var rep = '<div class="site-section bg-light">\
                <div class="container">\
                <div class="row">\
          <div class="col-md-7 mb-5">\
            <form id="formMessage" method="POST" class="p-5 bg-white">\
              <div class="row form-group">\
                <div class="col-md-12">\
                  <label class="text-black" for="sujet">Sujet</label>\
                  <input type="sujet" id="subject" name="subject" class="form-control" required>\
                </div>\
              </div>\
              <div class="row form-group">\
                <div class="col-md-12">\
                  <label class="text-black" for="message">Message</label>\
                  <textarea name="message" id="message" name="message" cols="30" rows="7" class="form-control" placeholder="Écrivez vos notes ou questions ici ..." required></textarea>\
                </div>\
              </div>\
              <div class="row form-group">\
                <div class="col-md-12">\
                  <input type="submit" onclick="envoyerMessage()" value="Envoyer le message" class="btn btn-primary py-2 px-4 text-white">\
                </div>\
              </div><span id="confirmEnvoieMessage"></span>\
            </form>\
          </div></div></div></div>';
    $('#adminAcceuil').html(rep); 
}
