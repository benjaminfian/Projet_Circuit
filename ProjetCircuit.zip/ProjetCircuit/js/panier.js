panier = [];
function ajouterPanier(titre, prix, image) {
    var b = true;
    if (!localStorage.getItem('monPanier')) {
        panier.push({
            "titre": titre,
            "prix": prix,
            "image": image
        });
    } else {
        panier = JSON.parse(localStorage.getItem('monPanier'));
        panier.push({
            "titre": titre,
            "prix": prix,
            "image": image
        });
    }
    localStorage.setItem("monPanier", JSON.stringify(panier));
    updatePanier();
}

function updatePanier() {
    var rep = "";
    var tab = JSON.parse(localStorage.getItem('monPanier'));
    qte = 0;
    if (tab != null && tab.length != 0) {
        for (var i = 0; i < tab.length; i++) {
            rep += '<li><div class="image"><img src="images/circuits/' + tab[i].image + '" alt="image"></div><strong><a href="#" onclick="return route(\'panier\',\'1\')">' + tab[i].titre + '</a>' + tab[i].prix + ' $ </strong><a href="#" class="action"><i class="icon-trash"></i></a></li>';
        }
        qte = tab.length;
    } else rep += "<li>Le panier est vide</li>";

    $('#cart_items').html(rep);
    $('.icon-shopping-cart').text(qte);
}
//Supprimer un produit du panier
function supprimer(id) {
    for (var i in panier)
        if (panier[i].idDepart == id)
            panier.splice(panier.indexOf(panier[i]), 1);
    localStorage.setItem("monPanier", JSON.stringify(panier));
    updatePanier();
    $('#ligneProduits').html(lignesProduitsPanier());
}

//Les lignes des produits dans la page panier
function lignesProduitsPanier() {
    $('#ligneProduits').html("");
    var contenu = "";
    total = 0;
    panier = JSON.parse(localStorage.getItem('monPanier'));
    for (var i in panier) {
        total+=Number(panier[i].prix);
        contenu += '<tr>';
        contenu += '<td><div class="thumb_cart"><img src="images/circuits/'+panier[i].image+'" alt="Image"></div><span class="item_cart">'+panier[i].titre+' ( Départ le '+panier[i].dateDepart+')</span></td>';
        contenu += '<td><strong>' + panier[i].prix + ' $</strong></td>';
        contenu += '<td class="options"><a onclick="supprimer(' + panier[i].idDepart + ')" href="#"><i class=" icon-trash"></i></a></td>';
        contenu += '</tr>';
    }
    $('#total').html(total+' $');
    return contenu;
}