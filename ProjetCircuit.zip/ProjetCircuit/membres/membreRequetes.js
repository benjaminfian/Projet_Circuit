function enregistrerMembre()
{    
    //alert();
    formMembre = document.getElementById('formEnregMembre');
    var pass1 = document.getElementById('pass').value;
    var pass2 = document.getElementById('pwConfirmation').value;
    if (pass1 == pass2)
    {
        var valid = formMembre.checkValidity();
        if (valid)
        {
            //alert("valid");
            event.preventDefault();
            formMembre = new FormData(formMembre);         
            formMembre.append('action','enregistrer');         
            $.ajax({
                type : 'POST',
                url : 'membres/membreControleur.php',
                data : formMembre,
                dataType : 'json',
                //async : false,
                //cache : false,
                contentType : false,
                processData : false,
                success : function (reponse){//alert(reponse);
                            membresVue(reponse);
                },
                fail : function (err){//alert("fail");
                }
            });
        }  
    }      
}

function login()
{ 
    formMembre = document.getElementById('formLogin');
    var valid = formMembre.checkValidity();
    if (valid)
    {
        //alert("valid");
        event.preventDefault();
        formMembre = new FormData(formMembre);         
        formMembre.append('action','login');         
        $.ajax({
            type : 'POST',
            url : 'membres/membreControleur.php',
            data : formMembre,
            dataType : 'json',
            //async : false,
            //cache : false,
            contentType : false,
            processData : false,
            success : function (reponse){//alert(reponse);
                        membresVue(reponse);
            },
            fail : function (err){//alert("fail");
            }
        });    
    }        
}

function logout()
{    
    formMembre = new FormData();         
    formMembre.append('action','logout');         
    $.ajax({
        type : 'POST',
        url : '../membres/membreControleur.php',
        data : formMembre,
        dataType : 'json',
        //async : false,
        //cache : false,
        contentType : false,
        processData : false,
        success : function (reponse){//alert(reponse);
                    membresVue(reponse);
        },
        fail : function (err){//alert("fail");
        }
    });
}

function envoyerMessage()
{    
    formMembre = document.getElementById('formMessage');
    var valid = formMembre.checkValidity();
    if (valid)
    {
        //alert("valid");
        event.preventDefault();
        formMembre = new FormData(formMembre);         
        formMembre.append('action','envoieMessage');         
        $.ajax({
            type : 'POST',
            url : '../membres/membreControleur.php',
            data : formMembre,
            dataType : 'json',
            //async : false,
            //cache : false,
            contentType : false,
            processData : false,
            success : function (reponse){//alert(reponse);
                        membresVue(reponse);
            },
            fail : function (err){//alert("fail");
            }
        });    
    }    
}

function listerMessage()
{    
    formMembre = new FormData();         
    formMembre.append('action','listeMessages');         
    $.ajax({
        type : 'POST',
        url : '../membres/membreControleur.php',
        data : formMembre,
        dataType : 'json',
        //async : false,
        //cache : false,
        contentType : false,
        processData : false,
        success : function (reponse){//alert(reponse);
                    membresVue(reponse);
        },
        fail : function (err){//alert("fail");
        }
    });
}

function supprimerMessage(id)
{
    formMembre = new FormData();         
    formMembre.append('action','supprimerMessage');
    formMembre.append('idMessage',id);
    $.ajax({
        type : 'POST',
        url : '../membres/membreControleur.php',
        data : formMembre,
        dataType : 'json',
        //async : false,
        //cache : false,
        contentType : false,
        processData : false,
        success : function (reponse){//alert(reponse);
                    membresVue(reponse);
        },
        fail : function (err){//alert("fail");
        }
    });
}




