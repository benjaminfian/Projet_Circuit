-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Май 21 2019 г., 04:54
-- Версия сервера: 10.1.40-MariaDB
-- Версия PHP: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `dbcircuits`
--

-- --------------------------------------------------------

--
-- Структура таблицы `activite`
--

CREATE TABLE `activite` (
  `descriptionActivite` text COLLATE utf8_unicode_ci NOT NULL,
  `idJour` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `activite`
--

INSERT INTO `activite` (`descriptionActivite`, `idJour`) VALUES
('Description avec images', 14),
('Description avec images', 15),
('Vous partirez Ã  pied vers Circular Quay pour la traversÃ©e en bateau vers Manly et sa cÃ©lÃ¨bre plage bordÃ©e de pins, son ambiance dÃ©contractÃ©e, ses surfeurs et sa charmante rue piÃ©tonne (boutiques, cafÃ©sâ€¦) Passage par le chemin cÃ´tier vers lâ€™anse de Shelly Beach. Retour au quai pour le bateau vers Watsons Bay et dÃ®ner au cÃ©lÃ¨bre restaurant Doyles On the Beach dâ€™oÃ¹ vous apercevez une vue imprenable sur la baie. Promenade cÃ´tiÃ¨re sur le Â«GapÂ» le long des falaises pour un panorama sur lâ€™ocÃ©an. Retour vers Circular Quay en bateau et visite de la Sydney Tower Eye avec sa vue Ã  360 degrÃ©s. Retour Ã  lâ€™hÃ´tel, fin dâ€™aprÃ¨smidi et souper libre. ', 16),
('JournÃ©e libre pour dÃ©couverte personnelle. (DJ) Option sur place ($) : Montagnes Bleues : DÃ©part avec votre guide francophone pour une journÃ©e dâ€™excursion aux Montagnes Bleues, lâ€™Echo Point et les Three Sisters, en passant par le parc animalier de Featherdale. DÃ®ner inclus. Retour Ã  Sydney en fin dâ€™aprÃ¨s-midi.', 17),
('Description avec images', 18),
('Vous partirez Ã  pied vers Circular Quay pour la traversÃ©e en bateau vers Manly et sa cÃ©lÃ¨bre plage bordÃ©e de pins, son ambiance dÃ©contractÃ©e, ses surfeurs et sa charmante rue piÃ©tonne (boutiques, cafÃ©sâ€¦) Passage par le chemin cÃ´tier vers lâ€™anse de Shelly Beach. Retour au quai pour le bateau vers Watsons Bay et dÃ®ner au cÃ©lÃ¨bre restaurant Doyles On the Beach dâ€™oÃ¹ vous apercevez une vue imprenable sur la baie. Promenade cÃ´tiÃ¨re sur le Â«GapÂ» le long des falaises pour un panorama sur lâ€™ocÃ©an. Retour vers Circular Quay en bateau et visite de la Sydney Tower Eye avec sa vue Ã  360 degrÃ©s. Retour Ã  lâ€™hÃ´tel, fin dâ€™aprÃ¨smidi et souper libre. ', 19),
('Description avec images', 20),
('Vous partirez Ã  pied vers Circular Quay pour la traversÃ©e en bateau vers Manly et sa cÃ©lÃ¨bre plage bordÃ©e de pins, son ambiance dÃ©contractÃ©e, ses surfeurs et sa charmante rue piÃ©tonne (boutiques, cafÃ©sâ€¦) Passage par le chemin cÃ´tier vers lâ€™anse de Shelly Beach. Retour au quai pour le bateau vers Watsons Bay et dÃ®ner au cÃ©lÃ¨bre restaurant Doyles On the Beach dâ€™oÃ¹ vous apercevez une vue imprenable sur la baie. Promenade cÃ´tiÃ¨re sur le Â«GapÂ» le long des falaises pour un panorama sur lâ€™ocÃ©an. Retour vers Circular Quay en bateau et visite de la Sydney Tower Eye avec sa vue Ã  360 degrÃ©s. Retour Ã  lâ€™hÃ´tel, fin dâ€™aprÃ¨smidi et souper libre. ', 21),
('JournÃ©e libre pour dÃ©couverte personnelle. (DJ) Option sur place ($) : Montagnes Bleues : DÃ©part avec votre guide francophone pour une journÃ©e dâ€™excursion aux Montagnes Bleues, lâ€™Echo Point et les Three Sisters, en passant par le parc animalier de Featherdale. DÃ®ner inclus. Retour Ã  Sydney en fin dâ€™aprÃ¨s-midi.', 22),
('Description avec images', 24),
('Soyez attentif aux premiÃ¨res glaces flottantes lorsque nous naviguerons en direction du nord. Vous apprÃ©cierez peut-Ãªtre une visite dans la salle de fitness, ou tout simplement un moment de dÃ©tente dans le salon panoramique', 25),
('La baie Tikhaya, ou \"baie silencieuse\" : câ€™est le lieu oÃ¹ une Ã©quipe de mÃ©tÃ©orologistes de la station russe Sedov fut bloquÃ©e au dÃ©but de la Seconde Guerre mondiale. Ils n\'ont Ã©tÃ© secourus qu\'en 1945. Nous aspirerons Ã  y passer la journÃ©e afin d\'explorer un peu l\'histoire et Ã©couter les cris des petits pingouins, semblables Ã  des rires, lorsqu\'ils vont et viennent en volant entre leur terrier dans les talus d\'Ã©boulis.', 26),
('Description avec images', 27),
('Soyez attentif aux premiÃ¨res glaces flottantes lorsque nous naviguerons en direction du nord. Vous apprÃ©cierez peut-Ãªtre une visite dans la salle de fitness, ou tout simplement un moment de dÃ©tente dans le salon panoramique', 28),
('La baie Tikhaya, ou \"baie silencieuse\" : câ€™est le lieu oÃ¹ une Ã©quipe de mÃ©tÃ©orologistes de la station russe Sedov fut bloquÃ©e au dÃ©but de la Seconde Guerre mondiale. Ils n\'ont Ã©tÃ© secourus qu\'en 1945. Nous aspirerons Ã  y passer la journÃ©e afin d\'explorer un peu l\'histoire et Ã©couter les cris des petits pingouins, semblables Ã  des rires, lorsqu\'ils vont et viennent en volant entre leur terrier dans les talus d\'Ã©boulis.', 29),
('Description avec images', 30),
('Soyez attentif aux premiÃ¨res glaces flottantes lorsque nous naviguerons en direction du nord. Vous apprÃ©cierez peut-Ãªtre une visite dans la salle de fitness, ou tout simplement un moment de dÃ©tente dans le salon panoramique', 31);

-- --------------------------------------------------------

--
-- Структура таблицы `circuit`
--

CREATE TABLE `circuit` (
  `idCircuit` int(11) NOT NULL,
  `titreCircuit` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `descriptionCircuit` text COLLATE utf8_unicode_ci NOT NULL,
  `prixCircuit` double NOT NULL,
  `etat` bit(1) NOT NULL DEFAULT b'0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `circuit`
--

INSERT INTO `circuit` (`idCircuit`, `titreCircuit`, `descriptionCircuit`, `prixCircuit`, `etat`) VALUES
(5, 'RÃŠVE AUSTRALIEN', '<p>L&rsquo;Australie se situe entre l&rsquo;oc&eacute;an Pacifique et Indien. La majorit&eacute; de la population est concentr&eacute;e sur le littoral est et sudest. L&rsquo;Australie occupe, par son &eacute;tendue, la sixi&egrave;me place parmi les plus vastes &eacute;tats du monde. Situ&eacute; de part et d&rsquo;autre du tropique du Capricorne, le paysage est extr&ecirc;mement vari&eacute;, allant de l&rsquo;impitoyable d&eacute;sert rouge &agrave; la verte et luxuriante for&ecirc;t tropicale. Pays r&eacute;put&eacute; dans le monde entier pour ses plages et le surf.</p>', 15000, b'1'),
(8, 'TRÃ‰SORS DE RUSSIE', '<p>La Russie, un vaste pays qui a tant de richesses &agrave; offrir aux voyageurs ! Deux villes majeures marqueront votre voyage&nbsp;: St-P&eacute;tersbourg et Moscou. Moderne, europ&eacute;enne, ponctu&eacute;e d&rsquo;une architecture &eacute;l&eacute;gante mais aussi de traces de l&rsquo;&eacute;poque socialiste, la ville est joyeuse et color&eacute;e. <strong>Vos exp&eacute;riences de voyageur y seront belles et vari&eacute;es.</strong>&nbsp;</p>', 10000, b'1');

-- --------------------------------------------------------

--
-- Структура таблицы `circuit_etape`
--

CREATE TABLE `circuit_etape` (
  `idCircuit` int(11) NOT NULL,
  `idEtape` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `circuit_etape`
--

INSERT INTO `circuit_etape` (`idCircuit`, `idEtape`) VALUES
(5, 55),
(5, 56),
(5, 57),
(8, 59),
(8, 60),
(8, 61);

-- --------------------------------------------------------

--
-- Структура таблицы `connexion`
--

CREATE TABLE `connexion` (
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `pwd` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `statut` bit(1) NOT NULL DEFAULT b'1',
  `type` enum('M','P','A') COLLATE utf8_unicode_ci NOT NULL,
  `idUser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `connexion`
--

INSERT INTO `connexion` (`email`, `pwd`, `statut`, `type`, `idUser`) VALUES
('admin@gmail.com', '123', b'1', 'A', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `detailscircuit`
--

CREATE TABLE `detailscircuit` (
  `idCircuit` int(11) NOT NULL,
  `dateDebutCircuit` date NOT NULL,
  `dateFinCircuit` date NOT NULL,
  `nbPlaceMin` int(11) NOT NULL,
  `nbPlaceMax` int(11) NOT NULL,
  `montantReservation` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `detailscircuit`
--

INSERT INTO `detailscircuit` (`idCircuit`, `dateDebutCircuit`, `dateFinCircuit`, `nbPlaceMin`, `nbPlaceMax`, `montantReservation`) VALUES
(5, '2019-06-29', '2019-07-14', 1, 25, 5000),
(8, '2019-06-20', '2019-07-04', 1, 12, 3000);

-- --------------------------------------------------------

--
-- Структура таблицы `detailsreservation`
--

CREATE TABLE `detailsreservation` (
  `idReservation` int(11) NOT NULL,
  `nbAdulte` int(11) NOT NULL,
  `nbEnfant` int(11) NOT NULL,
  `nbBebe` int(11) NOT NULL,
  `nbChambre` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `etape`
--

CREATE TABLE `etape` (
  `idEtape` int(11) NOT NULL,
  `titreEtape` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `descriptionEtape` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `etape`
--

INSERT INTO `etape` (`idEtape`, `titreEtape`, `descriptionEtape`) VALUES
(54, 'Archipel FranÃ§ois-Joseph ', '<p>Notre &eacute;quipe d\'exp&eacute;dition et ses coll&egrave;gues russes vous pr&eacute</p>'),
(55, 'SYDNEY', '<p>Rendez-vous au bout du monde &agrave; la d&eacute;couverte d&rsquo;une multitude de paysages et de cultures diff&eacute;rentes.</p>'),
(56, 'ALICE SPRINGS â€“ KINGS CANYON', '<p>Pour vous tous les plages et le surf...</p>'),
(57, 'PALM COVE', '<p>Les plages et le surf sont pour vous..</p>'),
(59, 'L\'archipel FranÃ§ois-Joseph', '<p>Nos futures escales par une s&eacute;rie d\'expos&eacute;s et conf&eacute;rences vous permettant de vous familiariser avec l\'histoire et la faune de l\'archipel Fran&ccedil;ois-Joseph</p>'),
(60, 'MOSCOU', '<p>Le soir, optez pour un spectacle sur la prestigieuse sc&egrave;ne du Bolcho&iuml; ou une d&eacute;gustation de caviar et vodka.</p>'),
(61, 'Lac BaÃ¯kal', '<p>Un voyage exceptionnel pour ceux qui aiment l&rsquo;aventure et les grands paysages.</p>');

-- --------------------------------------------------------

--
-- Структура таблицы `hebergement`
--

CREATE TABLE `hebergement` (
  `nomHebergement` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lienHebergement` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `idJour` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

--
-- Дамп данных таблицы `hebergement`
--

INSERT INTO `hebergement` (`nomHebergement`, `lienHebergement`, `idJour`) VALUES
('En bateau', 'En bateau', 14),
('Pan Pacific', 'https://www.panpacific.com/en.html', 15),
('Pan pacific', 'https://www.panpacific.com/en.html', 16),
('Rydges', 'https://www.rydges.com/accommodation/sydney-nsw/sydney-central/', 17),
('Pan Pacific', 'https://www.panpacific.com/en.html', 18),
('Pan pacific', 'https://www.panpacific.com/en.html', 19),
('Pan Pacific', 'https://www.panpacific.com/en.html', 20),
('Pan pacific', 'https://www.panpacific.com/en.html', 21),
('Rydges', 'https://www.rydges.com/accommodation/sydney-nsw/sydney-central/', 22),
('En bateau', 'En bateau', 24),
('En bateau', 'En bateau', 25),
('En bateau', 'En bateau', 26),
('En bateau', 'En bateau', 27),
('En bateau', 'En bateau', 28),
('En bateau', 'En bateau', 29),
('En bateau', 'En bateau', 30),
('En bateau', 'En bateau', 31);

-- --------------------------------------------------------

--
-- Структура таблицы `historique`
--

CREATE TABLE `historique` (
  `nom` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `prenom` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `age` int(11) NOT NULL,
  `sexe` enum('M','F') COLLATE utf8_unicode_ci NOT NULL,
  `dateVoyage` date NOT NULL,
  `titreCircuit` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `montant` double NOT NULL,
  `nbParticipant` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jour`
--

CREATE TABLE `jour` (
  `idJour` int(11) NOT NULL,
  `titreJour` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descriptionJour` text COLLATE utf8_unicode_ci,
  `idEtape` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `jour`
--

INSERT INTO `jour` (`idJour`, `titreJour`, `descriptionJour`, `idEtape`) VALUES
(14, 'titre', 'description', 54),
(15, 'titre', 'Départ pour la visite à pied de la ville avec votre guide francophone. En passant par Hyde Park et le Queen Victoria Building, découverte du quartier historique des Rocks. Dîner-croisière dans la baie à bord d’un catamaran qui vous mènera parmi les sites les plus renommés, tels que : le Sydney Harbour Bridge, le Fort Denison, le Luna Park et les demeures des milliardaires qui bordent la baie. Passage à l’extérieur au pied du célèbre Opéra de Sydney et balade dans les jardins botaniques. ', 55),
(16, 'titre', 'description', 55),
(17, 'titre', 'description', 55),
(18, 'titre', 'description', 56),
(19, 'titre', 'description', 56),
(20, 'titre', 'description', 57),
(21, 'titre', 'description', 57),
(22, 'titre', 'descriptionnm  ', 57),
(24, 'titre', 'description', 59),
(25, 'titre', 'description', 59),
(26, 'titre', 'description', 59),
(27, 'titre', 'description', 60),
(28, 'titre', 'description', 60),
(29, 'titre', 'description', 60),
(30, 'titre', 'description', 61),
(31, 'titre', 'description', 61);

-- --------------------------------------------------------

--
-- Структура таблицы `message`
--

CREATE TABLE `message` (
  `idMessage` int(11) NOT NULL,
  `titreMessage` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `texteMessage` text COLLATE utf8_unicode_ci NOT NULL,
  `dateMessage` datetime NOT NULL,
  `idUser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `paiement`
--

CREATE TABLE `paiement` (
  `idPaiement` int(11) NOT NULL,
  `datePaiement` date NOT NULL,
  `montantPaiement` double NOT NULL,
  `typePaiement` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `idReservation` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `participant`
--

CREATE TABLE `participant` (
  `nom` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `prenom` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dateNaissanceParticipant` date NOT NULL,
  `sexe` enum('M','F') COLLATE utf8_unicode_ci NOT NULL,
  `idReservation` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `pension`
--

CREATE TABLE `pension` (
  `nomPension` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lienPension` varchar(200) CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `idJour` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

--
-- Дамп данных таблицы `pension`
--

INSERT INTO `pension` (`nomPension`, `lienPension`, `idJour`) VALUES
('En bateau', 'En bateau', 14),
('Farm house kings cross', 'http://farmhousekingscross.com.au/', 15),
('The gantry', 'https://www.thegantry.com.au/', 16),
('The grand pavilion', 'https://www.thegrandpavilion.com.au/', 17),
('Farm house kings cross', 'http://farmhousekingscross.com.au/', 18),
('The gantry', 'https://www.thegantry.com.au/', 19),
('Farm house kings cross', 'http://farmhousekingscross.com.au/', 20),
('The gantry', 'https://www.thegantry.com.au/', 21),
('The grand pavilion', 'https://www.thegrandpavilion.com.au/', 22),
('En bateau', 'En bateau', 24),
('En bateau', 'En bateau', 25),
('En bateau', 'En bateau', 26),
('En bateau', 'En bateau', 27),
('En bateau', 'En bateau', 28),
('En bateau', 'En bateau', 29),
('En bateau', 'En bateau', 30),
('En bateau', 'En bateau', 31);

-- --------------------------------------------------------

--
-- Структура таблицы `promotion`
--

CREATE TABLE `promotion` (
  `idPromotion` int(11) NOT NULL,
  `pourcentagePromotion` double NOT NULL,
  `titrePromotion` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dateDebutPromotion` date NOT NULL,
  `dateFinPromotion` date NOT NULL,
  `idCircuit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `rabais`
--

CREATE TABLE `rabais` (
  `idRabais` int(11) NOT NULL,
  `montantRabais` double NOT NULL,
  `titreRabais` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dateDebutRabais` datetime NOT NULL,
  `dateFinRabais` datetime NOT NULL,
  `idUser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `reservation`
--

CREATE TABLE `reservation` (
  `idReservation` int(11) NOT NULL,
  `montantTotal` double NOT NULL,
  `PourcentageAcompte` double DEFAULT NULL,
  `annulation` bit(1) NOT NULL DEFAULT b'0',
  `dateReservation` datetime NOT NULL,
  `idUser` int(11) NOT NULL,
  `idCircuit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `tarif`
--

CREATE TABLE `tarif` (
  `idCircuit` int(11) NOT NULL,
  `prixBebe` double NOT NULL,
  `prixEnfant` double NOT NULL,
  `prixAdulte` double NOT NULL,
  `prixChambre` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `tarif`
--

INSERT INTO `tarif` (`idCircuit`, `prixBebe`, `prixEnfant`, `prixAdulte`, `prixChambre`) VALUES
(5, 0, 500, 1000, 500),
(8, 0, 200, 500, 300);

-- --------------------------------------------------------

--
-- Структура таблицы `test`
--

CREATE TABLE `test` (
  `idTest` int(11) NOT NULL,
  `titre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `bit` bit(1) DEFAULT b'0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `idUser` int(11) NOT NULL,
  `nomUser` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `prenomUser` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sexe` enum('M','F') CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `dateNaissance` date NOT NULL,
  `dateInscription` datetime NOT NULL,
  `panier` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`idUser`, `nomUser`, `prenomUser`, `sexe`, `dateNaissance`, `dateInscription`, `panier`) VALUES
(1, 'test', 'test', 'M', '2019-05-16', '2019-05-18 00:00:00', NULL),
(2, 'admin', 'admin', 'M', '1982-09-09', '2019-05-20 00:00:00', NULL);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `activite`
--
ALTER TABLE `activite`
  ADD KEY `idJour` (`idJour`);

--
-- Индексы таблицы `circuit`
--
ALTER TABLE `circuit`
  ADD PRIMARY KEY (`idCircuit`);

--
-- Индексы таблицы `circuit_etape`
--
ALTER TABLE `circuit_etape`
  ADD KEY `idCircuit` (`idCircuit`),
  ADD KEY `idEtape` (`idEtape`);

--
-- Индексы таблицы `connexion`
--
ALTER TABLE `connexion`
  ADD PRIMARY KEY (`email`),
  ADD KEY `idUser` (`idUser`);

--
-- Индексы таблицы `detailscircuit`
--
ALTER TABLE `detailscircuit`
  ADD KEY `idCircuit` (`idCircuit`);

--
-- Индексы таблицы `detailsreservation`
--
ALTER TABLE `detailsreservation`
  ADD KEY `idReservation` (`idReservation`);

--
-- Индексы таблицы `etape`
--
ALTER TABLE `etape`
  ADD PRIMARY KEY (`idEtape`);

--
-- Индексы таблицы `hebergement`
--
ALTER TABLE `hebergement`
  ADD KEY `idJour` (`idJour`);

--
-- Индексы таблицы `jour`
--
ALTER TABLE `jour`
  ADD PRIMARY KEY (`idJour`),
  ADD KEY `idEtape` (`idEtape`);

--
-- Индексы таблицы `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`idMessage`),
  ADD KEY `idUser` (`idUser`);

--
-- Индексы таблицы `paiement`
--
ALTER TABLE `paiement`
  ADD PRIMARY KEY (`idPaiement`),
  ADD KEY `idReservation` (`idReservation`);

--
-- Индексы таблицы `participant`
--
ALTER TABLE `participant`
  ADD KEY `idReservation` (`idReservation`);

--
-- Индексы таблицы `pension`
--
ALTER TABLE `pension`
  ADD KEY `idJour` (`idJour`);

--
-- Индексы таблицы `promotion`
--
ALTER TABLE `promotion`
  ADD PRIMARY KEY (`idPromotion`),
  ADD KEY `idCircuit` (`idCircuit`);

--
-- Индексы таблицы `rabais`
--
ALTER TABLE `rabais`
  ADD PRIMARY KEY (`idRabais`),
  ADD KEY `idUser` (`idUser`);

--
-- Индексы таблицы `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`idReservation`),
  ADD KEY `idUser` (`idUser`),
  ADD KEY `idCircuit` (`idCircuit`);

--
-- Индексы таблицы `tarif`
--
ALTER TABLE `tarif`
  ADD KEY `idCircuit` (`idCircuit`);

--
-- Индексы таблицы `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`idTest`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`idUser`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `circuit`
--
ALTER TABLE `circuit`
  MODIFY `idCircuit` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `etape`
--
ALTER TABLE `etape`
  MODIFY `idEtape` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT для таблицы `jour`
--
ALTER TABLE `jour`
  MODIFY `idJour` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT для таблицы `message`
--
ALTER TABLE `message`
  MODIFY `idMessage` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `promotion`
--
ALTER TABLE `promotion`
  MODIFY `idPromotion` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `rabais`
--
ALTER TABLE `rabais`
  MODIFY `idRabais` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `reservation`
--
ALTER TABLE `reservation`
  MODIFY `idReservation` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `test`
--
ALTER TABLE `test`
  MODIFY `idTest` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `activite`
--
ALTER TABLE `activite`
  ADD CONSTRAINT `activite_ibfk_1` FOREIGN KEY (`idJour`) REFERENCES `jour` (`idJour`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `circuit_etape`
--
ALTER TABLE `circuit_etape`
  ADD CONSTRAINT `circuit_etape_ibfk_1` FOREIGN KEY (`idCircuit`) REFERENCES `circuit` (`idCircuit`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `circuit_etape_ibfk_2` FOREIGN KEY (`idEtape`) REFERENCES `etape` (`idEtape`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `connexion`
--
ALTER TABLE `connexion`
  ADD CONSTRAINT `connexion_ibfk_1` FOREIGN KEY (`idUser`) REFERENCES `user` (`idUser`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `detailscircuit`
--
ALTER TABLE `detailscircuit`
  ADD CONSTRAINT `detailscircuit_ibfk_1` FOREIGN KEY (`idCircuit`) REFERENCES `circuit` (`idCircuit`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `detailsreservation`
--
ALTER TABLE `detailsreservation`
  ADD CONSTRAINT `detailsreservation_ibfk_1` FOREIGN KEY (`idReservation`) REFERENCES `reservation` (`idReservation`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `hebergement`
--
ALTER TABLE `hebergement`
  ADD CONSTRAINT `hebergement_ibfk_1` FOREIGN KEY (`idJour`) REFERENCES `jour` (`idJour`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `jour`
--
ALTER TABLE `jour`
  ADD CONSTRAINT `jour_ibfk_1` FOREIGN KEY (`idEtape`) REFERENCES `etape` (`idEtape`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `message`
--
ALTER TABLE `message`
  ADD CONSTRAINT `message_ibfk_1` FOREIGN KEY (`idUser`) REFERENCES `user` (`idUser`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `paiement`
--
ALTER TABLE `paiement`
  ADD CONSTRAINT `paiement_ibfk_1` FOREIGN KEY (`idReservation`) REFERENCES `reservation` (`idReservation`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `participant`
--
ALTER TABLE `participant`
  ADD CONSTRAINT `participant_ibfk_1` FOREIGN KEY (`idReservation`) REFERENCES `reservation` (`idReservation`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `pension`
--
ALTER TABLE `pension`
  ADD CONSTRAINT `pension_ibfk_1` FOREIGN KEY (`idJour`) REFERENCES `jour` (`idJour`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `promotion`
--
ALTER TABLE `promotion`
  ADD CONSTRAINT `promotion_ibfk_1` FOREIGN KEY (`idCircuit`) REFERENCES `circuit` (`idCircuit`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `rabais`
--
ALTER TABLE `rabais`
  ADD CONSTRAINT `rabais_ibfk_1` FOREIGN KEY (`idUser`) REFERENCES `user` (`idUser`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`idUser`) REFERENCES `user` (`idUser`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`idCircuit`) REFERENCES `circuit` (`idCircuit`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `tarif`
--
ALTER TABLE `tarif`
  ADD CONSTRAINT `tarif_ibfk_1` FOREIGN KEY (`idCircuit`) REFERENCES `circuit` (`idCircuit`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
