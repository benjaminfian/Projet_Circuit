<?php
//include '../include/header.php';
 echo '<script type="text/javascript">alert("")</script>';
require_once("include/connexion.inc.php");
$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$email=$_POST['email'];
$dateNaissance=$_POST['dateNaissance'];
$sexe=$_POST['sexe'];
$pass=$_POST['pass'];

$today = date("Y-m-d");

$requete="SELECT * FROM connexion WHERE email = ?";
$stmt = $connexion->prepare($requete);
$stmt->execute(array($email));
$ligne=$stmt->fetch(PDO::FETCH_OBJ);

if ($ligne == null)
{
$requete="INSERT INTO user VALUES(0,?,?,?,?,?)";
$stmt = $connexion->prepare($requete);
$stmt->execute(array($nom,$prenom,$sexe,$dateNaissance,$today,""));
$idMembre = $connexion->lastInsertId();
echo "Membre ".$idMembre." bien enregistré";

$requete="INSERT INTO connexion VALUES(?,?,0,?)";
$stmt = $connexion->prepare($requete);
$stmt->execute(array($email,$pass,1,'M',$idMembre));
$idMembre = $connexion->lastInsertId();
}
else
{    
    echo "Ce membre existe est déja enregistrer dans notre base de donnée. Entrer une adresse mail différente.";
}
?>

<?php
include '../include/footer.php';
?>

<meta http-equiv="refresh" content="1; url=<?php echo $_SERVER["HTTP_REFERER"]  ; ?>" />
