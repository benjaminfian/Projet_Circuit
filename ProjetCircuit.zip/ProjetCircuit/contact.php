<!DOCTYPE html>
<html lang="en">
  <head>
    <title>VaresAnto &mdash; Circuits</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,700,900|Display+Playfair:200,300,400,700"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/mediaelementplayer.min.css">


    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    
  </head>
  <body>
  
  <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
    
    <header class="site-navbar py-1" role="banner">

        <div class="container">
          <div class="row align-items-center">
            
            <div class="col-6 col-xl-2">
                <a href="index.html"><img src="images/logo.png" href="index.html" width="80%"></a>   
            </div>
            <div class="col-10 col-md-8 d-none d-xl-block">
              <nav class="site-navigation position-relative text-right text-lg-center" role="navigation">
  
                <ul class="site-menu js-clone-nav mx-auto d-none d-lg-block">
                  <li><a href="index.html">Accueil</a></li>
                  <li class="has-children">
                    <a href="circuits.html">Circuits</a>
                    <ul class="dropdown">
                      <li><a href="#">Japan</a></li>
                      <li><a href="#">Europe</a></li>
                      <li><a href="#">China</a></li>
                      <li><a href="#">France</a></li>
                    </ul>
                  </li>
                  <li><a href="discount.html">Promotions</a></li>
                  <li><a href="about.html">A propos</a></li>
                  <li class="active"><a href="contact.html">Contact</a></li>
                </ul>
              </nav>
            </div>
  
            <div class="col-6 col-xl-2 text-right">
              <div class="d-none d-xl-inline-block">
                <nav class="site-navigation position-relative text-right text-lg-center" role="navigation">
                <ul class="site-menu js-clone-nav ml-auto list-unstyled d-flex text-right mb-0" data-class="social">
  
                  <li>
                    <a href="#" class="pl-0 pr-3 text-black"><span class="icon-user-plus"></span></a>
                  </li>
                  <li>
                    <a href="#" class="pl-3 pr-3 text-black"><span class="icon-sign-in"></span></a>
                  </li>
                                  
                  <li class="has-children">
                      <a class="pl-3 pr-3 text-black" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="icon-language2"></span></a>
                      <ul class="dropdown">
                          <li><a class="dropdown-item" href="#" onclick="afficherSafari();"><img src="images/drapeau_fr.png" width="25px" >&nbsp;&nbsp;&nbsp;Français</a></li>
                          <li><a class="dropdown-item" href="#" onclick="afficherCroisiere();"><img src="images/drapeau_en.jpg" width="25px">&nbsp;&nbsp;&nbsp;Anglais</a></li>
                          <li><a class="dropdown-item" href="#" onclick="afficherHistorique();"><img src="images/drapeau_es.png" width="25px">&nbsp;&nbsp;&nbsp;Espagnol</a></li>
                        </ul>
                    </li>
  
                </ul>
                </nav>
              </div>
  
              <div class="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-black"><span class="icon-menu h3"></span></a></div>
  
            </div>
  
          </div>
        </div>
        
      </header>

  

   

    <div class="site-blocks-cover inner-page-cover" style="background-image: url(images/hero_bg_3.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center justify-content-center text-center">

            <div class="col-md-8" data-aos="fade-up" data-aos-delay="400">
              <h1 class="text-white font-weight-light">Contactez-nous</h1>
              <div><a href="index.html">Accueil</a> <span class="mx-2 text-white">&bullet;</span> <span class="text-white">Contact</span></div>
              
            </div>
          </div>
        </div>
      </div>  


    
    <div class="site-section bg-light">
      <div class="container">
        <div class="row">
          <div class="col-md-7 mb-5">

            

            <form action="#" method="POST" class="p-5 bg-white">
             

              <div class="row form-group">
                <div class="col-md-6 mb-3 mb-md-0">
                  <label class="text-black" for="prenom">Prénom</label>
                  <input type="text" id="prenon" name="prenom "class="form-control">
                </div>
                <div class="col-md-6">
                  <label class="text-black" for="nom">Nom</label>
                  <input type="text" id="nom" name="nom" class="form-control">
                </div>
              </div>

              <div class="row form-group">
                
                <div class="col-md-12">
                  <label class="text-black" for="email">Courriel</label> 
                  <input type="email" id="email" name="email" class="form-control">
                </div>
              </div>

              <div class="row form-group">
                
                <div class="col-md-12">
                  <label class="text-black" for="sujet">Sujet</label> 
                  <input type="sujet" id="subject" name="subject" class="form-control">
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <label class="text-black" for="message">Message</label> 
                  <textarea name="message" id="message" name="message" cols="30" rows="7" class="form-control" placeholder="Écrivez vos notes ou questions ici ..."></textarea>
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <input type="submit" onclick="" value="Envoyer le message" class="btn btn-primary py-2 px-4 text-white">
                </div>
              </div>

  
            </form>
          </div>
		  
          <?php
       
if (isset($_POST['nom'],$_POST['email'],$_POST['subject'],$_POST['message'])) {
    $nom=$_POST['nom'];
   
    $email=$_POST['email'];
	$subject=$_POST['subject'];
    $message=$_POST['message'];
   
    require 'phpmailer/PHPMailerAutoload.php';
    $mail = new PHPMailer();
    $mail->isSMTP();
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPSecure = "ssl";
    $mail->Port = 465;
    $mail->SMTPAuth = true;
    $mail->Username = 'circuit16701@gmail.com';
    $mail->Password = '@zerty01';

    $mail->setFrom($email,$nom);
	$mail->AddReplyTo($email,$nom);
    $mail->addAddress('circuit16701@gmail.com');
    $mail->Subject = $subject;
    $mail->Body = $message;
    
    if ($mail->send()){
       
        echo '<script>alert("Votre message a été bien envoyer");</script>';
       
    }    
    else
    {
        echo '<script>alert("Votre message n\'a pas été bien envoyer");</script> '.$mail->ErrorInfo.'</div>';
    }
        
        
        
     
  
}

?>

          <div class="col-md-5">
            
            <div class="p-4 mb-3 bg-white">
              <p class="mb-0 font-weight-bold">Adresse</p>
              <p class="mb-4">2030, boulevard Pie-IX, 4ème étage, Bureau 430, Montréal (Québec) H1V 2C8</p>

              <p class="mb-0 font-weight-bold">Téléphone</p>
              <p class="mb-4"><a href="#">+1 438 884 4188</a></p>

              <p class="mb-0 font-weight-bold">Courriel</p>
              <p class="mb-0"><a href="#">circuit16701@gmail.com</a></p>

            </div>
            
            <div class="p-4 mb-3 bg-white">
              <img src="images/hero_bg_1.jpg" alt="Image" class="img-fluid mb-4 rounded">
              <h3 class="h5 text-black mb-3">Plus d'informations</h3>
              <p> Créée en 2018, est une entreprise basée à Montréal qui propose les circuits touristiques fantastiques partout au monde sans aucune limites au niveau du services,  du prix, de destination.</p>
              <p><a href="#" class="btn btn-primary px-4 py-2 text-white">En savoir plus</a></p>
            </div>

          </div>
        </div>
      </div>
    </div>

    
    <footer class="site-footer">
        <div class="container">
          <div class="row">
            <div class="col-lg-4">
              <div class="mb-5">
                <h3 class="footer-heading mb-4">Adresse</h3>
                <p> 2030, boulevard Pie-IX<br>
                    4ème étage, Bureau 430<br>
                    Montréal (Québec) H1V 2C8
                </p>
              </div> 
            </div>
            <div class="col-lg-4 mb-5 mb-lg-0">
              <div class="row mb-5">
                <div class="col-md-12">
                  <h3 class="footer-heading mb-4">Navigation</h3>
                </div>
                <div class="col-md-6 col-lg-6">
                  <ul class="list-unstyled">
                    <li><a href="index.html">Accueil</a></li>
                    <li><a href="circuits.html">Circuits</a></li>
                    <li><a href="discount.html">Promotions</a></li>
                  </ul>
                </div>
                <div class="col-md-6 col-lg-6">
                  <ul class="list-unstyled">
                    <li><a href="contact.html">Contact</a></li>
                    <li><a href="#services">Services</a></li>
                    <li><a href="about.html">A propos</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-lg-4 mb-5 mb-lg-0">
              <div class="mb-5">
                <h3 class="footer-heading mb-4">Abonnez-vous</h3>
                <p>Abonnez-vous à notre bulletin et obtenez 5% de réduction sur votre premier Circuit.</p>
                <form action="#" method="post">
                  <div class="input-group mb-3">
                    <input type="text" class="form-control border-secondary text-white bg-transparent" placeholder="Entrer Email" aria-label="Enter Email" aria-describedby="button-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary text-white" type="button" id="button-addon2">Abonner</button>
                    </div>
                  </div>
                </form>
  
              </div>
  
            </div>
            
          </div>
          <div class="row pt-5 mt-5 text-center">
            <div class="col-md-12">
              <div class="mb-5">
                <a href="#" class="pl-0 pr-3"><span class="icon-facebook"></span></a>
                <a href="#" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
                <a href="#" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
                <a href="#" class="pl-3 pr-3"><span class="icon-linkedin"></span></a>
              </div>
  
              <p>
              &copy; <script>document.write(new Date().getFullYear());</script>  Tous droits réservés.
              <a href="index.html" target=""> VaresAnto</a> <i class="icon-heart-o" aria-hidden="true"></i>
              </p>
            </div>
            
          </div>
        </div>
      </footer>
  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/main.js"></script>
  <script src="membres/membreRequetes.js"></script>
  <script src="membres/membreControleurVue.js"></script> 
    
  </body>
</html>