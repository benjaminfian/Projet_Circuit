<?php
require_once("connexion.inc.php");
class circuitsModele{
	private $requete;
	private $params;
	private $connexion;
	
function __construct($requete=null,$params=null){
		$this->requete=$requete;
		$this->params=$params;
}
	
function obtenirConnexion(){
	$maConnexion = new Connexion("localhost", "root", "", "dbcircuits");
	$maConnexion->connecter();
	return $maConnexion->getConnexion();
}

function executer(){
		$this->connexion = $this->obtenirConnexion();
		$stmt = $this->connexion->prepare($this->requete);
		$stmt->execute($this->params);
        if (session_status() == PHP_SESSION_NONE) 
        { 
            session_start(); 
        }        
        if($this->requete == "INSERT INTO circuit VALUES(0,?,?,?,0)" || $this->requete == "INSERT INTO etape VALUES(0,?,?)" || $this->requete == "INSERT INTO jour VALUES(0,?,?,?)" || "INSERT INTO user VALUES(0,?,?,?,?,now(),0)")
        {
            $lastID = $this->connexion->lastInsertId();   
            $_SESSION["id"] = $lastID;
        }               
		$this->deconnecter();
		return $stmt;		
	}
function deconnecter(){
		unset($this->connexion);
}
    
function verserFichier($dossier, $inputNom, $chaine)
{
    //$images=$_FILES['images']['name'];
    	
    $total = count($_FILES[$inputNom]['name']);
    if($total != 0)
    {
        for( $i=0 ; $i < $total ; $i++ )
        {
            //Upload de la photo
            $nomImage=sha1($chaine.time().$i);
            $tmp = $_FILES[$inputNom]['tmp_name'][$i];
            $fichier= $_FILES[$inputNom]['name'][$i];
            $extension=strrchr($fichier,'.');
            @move_uploaded_file($tmp,$dossier."/".$nomImage.$extension);
            // Enlever le fichier temporaire chargé
            @unlink($tmp); //effacer le fichier temporaire                    
        }        
    }		
}
    
//src : https://jeanbaptistemarie.com/notes/code/php/supprimer-un-dossier-avec-php.html
function enleverDossier($dossier) 
{
    error_reporting(0);
    $dir_iterator = new RecursiveDirectoryIterator($dossier);
    $iterator = new RecursiveIteratorIterator($dir_iterator, RecursiveIteratorIterator::CHILD_FIRST);
    foreach($iterator as $fichier)
    {
        $fichier->isDir() ? rmdir($fichier) : unlink($fichier);
    }
    rmdir($dossier);
}
    
}
?>