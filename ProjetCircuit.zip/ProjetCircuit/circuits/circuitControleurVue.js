var idCircuit,idEtape,codeCircuit,codeEtape = 0;
//vue Circuit

function listeCircuits(reponse)
{
$('#formulaire').html("");
    $('#adminAcceuil').html("");
    var rep = '<div class="row marge-gauche custom-center">\
        <div class="col-sm-12 col-md-10 col-md-offset-1 custom-center"><br>\
            <button type="button" class="btn btn-success marge-bas" onclick="nouveauCircuit();">Ajouter un circuit</button>\
            <table class="table table-hover table-striped">\
                <thead>\
                    <tr>\
                        <th>image</th>\
                        <th class="text-center">Titre</th>\
                        <th class="text-center">Nombre d\'étapes</th>\
                        <th class="text-center">Date de début</th>\
                        <th class="text-center">Date de fin</th>\
                        <th class="text-center">Prix</th>\
                        <th></th><th></th><th></th></tr>\
                </thead>\
                <tbody>';    
    for (var i =0; i < reponse.listeCircuits.length; i++)
    {          
        rep +=  '<tr>\
                    <td >\
                        <div class="media">\
                                <img class="img_crud" src="'+reponse.listeImages[i]+'" alt="Circuit '+reponse.listeCircuits[i].idCircuit+'" title="image du circuit'+reponse.listeCircuits[i].titreCircuit+'">\
                        </div>\
                    </td>\
                    <td class="text-center"><strong>'+reponse.listeCircuits[i].titreCircuit+'</strong></td>\
                    <td class="text-center"><strong>'+reponse.listeCircuits[i].nbEtape+'</strong></td>\
                    <td class="text-center"><strong>'+reponse.listeCircuits[i].dateDebutCircuit+'</strong></td>\
                    <td class="text-center"><strong>'+reponse.listeCircuits[i].dateDebutCircuit+'</strong></td>\
                    <td class="text-center"><strong>'+reponse.listeCircuits[i].prixCircuit+' $</strong></td>';
        if (reponse.listeCircuits[i].etat == 0)
        {
            rep += '<td class="text-center"><button type="button" class="btn btn-success"\ onclick="obtenirFicheCircuit('+reponse.listeCircuits[i].idCircuit+')\">Modifier</button></td>\
                    <td class="text-center"><button type="button" class="btn btn-danger"\ onclick="supprimerCircuit('+reponse.listeCircuits[i].idCircuit+')\">Supprimer</button></td>\
                    <td class="text-center"><button type="button" class="btn btn-primary"\ onclick="activerCircuit('+reponse.listeCircuits[i].idCircuit+')\">Activer</button></td></tr>';    
        }
        else
        {
            rep += '<td></td><td></td>\
                    <td class="text-center"><button type="button" class="btn btn-secondary" onclick="desactiverCircuit('+reponse.listeCircuits[i].idCircuit+')\">Desactiver</button></td></tr>';    
        }                    
    }    
    rep += '</tbody></table></div></div></div>';
    $('#adminAcceuil').html(rep);
}

function listeCircuitsClient(reponse)
{
    $('#listeCircuits').html(""); 
    var rep = '<div class="row">';
    for (var i =0; i < reponse.listeCircuits.length; i++)
    {        
          rep += '<div class="col-md-6 col-lg-4 mb-4 mb-lg-4">\
            <a href="#" class="unit-1 text-center" onclick="ouvrirEtapes('+reponse.listeCircuits[i].idCircuit+')">\
              <img style="height:300px" src="'+reponse.listeImages[i]+'" alt="Image" class="img-fluid">\
              <div class="unit-1-text">\
                <h3><strong class="text-primary mb-2 d-block">'+reponse.listeCircuits[i].prixCircuit+'$</strong></h3>\
                <h3 class="unit-1-heading">'+reponse.listeCircuits[i].titreCircuit+'</h3>\
              </div>\
            </a>\
          </div>';
    }
    rep += '</div>';
    $('#listeCircuits').html(rep);
}

function listeEtapes(reponse)
{
    $('#listeEtapes').html("");
    var rep = '<div class="site-blocks-cover inner-page-cover" style="background-image: url(images/hero_bg_2.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">\
        <div class="container">\
          <div class="row align-items-center justify-content-center text-center">\
            <div class="col-md-8" data-aos="fade-up" data-aos-delay="400">\
              <h1 class="text-white font-weight-light">Circuit</h1>\
              <p class="text-white lead">&ldquo;Découvrez les circuits accompagnés par VaresAnto, une formule pour voyager en toute tranquillité ! Élaborés par nos experts, ils s’appuient sur un réseau de partenaires et de guides sélectionnés pour leurs connaissances et leur professionnalisme.&rdquo;</p>\
              <p class="mb-5"></p>\
                  <a class="btn btn-primary py-3 px-5 text-white" href="'+reponse.listeImages[0]+'" data-lightbox="imgGLR">Galerie</a>';
                  for (var i =1; i < reponse.listeImages.length; i++)
                  {                     
                     rep+='<a href="'+reponse.listeImages[i]+'" data-lightbox="imgGLR"></a>' 
                  }                  
        rep+='</div>\
          </div>\
        </div>\
      </div>\
      <div class="site-section">\
          <div class="container">\
              <nav class="nav nav-pills nav-fill">';
			
                  for (var j =1; j <= reponse.nbEtapes; j++)
                  {
                     var actif = "";
                     if (j == 1)
                     {
                         actif = "active";
                     }
                     else
                     {
                         actif = "";
                     }
                     rep+='<a class="nav-item nav-link btn-primary '+actif+'" href="#pE'+j+'" data-toggle="tab" >Etape '+j+'</a>'; 
                  }                  
        rep+='</nav>\
                <div class="tab-content">';
                  var nJourTotal=0;
                  for (var k =1; k <= reponse.nbEtapes; k++)
                  {
                     var actif = "";
                     if (k == 1)
                     {
                         actif2 = "active";
                     }
                     else
                     {
                         actif2 = "";
                     }  
                     rep+='<div class="tab-pane '+actif2+'" id="pE'+k+'"><p class="mb-5"></p>\
                    <div class="boxes row">\
                        <div class="col-md-4">\
                          <div class="grid_4">\
                            <figure>\
                              <div><img style="height:300px" src="'+reponse.listeImages[k-1]+'" alt="image etape "></div>\
                              <figcaption>';                               
                               for (var l =0; l < reponse.listeEtapes.length; l++)
                              {
                                  if (reponse.listeEtapes[l].idEtape > codeEtape)
                                  {
                                      rep+= '<h3>'+reponse.listeEtapes[l].titreEtape+'</h3>\
                                '+reponse.listeEtapes[l].descriptionEtape+'</figcaption>';
                                      codeEtape = reponse.listeEtapes[l].idEtape;
                                      break;
                                  }
                              }                                
                     rep+='</figure>\
                          </div>\
                        </div>\
                        <div class="col-md-8">\
                            <nav class="nav nav-tabs">';
                                var nJour = 1;
                                for (var m =0; m < reponse.listeEtapes.length; m++)
                                {                                    
                                    if (reponse.listeEtapes[m].idEtape == codeEtape)
                                    {
                                        if (nJour == 1)
                                        {
                                            rep+='<a class="nav-item nav-link active" href="#pJ'+eval(nJour + nJourTotal)+'" data-toggle="tab">Jour '+nJour+'</a>';
                                        }
                                        else
                                        {
                                            rep+='<a class="nav-item nav-link" href="#pJ'+eval(nJour + nJourTotal)+'" data-toggle="tab">Jour '+nJour+'</a>';
                                        }
                                        nJour++;                                        
                                    }
                                }                                
                      rep+='</nav>\
                              <div class="tab-content">';
                                nJour = 1;
                                var compteur=0;
                                for (var m =0; m < reponse.listeEtapes.length; m++)
                                {                                    
                                    if (reponse.listeEtapes[m].idEtape == codeEtape)
                                    {
                                        if (nJour == 1)
                                        {
                                            rep+='<div class="tab-pane active" id="pJ'+eval(nJour + nJourTotal)+'">'+reponse.listeEtapes[m].descriptionActivite+'<br><br><p>Hotel : <a href="'+reponse.listeEtapes[m].lienHebergement+'">'+reponse.listeEtapes[m].nomHebergement+'</a></p><br><br><p>Restaurant : <a href="'+reponse.listeEtapes[m].lienPension+'">'+reponse.listeEtapes[m].nomPension+'</a></p></div>';
                                        }
                                        else
                                        {
                                            rep+='<div class="tab-pane" id="pJ'+eval(nJour + nJourTotal)+'">'+reponse.listeEtapes[m].descriptionActivite+'<br><br><p>Hotel : <a href="'+reponse.listeEtapes[m].lienHebergement+'">'+reponse.listeEtapes[m].nomHebergement+'</a></p><br><br><p>Restaurant : <a href="'+reponse.listeEtapes[m].lienPension+'">'+reponse.listeEtapes[m].nomPension+'</a></p></div>';
                                        }
                                        nJour++;
                                        compteur++;
                                    }
                                }
                                nJourTotal+= compteur;
                        rep+='</div>\
                        </div>\
                      </div>\
                  </div>'; 
                  }                 
rep+='</div>\
  </div>';
    $('#listeEtapes').html(rep);
}

function afficheFiche(reponse)
{
    $('#contenu').html("");
    var uneFiche;
    if(reponse.OK)
    {
        uneFiche=reponse.circuit;
        var test = JSON.stringify(uneFiche);
        /*$('#formFicheF h3:first-child').html("Fiche du film numero "+uneFiche.idf);
        $('#idf').val(uneFiche.idf);
        $('#titreF').val(uneFiche.titre);
        $('#dureeF').val(uneFiche.duree);
        $('#resF').val(uneFiche.res);
        $('#divFormFiche').show();
        document.getElementById('divFormFiche').style.display='block';*/
    }
    else
    {
        /*$('#messages').html("Film "+$('#numF').val()+" introuvable");
        setTimeout(function(){ $('#messages').html(""); }, 5000);*/
    }
    $('#contenu').html(rep);
}

var circuitsVue=function(reponse)
{
	var action = reponse.action;    
	switch(action)
    {
		case "enregistrer" :
            if(reponse.idCircuit)
            {
                idCircuit = reponse.idCircuit;
                saveCircuit();
                //alert(idCircuit);                
            }                
            if(reponse.idEtape)
            {
                idEtape = reponse.idEtape;
                saveEtape(nbEtape);
                $('#ajouteEtape').attr("disabled", false);
                
                //ajouterJour(nbEtape);
                
                //alert(idEtape);                
            }            
            if(reponse.msgTarif)
            {
             //   alert(reponse.msgTarif);
                $('#msgTarif').html("");
                $('#msgTarif').html(reponse.msgTarif);
            }
            if(reponse.msgPromotion)
            {
                $('#msgPromotion').html("");
                $('#msgPromotion').html(reponse.msgPromotion);
            }
            if(reponse.msgJour)
            {
                $('#ajouterJour' + nbEtape).attr("disabled", false);
                
                $('#jourSup' + nbEtape + nbJour + '').attr("disabled", true);
                $('#jourSvg' + nbEtape + nbJour + '').attr("disabled", true);
                
                //ajouterJour(nbEtape);
                
                //alert(reponse.msgJour);                
            }
        break;
		case "enlever" :
            listerCircuits();
        break;
		case "modifier" :
            listerCircuits();
        break;            
		case "lister" :            
			listeCircuits(reponse);            
		break;
        case "listeCircuits" :            
			listeCircuitsClient(reponse);            
		break;
        case "listeEtapes" :            
			listeEtapes(reponse);            
		break;
		case "fiche" :
			//afficheFiche(reponse);
          //  alert(reponse.action);
		break;
        case "activer" :
			listerCircuits();
		break;
        case "desactiver" :
			listerCircuits();
		break;
        default :
            console.log(reponse.action);        
	}
}