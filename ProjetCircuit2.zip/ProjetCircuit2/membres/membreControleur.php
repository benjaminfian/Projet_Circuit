<?php
    require_once("../includes/modele.inc.php");    	
	$tabRes=array();

	function enregistrer()
    {        
		global $tabRes;
        $nom=$_POST['nom'];
        $prenom=$_POST['prenom'];
        $dateNaissance=$_POST['dateNaissance'];                
        $sexe= $_POST['sexe'];
        $email= $_POST['email'];        
        $pass=$_POST['pass'];
        $tabRes['action']="enregistrer";
        try
        {   
            $requete="INSERT INTO user VALUES(0,?,?,?,?,now(),0)";
            $unModele=new circuitsModele($requete,array($nom,$prenom,$sexe,$dateNaissance));
            $stmt=$unModele->executer();

            $idUser= $_SESSION["id"];

            $requete2="INSERT INTO connexion VALUES(?,?,b?,?,?)";
            $unModele=new circuitsModele($requete2,array($email,$pass,1,'M',$idUser));
            $stmt=$unModele->executer();             

            $tabRes['action']="enregistrer";            
            //$tabRes['msg']="Le circuit ".$titre." a bien �t� enregistr�.";                    
        }
        catch(Exception $e)
        {
            
        }
        finally
        {
            unset($unModele);
        }		
	}
	
	function login()
    {	 
        global $tabRes;
        $tabRes['action']="login";
        $email=$_POST['logEmail'];
        $pwd=$_POST['pwd'];
        $requete = "SELECT * FROM connexion WHERE email=? AND pwd=?";
        
        $unModele=new circuitsModele($requete,array($email,$pwd));
        $stmt=$unModele->executer();        
        
        $ligne=$stmt->fetch(PDO::FETCH_OBJ);
        if ($ligne == null)
        {
            $tabRes['msgLogin']="Email ou mot de passe incorect";
            return;
        }
        if (session_status() == PHP_SESSION_NONE) 
        { 
            session_start(); 
        }         
        $_SESSION['user']=$email;
        $tabRes['msgLogin']="OK";
	}

    function logout()
    {
        global $tabRes;
        $tabRes['action']="logout";
        session_unset();
        //session_destroy();        
	}

    
	//******************************************************
	//Contr�leur
	$action=$_POST['action'];        
	switch($action)
    {
		case "enregistrer" :
            enregistrer();            
		break;
		case "login" :             
			login();
		break;
        case "logout" :             
			logout();
		break;               
	}
    echo json_encode($tabRes);
?>