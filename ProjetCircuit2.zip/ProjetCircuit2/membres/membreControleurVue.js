
var membresVue=function(reponse)
{
	var action = reponse.action;    
	switch(action)
    {
		case "enregistrer" :
            document.getElementById("confirmFormEnregmembre").innerHTML = "Enregistrement réussi";
        break;
		case "login" :
            if(reponse.msgLogin == "OK")
            {
                document.location.href = "viewsCircuit/admin.php";
            }
            else
            {
                document.getElementById("confirmFormLoginmembre").innerHTML = reponse.msgLogin;
            }
        break;
        case "logout" :
            document.location.href = "../index.html";
        break;
        default :
            console.log(reponse.action);        
	}
}