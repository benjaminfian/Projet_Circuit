<!doctype html>
<html lang="fr">

<head><!---->  
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
        <script language="javascript" src="../js/jquery-3.3.1.min.js"></script>
        <script language="javascript" src="../js/global.js"></script>
        <script language="javascript" src="../circuits/circuitRequetes.js"></script>    
        <script language="javascript" src="../circuits/circuitControleurVue.js"></script>
    
       
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
            integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
            crossorigin="anonymous"></script>
       
        <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
        <script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
		
        <script src="../js/formulaire.js"></script>	
      
    
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../css/bootstrap-grid.min.css">
        <link rel="stylesheet" href="../css/bootstrap-reboot.min.css">
        <link rel="stylesheet" href="../css/monCSS.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,700,900|Display+Playfair:200,300,400,700"><link href="https://fonts.googleapis.com/css?family=Roboto+Slab" rel="stylesheet">
        
        
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/css/bootstrap-datepicker.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
            integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
        <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet"
            href="https://cloud.tinymce.com/5/tinymce.min.js?apiKey=bf1dckm1oallcnw9kiu10dbo0s87xnd804mg9go70pdi4kxk&fbclid=IwAR3upVC5kNBxCXaDtwcUNi0O02_qG1IuhnJD9eFjEl6TbY558fB33d8FaX4">
        <link rel="stylesheet" href="../css/styleFormulaire.css">  

<!---->
   
    <link rel="stylesheet" href="../css/magnific-popup.css">
    <link rel="stylesheet" href="../css/jquery-ui.css">
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">

    <link rel="stylesheet" href="../css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="../fonts/flaticon/font/flaticon.css">
	 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,700,900|Display+Playfair:200,300,400,700"> 
    <link rel="stylesheet" href="../fonts/icomoon/style.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/mediaelementplayer.min.css">


    <link rel="stylesheet" href="../css/aos.css">

    <link rel="stylesheet" href="../css/style.css">

		

</head>

<body >
    <div id="contenu">
        
		    <header class="site-navbar py-1" role="banner">

      <div class="container">
        <div class="row align-items-center">
          
          <div class="col-6 col-xl-2">
              <a href="../index.html"><img src="../images/logo.png" href="../index.html" width="80%"></a>   
          </div>
          <div class="col-10 col-md-8 d-none d-xl-block">
            <nav class="site-navigation position-relative text-right text-lg-center" role="navigation">

              <ul class="site-menu js-clone-nav mx-auto d-none d-lg-block">
                <li class="">
                  <a href="../index.html">Accueil</a>
                </li>
                <li class="has-children">
                  <a href="circuits.html">Circuits</a>
                  <ul class="dropdown">
                    <li><a href="#">Japan</a></li>
                    <li><a href="#">Europe</a></li>
                    <li><a href="#">China</a></li>
                    <li><a href="#">France</a></li>
                  </ul>
                </li>
                <li><a href="discount.html">Promotions</a></li>
                <li class="has-children">
                  <a href="circuits.html">Administrateur</a>
                  <ul class="dropdown">
                    <li><a href="javascript:listerCircuits();">Gestion de circuits</a></li>
                    <li><a href="#">Messages</a></li>
                    <li><a href="#">Gestion de personnel</a></li>
                  
                  </ul>
                </li>
              </ul>
            </nav>
          </div>

          <div class="col-6 col-xl-2 text-right">
            <div class="d-none d-xl-inline-block">
              <nav class="site-navigation position-relative text-right text-lg-center" role="navigation">
              <ul class="site-menu js-clone-nav ml-auto list-unstyled d-flex text-right mb-0" data-class="social">
                
                <li>
                  <a class="btn" onclick="logout()"><span class="icon-sign-in"></span></a>
                </li>
                                
                <li class="has-children">
                    <a class="pl-3 pr-3 text-black" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="icon-language2"></span></a>
                    <ul class="dropdown">
                        <li><a class="dropdown-item" href="#" onclick="afficherSafari();"><img src="../images/drapeau_fr.png" width="25px" >&nbsp;&nbsp;&nbsp;Français</a></li>
                        <li><a class="dropdown-item" href="#" onclick="afficherCroisiere();"><img src="../images/drapeau_en.jpg" width="25px">&nbsp;&nbsp;&nbsp;Anglais</a></li>
                        <li><a class="dropdown-item" href="#" onclick="afficherHistorique();"><img src="../images/drapeau_es.png" width="25px">&nbsp;&nbsp;&nbsp;Espagnol</a></li>
                      </ul>
                  </li>

              </ul>
              </nav>
            </div>
<!---->

<!---->
  <!---->
            <div class="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-black"><span class="icon-menu h3"></span></a></div>

          </div>

        </div>
      </div>
      
    </header>
		
    </div>
	<div id="adminAcceuil"></div>
	<div id="formulaire"></div>
	
      <script src="../js/jquery-3.3.1.min.js"></script>
  <script src="../js/jquery-migrate-3.0.1.min.js"></script>
  <script src="../js/jquery-ui.js"></script>
  <script src="../js/popper.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/owl.carousel.min.js"></script>
  <script src="../js/jquery.stellar.min.js"></script>
  <script src="../js/jquery.countdown.min.js"></script>
  <script src="../js/jquery.magnific-popup.min.js"></script>
  <script src="../js/bootstrap-datepicker.min.js"></script>
  <script src="../js/aos.js"></script>
  <script src="../js/main.js"></script>
  <script src="../membres/membreRequetes.js"></script>
  <script src="../membres/membreControleurVue.js"></script>
</body>

</html>