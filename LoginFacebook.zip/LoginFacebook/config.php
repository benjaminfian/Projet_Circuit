<?php
	session_start();
	require_once "Facebook/autoload.php";
	$FB =new \Facebook\Facebook([
		'app_id' => '2354539051471677',
		'app_secret' => '30de2e2554c4b8019b5d68ad14afd97f',
		'default_graph_version' => 'v2.10'
		]);
	
	$helper = $FB->getRedirectLoginHelper();	

?>